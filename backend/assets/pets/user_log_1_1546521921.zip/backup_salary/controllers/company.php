<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:37 PM
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class company extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("company_model", '', true);
    }
    public function index()
    {
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "c.insertDate";
        $searchCriteria["orderDir"] = "DESC";
        $this->company_model->searchCriteria=$searchCriteria;
        $rsCompany = $this->company_model->getComapny();
        $rsListing['rsCompany']	=	$rsCompany;

        // Load Views
        $this->load->view('company/list', $rsListing);
    }

    public function Addcompany()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->company_model->get_by_id('id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('company/companyForm',$data);
    }

    public function saveCompany()
    {
        $strAction = $this->input->post('action');

        // Check User
       /* $searchCriteria = array();
        $searchCriteria["selectField"] = "w.workid";
        $searchCriteria["city_name"] = $this->Page->getRequest('txt_city_name');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->company_model->searchCriteria=$searchCriteria;
        $rsCityName = $this->company_model->getCityList();
        if(count($rsCityName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=city&m=addCity', 'location');
        }*/
	    $searchCriteria = array();
         $searchCriteria["selectField"] = "c.id";
	    $searchCriteria["Code"] = trim($this->Page->getRequest('Code'));
	    $searchCriteria["Name"] = trim($this->Page->getRequest('Name'));
	   if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
	   $this->company_model->searchCriteria=$searchCriteria;
        $rscompanyName = $this->company_model->getComapny();
	  // echo $this->db->last_query();exit;
        if(count($rscompanyName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=company', 'location');
        }
	   
	   
        $arrHeader["Code"]    =	trim($this->Page->getRequest('Code'));
	   $arrHeader["Name"]    =	trim($this->Page->getRequest('Name'));
	   $arrHeader["Address"]    =	$this->Page->getRequest('Address');
	   $arrHeader["IsPtpl"]    =	$this->Page->getRequest('IsPtpl');
	   
       
		/*print_r($arrHeader);
		print_r($strAction);exit;*/
        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();

            $intCenterID = $this->company_model->insert($arrHeader);
		  
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $worklocationid				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  $arrHeader['updateIP'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');

            $update_record = $this->company_model->update($arrHeader, array('id' => $worklocationid));
		  		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=company', 'location');
    }

	function checkCompanyCode(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'Code'){
			$dbField = 'Code';
			$returnValue = 'CodeExists';
		}else if ($field == 'Name'){
			$dbField = 'Name';
			$returnValue = 'NameExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('companymaster', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('companymaster', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('companymaster', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
	
    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate companymaster set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=company', 'location');
    }

    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";

                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
}
