<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class branch extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("branch_model",'',true);
	}
	
	public function index(){
		$data['rsList'] = $this->branch_model->getList();
		$this->load->view('branch/list', $data);
	}

	public function addBranch(){
		$data["strAction"] 	= $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] 		= $this->Page->getRequest("id");

        if($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->branch_model->get_by_id($data["id"],true);
        }else{
           $data["strAction"] = "A";
        }
		$this->load->view('branch/branch_from',$data);
	}
	
	function process(){
		$BranchID = $this->input->post('hid_id');
		$data['BranchCode'] 	= $this->input->post('BranchCode');
		$data['BranchName'] 	= $this->input->post('BranchName');
		$data['BranchAPXName'] 	= $this->input->post('BranchAPXName');
		$data['BranchAPXID'] 	= $this->input->post('BranchAPXID');
		$data['BranchAPXCode'] 	= $this->input->post('BranchAPXCode');
		
		$errMsg = '';
		
		if($data['BranchCode'] == '') $errMsg .= "BranchCode is empty <br>";	
		if($data['BranchName'] == '') $errMsg .= "BranchName is empty <br>";	
		if($data['BranchAPXName'] == '') $errMsg .= "BranchAPXName is empty <br>";	
		if($data['BranchAPXID'] == '') $errMsg .= "BranchAPXID is empty <br>";	
		if($data['BranchAPXCode'] == '') $errMsg .= "BranchAPXCode is empty <br>";	
		
		$check = $this->branch_model->check_code($BranchID, $data['BranchCode']);
		if(count($check) > 0) $errMsg .= "BranchCode already in use";
		
		if($BranchID != ''){
			$checkIsRec = $this->branch_model->get_by_id($BranchID);
			if(count($checkIsRec) == 0)	$errMsg .= "Invalid branch id";
		}
		
		if($errMsg != '' ){
			$this->Page->setMessage('<div class="msg_error">'.$errMsg.'</div>');
			redirect('?c=branch');
		}
		
		if($BranchID == ''){
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertIP'] = $this->input->ip_address();
			$res = $this->branch_model->addBranch($data);
			if($res){
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to add record</div>');
			}
		}else{
			
			$data['updateBy'] = $this->Page->getSession("intUserId");
			$data['updateDate'] = date('Y-m-d H:i:s');
			$data['updateIP'] = $this->input->ip_address();
			$res = $this->branch_model->updateBranch($data, $BranchID);
			if($res){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update record</div>');
			}
		}
		redirect('c=branch', 'location');
	}
	
	function checkBranchCode(){
		$branchID = $this->input->post('branch_id');
		$code = $this->input->post('code');
		$check = $this->branch_model->check_code($branchID, $code);
		$msg['error'] = count($check) > 0 ? 1 : 0;
		echo json_encode($msg);
	}
	
	function branch_status(){
		$BranchID = $this->input->post('branch_id');
		$bdata = $this->branch_model->get_by_id($BranchID);
		if(!empty($bdata) && $BranchID != ''){
			$set['delete_flag'] = (@$bdata[0]['delete_flag'] == 0) ? 1 : 0;
			$set['updateBy'] = $this->Page->getSession("intUserId");
			$set['updateDate'] = date('Y-m-d H:i:s');
			$set['updateIP'] = $this->input->ip_address();
			$upd = $this->branch_model->updateStatus($set,$BranchID);
			if($upd){
				$msg['data'] = $set;
				$msg['error'] = 0;
				$msg['message'] = 'Success!';
			}else{
				$msg['error'] = 1;
				$msg['message'] = 'Failed!';
			}
		}else{
			$msg['error'] = 1;
			$msg['message'] = 'Something went wrong!';
		}
		echo json_encode($msg);
	}
}