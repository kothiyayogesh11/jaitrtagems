<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Salary_monthly_head extends CI_Controller {
	var $module = 'salary_monthly_head';
	var $datetime;
	var $user_id;
	var $ip;
	function __construct(){
		parent::__construct();
		$this->datetime = date('Y-m-d H:i:s');
		$this->user_id = $this->session->userdata('sess_intUserId');
		$this->ip = $this->input->ip_address();
		$this->load->model("salary_monthly_head_model",'salary',true);
		$this->load->model("salaryhead_model",'salaryhead_model',true);
	}
	
	public function index(){
        $searchCriteria = array();
        $rsSales = $this->salary->get_salary_data();
        $rsListing['rsList']	=	$rsSales;
		$this->load->view('salary_monthly_head/list', $rsListing);
    }

    public function add(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->salary->get_by_id('id', $data["id"]);
        } else{
            $data["strAction"] = "A";
        }
        $this->load->view('salary_monthly_head/salary_form',$data);
    }

	public function process(){
		$salID = $this->input->post('hid_id');
		$data['empID'] = $this->input->post('empID');
		$getEmpData = $this->salary->get_employee_by_id($data['empID']);

		// get salary head master details
        $searchCriteria = array();
        $searchCriteria['id'] = $this->input->post('headID');
        $this->salaryhead_model->searchCriteria = $searchCriteria;
        $resSalaryHead = $this->salaryhead_model->getSalaryhead();

		if(!empty($getEmpData)){
			$data['empCode'] 	= @$getEmpData[0]['EmpCode'];
			$data['empBranch'] 	= @$getEmpData[0]['BranchID'];
			$data['empCompany'] = @$getEmpData[0]['CompanyID'];
            $data['empESINumber'] = $this->input->post('EsiNumber');
            $data['PFNo'] = $this->input->post('PFNumber');
		}else{
			$this->Page->setMessage('<div class="msg_error">Invalid employee..!</div>');
			redirect('c=salary_monthly_head', 'location');exit;
		}

        if(!empty($resSalaryHead)){
            $data['is_pre_defined'] = @$resSalaryHead[0]['is_pre_defined'];
        }else{
            $this->Page->setMessage('<div class="msg_error">Invalid Salary Head..!</div>');
            redirect('c=salary_monthly_head', 'location');exit;
        }

		$data['amount'] = $this->input->post('amount');
		$data['headID'] = $this->input->post('headID');

		$data['month'] = $this->input->post('month');
		$data['year'] = $this->input->post('year');
		$data['date'] = $this->input->post('date');
		$data['days'] = $this->input->post('days');
		if($salID == ''){
			$data['insertDate'] = $this->datetime;
			$data['insertBy'] = $this->user_id;
			$data['insertIP'] = $this->ip;
			$add = $this->salary->addSalaryHead($data);
			if($add){
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to insert data</div>');
			}
		}else{
			$data['updateDate'] = $this->datetime;
			$data['updateBy'] = $this->user_id;
			$data['updateIP'] = $this->ip;
			$upd = $this->salary->updateSalaryHead($data,$salID);
			if($upd){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update data</div>');
			}
		}
		redirect('c=salary_monthly_head', 'location');exit;
	}
	
    public function delete(){
        $ids	=	$this->input->post('chk_lst_list1');
        $ids	=	implode(",", $ids);
        $strQuery = "DELETE FROM ".$this->salary->tbl_salary_employee_monthly_head." WHERE id IN (". $ids .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        redirect('c=salary_monthly_head', 'location');
    }

	function import(){
		
		$date = date('Y-m-d',strtotime($this->input->post('startDate')));
		$check = $this->salary->getMonthModule($date, $this->module);
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_tds';
			$config['upload_path'] = $path;
			$config['allowed_types'] = '*';
			$config['remove_spaces'] = TRUE;
			$this->load->library('upload');
			$this->upload->initialize($config);
			if (!$this->upload->do_upload('import')){
				$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=salary_monthly_head', 'location');		   
			} else {
				$data = array('upload_data' => $this->upload->data());
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				if(!in_array($fdata['type'],array('txt','xlsx'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
					redirect('c=salary_monthly_head', 'location');
				}
				$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['ModuleCode'] = $this->module;
				$fdata['Date'] = $date;
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				$addFile = $this->salary->addFileList($fdata);
				$fileID = $this->db->insert_id();
			}
			if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
				redirect('c=salary_monthly_head', 'location');exit;
			}
			if (!empty($data['upload_data']['file_name'])) {
				$import_xls_file = $data['upload_data']['file_name'];
			} else {
				$import_xls_file = 0;
			}
			$inputFileName = $path . $import_xls_file;
			if(@$fdata['type'] == 'xlsx'){
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
				} catch (Exception $e) {
					die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage());
				}
			
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);

				$arrayCount = count($allDataInSheet);
				$flag = 0;
				$createArray = array('Employee Code','headCode','amount','month','year','date','days');
				$makeArray = array('EmployeeCode'=>'EmployeeCode','headCode'=>'headCode','amount'=>'amount','month'=>'month','year'=>'year','date'=>'date','days'=>'days');
				$SheetDataKey = array();
				foreach ($allDataInSheet as $dataInSheet) {
					foreach ($dataInSheet as $key => $value) {
						if (in_array(trim($value), $createArray)) {
							$value = preg_replace('/\s+/', '', $value);
							$SheetDataKey[trim($value)] = $key;
						} else {
							
						}
					}
				}

				$data = array_diff_key($makeArray, $SheetDataKey);
				
				if (empty($data)) $flag = 1;
				$errMsg = '';
				if ($flag == 1){
					$a = 1;
					for ($i = 2; $i <= $arrayCount; $i++) {
						$err 		= array();
						$empCode 	= $SheetDataKey['EmployeeCode'];
						$headCode 	= $SheetDataKey['headCode'];
						$amount 	= $SheetDataKey['amount'];
						$month 	= $SheetDataKey['month'];
						$year 	= $SheetDataKey['year'];
						$date 	= $SheetDataKey['date'];
						$days 	= $SheetDataKey['days'];
						
						$empCode 	= filter_var(trim($allDataInSheet[$i][$empCode]), FILTER_SANITIZE_STRING);
						$headCode 	= filter_var(trim($allDataInSheet[$i][$headCode]), FILTER_SANITIZE_STRING);
						$amount 	= filter_var(trim($allDataInSheet[$i][$amount]), FILTER_SANITIZE_STRING);
						$month 	= filter_var(trim($allDataInSheet[$i][$month]), FILTER_SANITIZE_STRING);
						$year 	= filter_var(trim($allDataInSheet[$i][$year]), FILTER_SANITIZE_STRING);
						$date 	= filter_var(trim($allDataInSheet[$i][$date]), FILTER_SANITIZE_STRING);
						$days 	= filter_var(trim($allDataInSheet[$i][$days]), FILTER_SANITIZE_STRING);
						
						// get employee details form employee code
						$EMPData = $this->salary->get_employee_by_code($empCode);

						$empID = isset($EMPData[0]['id']) ? $EMPData[0]['id'] : '';
						$empBranch = isset($EMPData[0]['BranchID']) ? $EMPData[0]['BranchID'] : '';
						$empCompany = isset($EMPData[0]['CompanyID']) ? $EMPData[0]['CompanyID'] : '';
                        $empESINumber 	= isset($EMPData[0]['EsiNumber']) && $EMPData[0]['EsiNumber']!='' ? $EMPData[0]['EsiNumber'] : '-'; //$SheetDataKey['EsiNumber'];
                        $PFNo 	= isset($EMPData[0]['PFUANNo']) && $EMPData[0]['PFUANNo']!='' ? $EMPData[0]['PFUANNo'] : '-'; //$SheetDataKey['PFUANNo'];
						$EmployeeName = @$EMPData[0]['EmpFullName'];
						
						if($empCode == '' || $empID == ''){
							$err['empCode'] = '1';
							$errMsg .= $a.' - employee code is empty or invalide<br>';
						}
						
						$getSalaryHeadIdByHeadCode = $this->salary->getSalaryHeadIdByHeadCode($headCode);
						$headID = @$getSalaryHeadIdByHeadCode[0]['id'];
                        $isPreDefined = @$getSalaryHeadIdByHeadCode[0]['is_pre_defined'];

						if($headCode == '' || $headID == ''){
							$err['headCode'] = '1';
							$errMsg .= $a.' - headCode is empty or invalide<br>';
						}
						
						if($amount == ''){
							$err['amount'] = '1';
							$errMsg .= $a.' - amount is empty <br>';
						}
						
						if($month == ''){
							$err['month'] = '1';
							$errMsg .= $a.' - month is empty <br>';
						}
						
						if($year == ''){
							$err['year'] = '1';
							$errMsg .= $a.' - year is empty <br>';
						}
						
						if($date == ''){
							$err['date'] = '1';
							$errMsg .= $a.' - date is empty <br>';
						}
						
						if($days == ''){
							$err['days'] = '1';
							$errMsg .= $a.' - days is empty <br>';
						}
						
						$fetchData[] = array(
							'empID' => $empID, 
							'empCode' => $empCode, 
							'EmployeeName' => $EmployeeName, 
							'empBranch' => $empBranch, 
							'empCompany' => $empCompany,
							
							'headCode' => $headCode,
							'headID' => $headID,
							
							'amount' => $amount,
							'is_pre_defined' => $isPreDefined,
							'empESINumber' => $empESINumber,
							'PFNo' => $PFNo,
							'month' => $month,
							'year' => $year,
							'date' => $date,
							'days' => $days,
							'error'=>$err
						);
						$a++;
					}

					$data['data'] = $fetchData;
					$data['fileID'] = @$fileID;
					$data['errMsg'] = $errMsg;
					$data['date'] = $date;
					$data['checkDate'] = count($check);
					//pre($data);exit;
					$this->load->view('salary_monthly_head/import_list',$data);
				} else {
					$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
					redirect(base_url('c=salary_monthly_head','location'));
				}
			}else{
				$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
				redirect(base_url('c=salary_monthly_head','location'));
			}
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=salary_monthly_head', 'location');
		}
	}
	
	function import_add_process(){
		//pre($this->input->post());exit;
		$empID = $this->input->post('empID');
		$empCode = $this->input->post('empCode');
		$empBranch = $this->input->post('empBranch');
		$empCompany = $this->input->post('empCompany');
		$amount = $this->input->post('amount');
		$is_pre_defined = $this->input->post('is_pre_defined');

		$headID = $this->input->post('headID');
		$empESINumber = $this->input->post('empESINumber');
		$PFNo = $this->input->post('PFNo');
		$month = $this->input->post('month');
		$year = $this->input->post('year');
		$dateTbl = $this->input->post('dateTbl');
		$days = $this->input->post('days');
		
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=salary_monthly_head', 'location');
		}
		
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$check = $this->salary->getMonthModule($date, $this->module);
		if(!empty($check))	foreach($check as $file) $this->salary->removeOldData($file['id'],$fileID);
		
		for($i = 0; $i < $totalLength; $i++){
			$data['empID'] = $empID[$i];
			$data['empCode'] = $empCode[$i];
			$data['empBranch'] = $empBranch[$i];
			$data['empCompany'] = $empCompany[$i];
			$data['amount'] = $amount[$i];
			$data['is_pre_defined'] = $is_pre_defined[$i];
			$data['headID'] = $headID[$i];
			$data['empESINumber'] = $empESINumber[$i];
			$data['PFNo'] = $PFNo[$i];
			$data['month'] = $month[$i];
			$data['year'] = $year[$i];
			$data['date'] = $dateTbl[$i];
			$data['days'] = $days[$i];
			
			$data['FileID'] = $fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIp'] = $this->input->ip_address();

			$add[] = $this->salary->addSalaryHead($data);
		}
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=salary_monthly_head', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/salary_employee_monthly_head.xlsx', NULL);
	}
	
	function checkModuleUpload(){
		//error_reporting(-1);
		$date = $this->input->post('date');
		if($date == ''){
			$msg['error'] = 1;
			$msg['message'] = 'Date is empty!';
		}else{
			$check = $this->tds->getMonthModule($date, $this->module);
			if(count($check) > 0){
				$msg['error'] = 1;
				$msg['message'] = 'This month data already added! \n Are you sure to remove and upload new data?';
			}else{
				$msg['error'] = 0;
				$msg['message'] = 'This month data already added!';
			}
		}
		echo json_encode($msg);
	}
}