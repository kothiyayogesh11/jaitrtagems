<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CalculateSalary extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model("CalculateSalary_model",'calc_sal_model',true);
    }

    public function index(){
        $data = array();
        // Load Views
        $this->load->view('salary/calculate_salary_index', $data);
    }

    public function calculate()
    {
        $calcDate = $this->Page->getRequest("calc_date");
        $lastDayDate = date("Y-m-t",strtotime($calcDate));
        $firstDayDate = date("Y-m-01",strtotime($calcDate));
        $totalDays = date('d', strtotime($lastDayDate));

        // get employee salary details
        $rsEmpSalary = $this->calc_sal_model->getEmployeeSalary($lastDayDate);

        // get employee leave details
        $empLeaveArr = $this->calc_sal_model->getEmployeeLeave($calcDate);
        
        // get employee Joining Date
        $empdojArr = $this->calc_sal_model->getEmployeedoj($calcDate);
        //pre($empdojArr);die;
        // get employee incentive
        $empIncentiveArr = $this->calc_sal_model->getEmployeeIncentive($calcDate);

        // get salary settings
        $rsSalarySettingsArr = $this->calc_sal_model->getEmployeeSalarySetting();

        // get salary head master
        $rsSalaryHeadMaster = $this->calc_sal_model->getSalaryHeadMaster();
        $headMasterArr = array();
        if(count($rsSalaryHeadMaster) > 0)
        {
            foreach ($rsSalaryHeadMaster AS $salaryHeadMaster)
            {
                $headMasterArr[$salaryHeadMaster['code']] = $salaryHeadMaster;
            }
        }

        // get pre paid salary head amount
        $rsEmployeeMonthlyHeadSalary = $this->calc_sal_model->getEmployeeMonthlyHeadSalary($lastDayDate);

        $empMonthlyHeadSalaryArr = array();
        if(count($rsEmployeeMonthlyHeadSalary) > 0)
        {
            foreach ($rsEmployeeMonthlyHeadSalary AS $data)
            {
                $empMonthlyHeadSalaryArr[$data['empID']][$data['code']] = $data['amount'];
            }
        }

        // insert in calculation
        $param = array();
        $param['month'] = date("m",strtotime($calcDate));
        $param['year'] = date("Y",strtotime($calcDate));
        $param['date'] = $calcDate;
        $param['insert_by'] = $this->Page->getSession("intUserId");
        $param['insertdate'] = date('Y-m-d H:i:s');
        $param['insert_ip'] = $this->input->ip_address();
        $calc_id = $this->calc_sal_model->insertCalculation($param);

        // remove old calculation records
        $this->calc_sal_model->deactiveOldRecords($calcDate);
        // calculate salary
        if(count($rsEmpSalary))
        {
            foreach ($rsEmpSalary AS $empSalary)
            {
                //$totalDays = date('d', strtotime($lastDayDate));
                $empId = $empSalary['empID'];
                $empdoj = $empdojArr['DOJ'][$empId];
                $empdol = $empdojArr['DOL'][$empId];
                $empLeave = (isset($empLeaveArr[$empId]) && $empLeaveArr[$empId])?$empLeaveArr[$empId]:0;
                
                //$lastDayDate $firstDayDate
                if($empdoj>$firstDayDate)
                {
                    $staartDay = date('d', strtotime($empdoj));
                    $empWorkedDays = $totalDays - $staartDay - $empLeave + 1;
                    //$empWorkedDays = $totalDays - $empLeave;
                }else
                {
                    $empWorkedDays = $totalDays - $empLeave;
                }
                if($empdol>=$firstDayDate && $empdol<=$lastDayDate)
                {
                    $endDay = date('d', strtotime($empdol));
                    $leftdays = $totalDays - $endDay;
                    $empWorkedDays = $empWorkedDays - $leftdays;
                    //$empWorkedDays = $totalDays - $empLeave;
                }elseif($empdol<$firstDayDate && $empdol !='0000-00-00')
                {
                    $empWorkedDays= 0;
                }
                /*if($empWorkedDays<1)
                {
                    echo $empdoj; 
                    echo "<br />l"; 
                    echo $empdol;
                    echo "<br />lf"; 
                    echo $leftdays;
                    echo "<br />to"; 
                    echo $totalDays; 
                    die;
                }*/
                $incentive = $empIncentiveArr[$empId];
                $salaryb = array();
                $salaryc = array();

                // get pre entered head salary
                if(count($empMonthlyHeadSalaryArr[$empId]) > 0)
                {
                    foreach ($empMonthlyHeadSalaryArr[$empId] AS $key=>$val)
                    {
                        $salaryc[$key] = $val;
                    }
                }
                //Salary Flag GET
                $isflag['isFix'] = $empSalary['isFix'];
                $isflag['TDS'] = $empSalary['TDS'];
                $isflag['PF'] = $empSalary['PF'];
                $isflag['ESIC'] = $empSalary['ESI'];
                //$isflag['hra'] = $empSalary['HRA'];
                $isflag['Incentive'] = $empSalary['INC'];
                $isflag['PTAX'] = $empSalary['PTAX'];
                
                // base salary head
                $salaryb['Basic'] = $empSalary['salary'];
                $salaryb['ConveyanceAllowence']= $empSalary['conveyence_allowence'];
                $salaryb['StandardAllowence']= $empSalary['standard_allowence'];
                $salaryb['SpecialAllowence']= $empSalary['special_allowence'];
                $salaryb['hra']= $empSalary['HRA'];
                $salaryb['Incentive']= $empIncentiveArr[$empId];
                $salaryb['commitmentSalary']= $empSalary['commitmentSalary'];
                $salaryb['TotalSalary']= $empSalary['salary']+$empSalary['conveyence_allowence']+$empSalary['standard_allowence']+$empSalary['special_allowence']+$empSalary['HRA'];

                // calculated salary head
                $salaryc['Basic'] = floatval(($empSalary['salary'] / $totalDays) * $empWorkedDays);
                $salaryc['ConveyanceAllowence'] = floatval(($empSalary['conveyence_allowence'] / $totalDays) * $empWorkedDays);
                $salaryc['StandardAllowence']= floatval(($empSalary['standard_allowence'] / $totalDays) * $empWorkedDays);
                $salaryc['SpecialAllowence']= floatval(($empSalary['special_allowence'] / $totalDays) * $empWorkedDays);
                $salaryc['hra']= floatval(($empSalary['HRA'] / $totalDays) * $empWorkedDays);
                $salaryc['commitmentSalary']= floatval(($empSalary['commitmentSalary']/ $totalDays) * $empWorkedDays);

                // calculate incentive
                $calcIncentive = 0;
                if($empSalary['isFix'] == 0)
                {
                    if($empSalary['IsPP'] == 1)
                    {
                        if($empSalary['IsEarn'] == 0)
                        {
                            $calcIncentive = floatval($incentive - $salaryb['TotalSalary']);
                            $calcIncentive = ($calcIncentive < 0)?0:$calcIncentive;
                        }
                        else if($empSalary['IsEarn'] == 1)
                        {
                            $calcIncentive = floatval($incentive - $salaryb['TotalSalary']);
                        }
                    }
                    else if($empSalary['IsPP'] == 0)
                    {
                        if($empSalary['IsEarn'] == 0)
                        {
                            //$calcIncentive = floatval($incentive + $salaryb['TotalSalary']);
                            $calcIncentive = ($calcIncentive < 0)?0:$calcIncentive;
                        }
                    }
                }

                $salaryc['Incentive']= $calcIncentive;

                $salaryc['GrossPay'] = 0;
               foreach($salaryc as $key=>$val)
                {
                    IF($headMasterArr[$key]['type'] =='ADD')
                    {
                        $salaryc['GrossPay'] += $val;
                    }

                }
                if($salaryb['commitmentSalary']>0)
                {
                    if($salaryc['commitmentSalary']>$salaryc['GrossPay'])
                    {
                        $salaryc['cmtPay'] = $salaryc['commitmentSalary'] - $salaryc['GrossPay'];
                    }else
                    {
                        $salaryc['cmtPay'] = 0;
                    }
                }else
                {
                    $salaryc['cmtPay'] = 0;
                }
                $salaryc['GrossPay'] +=$salaryc['cmtPay'];

                // apply setting
                if(count($rsSalarySettingsArr))
                {
                    foreach ($rsSalarySettingsArr AS $data)
                    {
                        if($isflag[$data['actual_sal_head_code_store']])
                        {
                            if($data['is_calc_on_base_salary'] == 1)
                            {
                                if($data['type'] == 'PER')
                                {
                                    $calval = ($salaryb[$data['actual_sal_head_code']]*$data['value']/100);
                                }
                                else
                                {
                                    $calval = $data['value'];
                                }
                            }
                            else
                            {
                                if($data['type'] == 'PER')
                                {
                                    $calval = ($salaryc[$data['actual_sal_head_code']] * $data['value'] / 100);
                                }
                                else
                                {
                                    $calval = $data['value'];
                                }
                            }
                            $calvalb = $calval;
                            if($data['min_limit']>0 && $data['min_limit']>$calval) {
                                $calval = $data['min_limit'];
                            }
                            if($data['max_limit']>0 && $data['max_limit']<$calval) {
                                $calval = $data['max_limit'];
                            }
                        }else
                        {
                            $calval = 0;
                            $calvalb = 0;
                        }
                        
                        
                        if($data['actual_sal_head_code_store'] == 'PF')
                        {
                            $salaryc[$data['actual_sal_head_code_store']] = round($calval);
                            $salaryb[$data['actual_sal_head_code_store']] = round($calvalb);
                        }else
                        {
                            $salaryc[$data['actual_sal_head_code_store']] = ceil($calval);
                            $salaryb[$data['actual_sal_head_code_store']] = ceil($calvalb);
                        }
                    }
                }
                // add professional tax
                $rsPTax = $this->calc_sal_model->getProfessionalTaxSettings($salaryc['GrossPay']);
                if(count($rsPTax) > 0)
                {
                    foreach ($rsPTax AS $pTax)
                    {
                        $salaryc['PTAX'] = $pTax['value'];
                    }
                }

                $salaryc['GrossDid'] = 0;

                foreach($salaryc as $key=>$val)
                {
                    IF($headMasterArr[$key]['type'] =='MINUS')
                    {
                        $salaryc['GrossDid'] += $val;
                    }
                }

                $salaryc['NetPay'] = $salaryc['GrossPay'] - $salaryc['GrossDid'];

                

                /*if($empId==1)
                {
                    
                    pre($empIncentiveArr);
                    echo $totalDays;
                    echo "T - L";
                    echo $incentive;
                    echo "<br />";
                    pre($salaryc); exit; 
                }*/

                if(count($salaryc) > 0)
                {
                    $batchArr = array();
                    foreach ($salaryc AS $code=>$amount)
                    {
                        if(isset($empMonthlyHeadSalaryArr[$empId][$code]))
                        {
                            continue;
                        }

                        $param = array();
                        $param['empID'] = $empId;
                        $param['amount'] = $amount;
                        $param['headID'] = $headMasterArr[$code]['id'];
                        $param['is_pre_defined'] = $headMasterArr[$code]['is_pre_defined'];
                        $param['empCode'] = $empSalary['emp_code'];
                        $param['empBranch'] = $empSalary['emp_branch_id'];
                        $param['empCompany'] = $empSalary['emp_company_id'];
                        $param['empESINumber'] = $empSalary['EsiNumber'];
                        $param['PFNo'] = $empSalary['PFNumber'];
                        $param['month'] = date("m",strtotime($calcDate));
                        $param['year'] = date("Y",strtotime($calcDate));
                        $param['date'] = $calcDate;
                        $param['days'] = $empWorkedDays;
                        $param['EntryType'] = 0;
                        $param['calc_id'] = $calc_id;
                        $param['insertBy'] = $this->Page->getSession("intUserId");
                        $param['insertDate'] = date('Y-m-d H:i:s');
                        $param['insertIP'] = $this->input->ip_address();

                        $batchArr[] = $param;
                        //pre($param);
                    }
                }

                $this->calc_sal_model->insertBatch($batchArr);

                $this->Page->setMessage('REC_ADD_MSG');

                // For free memory form variable
                $empId = null;
                $empLeave = null;
                $empWorkedDays = null;
            }
        }

        redirect('c=CalculateSalary', 'location');
    }
}