<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class monthlysales extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model("monthlysales_model", '', true);
    }
	
    public function index(){
        $searchCriteria = array();
        $searchCriteria["orderField"] = "ms.id";
        $searchCriteria["orderDir"] = "DESC";
        $this->monthlysales_model->searchCriteria=$searchCriteria;
        $rsSales = $this->monthlysales_model->getSales();
        $rsListing['rsSales']	=	$rsSales;
        $this->load->view('managesales/list', $rsListing);
    }

    public function Addsales(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->monthlysales_model->get_by_id('id', $data["id"]);
        }else{
            $data["strAction"] = "A";
        }
        $this->load->view('managesales/salesForm',$data);
    }

    public function saveSales(){
       $strAction = $this->input->post('action');
	   $date = trim($this->Page->getRequest('date'));
	   $d = date_parse_from_format("Y-m-d", $date);
	   $searchCriteria["Month"] = $d["month"];
	   $searchCriteria["BranchID"] = trim($this->Page->getRequest('BranchID'));
	   
	   if ($strAction == 'E'){
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
       }
	            
	   $searchCriteria["selectField"] = "ms.id";
	   $this->monthlysales_model->searchCriteria=$searchCriteria;
       $rsCheckDate = $this->monthlysales_model->getSales();
       if(count($rsCheckDate) > 0){
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=monthlysales', 'location');
       }
	   
	   
       $arrHeader["BranchID"]    =	trim($this->Page->getRequest('BranchID'));
	   $arrHeader["date"]    =	trim($this->Page->getRequest('date'));
	   $arrHeader["SalesAmount"]    =	$this->Page->getRequest('SalesAmount');
	   $arrHeader["SalesQty"]    =	$this->Page->getRequest('SalesQty');
	   $arrHeader["NetSalesAmout"]    = $this->Page->getRequest('NetSalesAmout');
	   
	   if($arrHeader['date']){
			   
	   }
	   
	    
        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIp'] 		= 	$this->input->ip_address();

            $intCenterID = $this->monthlysales_model->insert($arrHeader);
		  
		  
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $salesID				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  $arrHeader['updateIp'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');

            $update_record = $this->monthlysales_model->update($arrHeader, array('id' => $salesID));
		  		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=monthlysales', 'location');
    }

	function datecheck(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'date'){
			$dbField = 'Date';
			$returnValue = 'dateExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('branchwisemonthlysales', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('branchwisemonthlysales', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('branchwisemonthlysales', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
	
    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate branchwisemonthlysales set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=monthlysales', 'location');
    }

    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";

                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
	
	function import(){
		/*pre($_FILES);
		pre($this->input->post());
		exit;*/
		$startDate = $this->input->post('startDate');
		$module = 'monthlysales';
		$check = $this->monthlysales_model->getMonthModule($startDate, $module);
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_salse';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')) {
               	$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=monthlysales', 'location');
            } else {
                $data = array('upload_data' => $this->upload->data());
				$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				$fdata['ModuleCode'] = 'monthlysales';
				$fdata['Date'] = $startDate;
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				
				if(!in_array($fdata['type'],array('txt','xlsx'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            		redirect('c=monthlysales', 'location');
				}
				
				$addFile = $this->monthlysales_model->addFileList($fdata);
				$fileID = $this->db->insert_id();
            }
            if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            	redirect('c=monthlysales', 'location');
			}
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            
			$inputFileName = $path . $import_xls_file;
			
			if(@$fdata['type'] == 'xlsx'){
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
				} catch (Exception $e) {
					die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
							. '": ' . $e->getMessage());
				}
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
				
				$arrayCount = count($allDataInSheet);
				$flag = 0;
				$createArray = array('Branch', 'Qty.', "Free", 'Avg. Rate', 'Sales Value', 'Discount Amt.', 'Tax Amt.', 'Surcharge', 'Service Tax', 'Net Amount', 'SR Qty', 'SR Free', 'SR Value', 'SR Discount Amt.', 'SR Tax Amt.', 'SR Surcharge', 'SR Net Amt.', 'Total Qty', 'Total Value', 'Total Discount', 'Total Tax','Total Surcharge','Total Net Value');
				
				$makeArray = array('Branch'=>'Branch', 'Qty.'=>'Qty.', "Free"=>"Free", 'Avg.Rate'=>'Avg.Rate','SalesValue'=>'SalesValue','DiscountAmt.' => 'DiscountAmt.', 'TaxAmt.' => 'TaxAmt.', 'Surcharge' => 'Surcharge', 'ServiceTax' => 'ServiceTax', 'NetAmount' => 'NetAmount','SRQty' => 'SRQty', 'SRFree' => 'SRFree', 'SRValue' => 'SRValue', 'SRDiscountAmt.' => 'SRDiscountAmt.', 'SRTaxAmt.' => 'SRTaxAmt.', 'SRSurcharge' => 'SRSurcharge', 'SRNetAmt.' => 'SRNetAmt.', 'TotalQty' => 'TotalQty', 'TotalValue' => 'TotalValue', 'TotalDiscount' => 'TotalDiscount','TotalTax' => 'TotalTax','TotalSurcharge' => 'TotalSurcharge','TotalNetValue'=>'TotalNetValue');
				$SheetDataKey = array();
				foreach ($allDataInSheet as $dataInSheet) {
					foreach ($dataInSheet as $key => $value) {
						if (in_array(trim($value), $createArray)) {
							$value = preg_replace('/\s+/', '', $value);
							$SheetDataKey[trim($value)] = $key;
						} else {
							
						}
					}
				}
				$data = array_diff_key($makeArray, $SheetDataKey);
				if (empty($data)) {
					$flag = 1;
				}
				$errMsg = '';
				if ($flag == 1) {
					$a = 1;
					for ($i = 2; $i <= $arrayCount; $i++) {
						$err = array();
						$BranchID = $SheetDataKey['Branch'];                    
						$SalesAmount = $SheetDataKey['TotalValue'];
						$SalesQty = $SheetDataKey['Qty.'];
						$NetSalesAmout = $SheetDataKey['TotalNetValue'];
						
						$BranchID = filter_var(trim($allDataInSheet[$i][$BranchID]), FILTER_SANITIZE_STRING);
						$Date = $startDate;
						$SalesAmount = filter_var(trim($allDataInSheet[$i][$SalesAmount]), FILTER_SANITIZE_EMAIL);
						$SalesQty = filter_var(trim($allDataInSheet[$i][$SalesQty]), FILTER_SANITIZE_STRING);
						$NetSalesAmout = filter_var(trim($allDataInSheet[$i][$NetSalesAmout]), FILTER_SANITIZE_STRING);
						$BranchName = $BranchID;
						
						$BranchData = $this->monthlysales_model->getBranchIdByName($BranchName);
						$BranchID = @$BranchData[0]['id'] != '' ? @$BranchData[0]['id'] : NULL;
						
						if($BranchID == ''){
							$err['Branch'] = '1';
							$errMsg .= $a.' - Branch is not found<br>';
						}else{
							//echo $a;
							$checkBrach = $this->monthlysales_model->getBranchById($BranchID);
							if(count($checkBrach) ==  0){
								$err['Branch'] = '1';
								$errMsg .= $a.' - There is no branch<br>';
							}
						}
						
						
						if(strtotime($startDate) == 0){
							$err['Date'] = '1';
							$errMsg .= $a.' - Date is empty or invalide <br>';
						}
						
						if($SalesQty == ''){
							$err['SalesQty'] = '1';
							$errMsg .= $a.' - Sales Qty is empty <br>';
						}
						
						$checkIsExist = $this->monthlysales_model->checkRecExists($BranchID, $Date);
						/*if(count($checkIsExist) > 0){
							$err['recExit']['count'] = '1';
							$errMsg .= $a.' - Monthly salse is already added <br> ';
						}*/
						
						$fetchData[] = array('BranchID' => $BranchID, 'Date' => $Date, 'SalesAmount' => $SalesAmount, 'SalesQty' => $SalesQty, 'NetSalesAmout' => $NetSalesAmout,'BranchName' => $BranchName,'error'=>$err);
						$a++;
					}           
					//pre($fetchData);exit;
					
				} else {
					redirect(base_url());
				}
			}else{
				$txt = file_get_contents($inputFileName);
				$convert = explode("\n", $txt);
				$length = count($convert);
				$a = 1;
				for($i = 0; $i <= $length; $i++){
					if(!empty($convert[$i])){
						$txtData = explode("\t",$convert[$i]);
						//pre($txtData);
						if(strtolower(trim($txtData[0])) == strtolower('Grand Total')) continue;
						$BranchID = @$txtData[0];
						$Date = $startDate;
						$SalesAmount = @$txtData[19];//filter_var(trim($allDataInSheet[$i][$SalesAmount]), FILTER_SANITIZE_EMAIL);
						$SalesQty = @$txtData[6];//filter_var(trim($allDataInSheet[$i][$SalesQty]), FILTER_SANITIZE_STRING);
						$NetSalesAmout = @$txtData[23];//filter_var(trim($allDataInSheet[$i][$NetSalesAmout]), FILTER_SANITIZE_STRING);
						$BranchName = $BranchID;
						
						$BranchData = $this->monthlysales_model->getBranchIdByName($BranchName);
						$BranchID = @$BranchData[0]['id'] != '' ? @$BranchData[0]['id'] : NULL;
						
						if($BranchID == ''){
							$err['Branch'] = '1';
							$errMsg .= $a.' - Branch is not found <br>';
						}else{
							$checkBrach = $this->monthlysales_model->getBranchById($BranchID);
							if(count($checkBrach) ==  0){
								$err['Branch'] = '1';
								$errMsg .= $a.' - There is no branch<br>';
							}
						}
						
						if(strtotime($startDate) == 0){
							$err['Date'] = '1';
							$errMsg .= $a.' - Date is empty or invalide <br>';
						}
						
						if($SalesQty == ''){
							$err['SalesQty'] = '1';
							$errMsg .= $a.' - Sales Qty is empty <br>';
						}
						
						$checkIsExist = $this->monthlysales_model->checkRecExists($BranchID, $Date);
						
						$fetchData[] = array('BranchID' => $BranchID, 'Date' => $Date, 'SalesAmount' => $SalesAmount, 'SalesQty' => $SalesQty, 'NetSalesAmout' => $NetSalesAmout,'BranchName' => $BranchName,'error'=>$err);
						$a++;
					}
				}
			}
			//exit;
			$data['data'] = $fetchData;
			$data['fileID'] = @$fileID;
			$data['errMsg'] = $errMsg;
			$data['date'] = $startDate;
			$data['checkDate'] = count($check);
			$this->load->view('managesales/import_list',$data);
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=monthlysales', 'location');
		}
	}
	
	function import_add_process(){
		//pre($this->input->post());exit;
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$BranchID = $this->input->post('BranchID');
		$Date = $this->input->post('Date');
		$SalesAmount = $this->input->post('SalesAmount');
		$SalesQty = $this->input->post('SalesQty');
		$NetSalesAmout = $this->input->post('NetSalesAmout');
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=monthlysales', 'location');
		}
		
		$module = 'monthlysales';
		$check = $this->monthlysales_model->getMonthModule($date, $module);
		if(!empty($check)){
			foreach($check as $file){
				$this->monthlysales_model->removeOldData($file['id'],$fileID);
			}
		}
		
		
		
		for($i = 0; $i < $totalLength; $i++){
			$data['BranchID'] = $BranchID[$i];
			$data['Date'] = date('Y-m-d',strtotime($Date[$i]));
			$data['SalesAmount'] = $SalesAmount[$i];
			$data['SalesQty'] = $SalesQty[$i];
			$data['NetSalesAmout'] = $NetSalesAmout[$i];
			$data['FileID'] = $fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIp'] = $this->input->ip_address();
			$add[] = $this->monthlysales_model->addMonthlySalseData($data);
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=monthlysales', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/salse_main.xlsx', NULL);
	}
}
