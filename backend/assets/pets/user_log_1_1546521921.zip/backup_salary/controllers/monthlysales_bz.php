<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class monthlysales extends CI_Controller
{
    function __construct()
    {
		parent::__construct();
        $this->load->model("monthlysales_model", '', true);
    }
    public function index()
    {
		
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "ms.id";
        $searchCriteria["orderDir"] = "DESC";
        $this->monthlysales_model->searchCriteria=$searchCriteria;
        $rsSales = $this->monthlysales_model->getSales();
        $rsListing['rsSales']	=	$rsSales;
        // Load Views
        $this->load->view('managesales/list', $rsListing);
    }
    public function Addsales()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->monthlysales_model->get_by_id('id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('managesales/salesForm',$data);
    }
    public function saveSales()
    {
        $strAction = $this->input->post('action');
	   $date = trim($this->Page->getRequest('date'));
	   $d = date_parse_from_format("Y-m-d", $date);
	   $searchCriteria["Month"] = $d["month"];
	   $searchCriteria["BranchID"] = trim($this->Page->getRequest('BranchID'));
	   
	   if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
	            
	   $searchCriteria["selectField"] = "ms.id";
	   $this->monthlysales_model->searchCriteria=$searchCriteria;
        $rsCheckDate = $this->monthlysales_model->getSales();
        if(count($rsCheckDate) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=monthlysales', 'location');
        }
	   
	   
       $arrHeader["BranchID"]    =	trim($this->Page->getRequest('BranchID'));
	   $arrHeader["date"]    =	trim($this->Page->getRequest('date'));
	   $arrHeader["SalesAmount"]    =	$this->Page->getRequest('SalesAmount');
	   $arrHeader["SalesQty"]    =	$this->Page->getRequest('SalesQty');
	   $arrHeader["NetSalesAmout"]    = $this->Page->getRequest('NetSalesAmout');
	   
	   if($arrHeader['date']){
			   
	   }
	   
	    
        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIp'] 		= 	$this->input->ip_address();
            $intCenterID = $this->monthlysales_model->insert($arrHeader);
		  
		  
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $salesID				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  	$arrHeader['updateIp'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');
            $update_record = $this->monthlysales_model->update($arrHeader, array('id' => $salesID));
		  		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }
        redirect('c=monthlysales', 'location');
    }
	function datecheck(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'date'){
			$dbField = 'Date';
			$returnValue = 'dateExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('branchwisemonthlysales', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('branchwisemonthlysales', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('branchwisemonthlysales', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
	
    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate branchwisemonthlysales set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=monthlysales', 'location');
    }
    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";
                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }
    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";
                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
	
	function import(){
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../';
			$config['file_name'] = time().'_import';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')) {
               echo $this->upload->display_errors();
			   exit;
			   // $error = array('error' => $this->upload->display_errors());
            } else {
				
                $data = array('upload_data' => $this->upload->data());
            }
            
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            $inputFileName = $path . $import_xls_file;
            try {
				
                $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
                $objReader = PHPExcel_IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch (Exception $e) {
                die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
                        . '": ' . $e->getMessage());
            }
            $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
            
            $arrayCount = count($allDataInSheet);
            $flag = 0;
            $createArray = array('EmpCode', 'Salary', 'CommitmentSalary', 'startDate', 'EndDate','IsFix');
            $makeArray = array('EmpCode' => 'EmpCode', 'Salary' => 'Salary', 'CommitmentSalary' => 'CommitmentSalary', 'startDate' => 'startDate', 'EndDate' => 'EndDate','IsFix'=>'IsFix');
            $SheetDataKey = array();
            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    } else {
                        
                    }
                }
            }
            $data = array_diff_key($makeArray, $SheetDataKey);
           
            if (empty($data)) {
                $flag = 1;
            }
            if ($flag == 1) {
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $addresses = array();
                    $EmpCode = $SheetDataKey['EmpCode'];
                    $Salary = $SheetDataKey['Salary'];
                    $CommitmentSalary = $SheetDataKey['CommitmentSalary'];
                    $startDate = $SheetDataKey['startDate'];
                    $EndDate = $SheetDataKey['EndDate'];
					$isFix = $SheetDataKey['IsFix'];
					
                    $EmpCode = filter_var(trim($allDataInSheet[$i][$EmpCode]), FILTER_SANITIZE_STRING);
                    $Salary = filter_var(trim($allDataInSheet[$i][$Salary]), FILTER_SANITIZE_STRING);
                    $CommitmentSalary = filter_var(trim($allDataInSheet[$i][$CommitmentSalary]), FILTER_SANITIZE_EMAIL);
                    $startDate = filter_var(trim($allDataInSheet[$i][$startDate]), FILTER_SANITIZE_STRING);
                    $EndDate = filter_var(trim($allDataInSheet[$i][$EndDate]), FILTER_SANITIZE_STRING);
					$isFix = filter_var(trim($allDataInSheet[$i][$isFix]), FILTER_SANITIZE_STRING);
					
                    $fetchData[] = array('EmpCode' => $EmpCode, 'Salary' => $Salary, 'CommitmentSalary' => $CommitmentSalary, 'startDate' => $startDate, 'EndDate' => $EndDate,'IsFix'=>$isFix);
                }              
                $fetchData;
				if(isset($fetchData) && !empty($fetchData)){
					$i = 0;
					$empData = array();
					foreach($fetchData as $eval){
						if($eval['EmpCode'] == ''){
							$this->Page->setMessage('<div class="msg_error">Employee code is empty</div>');
            				redirect('c=salary', 'location');
						}
						$emp = $this->monthlysales_model->get_employee_by_code($eval['EmpCode']);
						
						if(empty($emp) && !isset($emp[0]['id'])){
							$this->Page->setMessage('<div class="msg_error">Invalid employee code</div>');
            				redirect('c=salary', 'location');
						}
						
						$empData[$i]['empID'] = @$emp[0]['id'];
						$empData[$i]['salary'] = $eval['Salary'];
						$empData[$i]['commitmentSalary'] = $eval['CommitmentSalary'];
						$empData[$i]['startDate'] = date('Y-m-d',strtotime($eval['startDate']));
						$empData[$i]['endDate'] = date('Y-m-d',strtotime($eval['EndDate']));
						$empData[$i]['isFix'] = strtolower($eval['IsFix']) == 'yes' ? 1 : 0;
						$i++;
					}
				}
				
				if(isset($empData) && !empty($empData)){
					foreach($empData as $val){
						$this->monthlysales_model->update_is_last(array('empID',$val['empID']));
						$val['isLast'] = 1;
						$add[] = $this->monthlysales_model->addImportSalary($val);
					}
				}
				if(isset($add) && count($add) > 0){
					$this->Page->setMessage('REC_ADD_MSG');
				}
            } else {
                redirect(base_url());
            }
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
		}
		redirect('c=salary', 'location');
	}
	
	function import(){
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../';
			$config['file_name'] = time().'_import_salse';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')) {
               echo $this->upload->display_errors();
			   exit;
			   // $error = array('error' => $this->upload->display_errors());
            } else {
				
                $data = array('upload_data' => $this->upload->data());
            }
            
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            $inputFileName = $path . $import_xls_file;
            try {
				
                $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
                $objReader = PHPExcel_IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch (Exception $e) {
                die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
                        . '": ' . $e->getMessage());
            }
            $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
            
            $arrayCount = count($allDataInSheet);
            $flag = 0;
            $createArray = array('EmpCode', 'Salary', 'CommitmentSalary', 'startDate', 'EndDate','IsFix');
            $makeArray = array('EmpCode' => 'EmpCode', 'Salary' => 'Salary', 'CommitmentSalary' => 'CommitmentSalary', 'startDate' => 'startDate', 'EndDate' => 'EndDate','IsFix'=>'IsFix');
            $SheetDataKey = array();
            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    } else {
                        
                    }
                }
            }
            $data = array_diff_key($makeArray, $SheetDataKey);
           
            if (empty($data)) {
                $flag = 1;
            }
            if ($flag == 1) {
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $addresses = array();
                    $EmpCode = $SheetDataKey['EmpCode'];
                    $Salary = $SheetDataKey['Salary'];
                    $CommitmentSalary = $SheetDataKey['CommitmentSalary'];
                    $startDate = $SheetDataKey['startDate'];
                    $EndDate = $SheetDataKey['EndDate'];
					$isFix = $SheetDataKey['IsFix'];
					
                    $EmpCode = filter_var(trim($allDataInSheet[$i][$EmpCode]), FILTER_SANITIZE_STRING);
                    $Salary = filter_var(trim($allDataInSheet[$i][$Salary]), FILTER_SANITIZE_STRING);
                    $CommitmentSalary = filter_var(trim($allDataInSheet[$i][$CommitmentSalary]), FILTER_SANITIZE_EMAIL);
                    $startDate = filter_var(trim($allDataInSheet[$i][$startDate]), FILTER_SANITIZE_STRING);
                    $EndDate = filter_var(trim($allDataInSheet[$i][$EndDate]), FILTER_SANITIZE_STRING);
					$isFix = filter_var(trim($allDataInSheet[$i][$isFix]), FILTER_SANITIZE_STRING);
					
                    $fetchData[] = array('EmpCode' => $EmpCode, 'Salary' => $Salary, 'CommitmentSalary' => $CommitmentSalary, 'startDate' => $startDate, 'EndDate' => $EndDate,'IsFix'=>$isFix);
                }              
                $fetchData;
				if(isset($fetchData) && !empty($fetchData)){
					$i = 0;
					$empData = array();
					foreach($fetchData as $eval){
						if($eval['EmpCode'] == ''){
							$this->Page->setMessage('<div class="msg_error">Employee code is empty</div>');
            				redirect('c=salary', 'location');
						}
						$emp = $this->salary_model->get_employee_by_code($eval['EmpCode']);
						
						if(empty($emp) && !isset($emp[0]['id'])){
							$this->Page->setMessage('<div class="msg_error">Invalid employee code</div>');
            				redirect('c=salary', 'location');
						}
						
						$empData[$i]['empID'] = @$emp[0]['id'];
						$empData[$i]['salary'] = $eval['Salary'];
						$empData[$i]['commitmentSalary'] = $eval['CommitmentSalary'];
						$empData[$i]['startDate'] = date('Y-m-d',strtotime($eval['startDate']));
						$empData[$i]['endDate'] = date('Y-m-d',strtotime($eval['EndDate']));
						$empData[$i]['isFix'] = strtolower($eval['IsFix']) == 'yes' ? 1 : 0;
						$i++;
					}
				}
				
				if(isset($empData) && !empty($empData)){
					foreach($empData as $val){
						$this->salary_model->update_is_last(array('empID',$val['empID']));
						$val['isLast'] = 1;
						$add[] = $this->salary_model->addImportSalary($val);
					}
				}
				if(isset($add) && count($add) > 0){
					$this->Page->setMessage('REC_ADD_MSG');
				}
            } else {
                redirect(base_url());
            }
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
		}
		redirect('c=salary', 'location');
	}
}
