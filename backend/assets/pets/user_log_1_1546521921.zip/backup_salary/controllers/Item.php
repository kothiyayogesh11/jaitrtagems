<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Item extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("item_model",'item',true);
	}
	
	public function index(){
		$data['rsData'] = $this->item->getList();
		$this->load->view('item/list', $data);
	}

	public function addItem(){
		$data["strAction"] 	= $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] 		= $this->Page->getRequest("id");

        if($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->item->get_by_id($data["id"],true);
        }else{
           $data["strAction"] = "A";
        }
		$this->load->view('item/item_form',$data);
	}
	
	function process(){
		//pre($this->input->post());exit;
		$itemID = $this->input->post('hid_id');
		$data['ItemName'] 	= $this->input->post('ItemName');
		$data['ItemCode'] 	= $this->input->post('ItemCode');
		$data['BrandID'] 	= $this->input->post('Brand');
		$data['ProductTypeID'] 	= $this->input->post('ProductType');
		$data['ItemExtCode'] 	= $this->input->post('ItemExtCode');
		$data['IsSerialManaged'] = intval($this->input->post('IsSerialManaged'));
		$errMsg = '';
		
		if($data['ItemName'] == '') $errMsg .= "Name is empty <br>";	
		if($data['ItemCode'] == '') $errMsg .= "Code is empty <br>";	
		if($data['BrandID'] == '') $errMsg .= "Select branch <br>";	
		if($data['ProductTypeID'] == '') $errMsg .= "Select product type is empty <br>";	
		if($data['ItemExtCode'] == '') $errMsg .= "ExtCode is empty <br>";
		
		if($itemID != ''){
			$checkIsRec = $this->item->get_by_id($itemID);
			if(count($checkIsRec) == 0)	$errMsg .= "Invalid item id";
		}
		
		if($errMsg != '' ){
			$this->Page->setMessage('<div class="msg_error">'.$errMsg.'</div>');
			redirect('?c=item');
		}
		
		if($itemID == ''){
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertIP'] = $this->input->ip_address();
			$res = $this->item->addItem($data);
			if($res){
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to add record</div>');
			}
		}else{
			
			$data['updateBy'] = $this->Page->getSession("intUserId");
			$data['updateDate'] = date('Y-m-d H:i:s');
			$data['updateIP'] = $this->input->ip_address();
			$res = $this->item->updateItem($data, $itemID);
			if($res){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update record</div>');
			}
		}
		redirect('c=item', 'location');
	}
	
	function delete(){
		$arrUserIds		= $this->input->post('chk_lst_list1');
		$strUserIds		= implode(",", $arrUserIds);
		$strQuery = "DELETE FROM ".$this->item->tbl_itemmaster." WHERE id IN (". $strUserIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		redirect('c=item', 'location');
	}
	
}