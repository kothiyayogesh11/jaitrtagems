<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:37 PM
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Salaryhead extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("salaryhead_model", '', true);
    }
    public function index()
    {
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "c.insertDate";
        $searchCriteria["orderDir"] = "DESC";
        $this->salaryhead_model->searchCriteria=$searchCriteria;
        $rsSalary = $this->salaryhead_model->getSalaryhead();
        $rsListing['rsSalary']	=	$rsSalary;

        // Load Views
        $this->load->view('salaryhead/list', $rsListing);
    }

    public function Addsalaryhead()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->salaryhead_model->get_by_id('id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('salaryhead/salaryForm',$data);
    }

    public function savesalaryhead()
    {
        $strAction = $this->input->post('action');

        // Check User
       $searchCriteria = array();
        $searchCriteria["selectField"] = "c.id";
        $searchCriteria["code"] = $this->Page->getRequest('code');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->salaryhead_model->searchCriteria=$searchCriteria;
        $rsCityName = $this->salaryhead_model->getSalaryhead();
        if(count($rsCityName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=salaryhead&m=Addsalaryhead', 'location');
        }
	   
        $arrHeader["code"]    =	$this->Page->getRequest('code');
        $arrHeader["name"]    = 	$this->Page->getRequest('name');
        $arrHeader["type"]    = 	$this->Page->getRequest('type');
		$arrHeader["min_allowed_amount"] = $this->Page->getRequest('min_allowed_amount');
        $arrHeader["max_allowed_amount"]      = 	$this->Page->getRequest('max_allowed_amount');
        $arrHeader["is_pre_defined"]      = 	$this->Page->getRequest('is_pre_defined');
        $arrHeader["is_calc"]      = 	$this->Page->getRequest('is_calc');

		/*print_r($arrHeader);
		print_r($strAction);exit;*/
        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();

            $intCenterID = $this->salaryhead_model->insert($arrHeader);
		  
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $worklocationid				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  $arrHeader['updateIP'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');

            $update_record = $this->salaryhead_model->update($arrHeader, array('id' => $worklocationid));
		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=salaryhead', 'location');
    }

    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate salary_head_master set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=salaryhead', 'location');
    }
		
	function checkLocationCode(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'code'){
			$dbField = 'code';
			$returnValue = 'codeExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('salary_head_master', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('salary_head_master', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('salary_head_master', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";

                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
}
