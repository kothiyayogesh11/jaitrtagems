<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class EmployeeTDS extends CI_Controller {
	var $module = 'employeetds';
	var $datetime;
	var $user_id;
	var $ip;
	function __construct(){
		parent::__construct();
		$this->datetime = date('Y-m-d H:i:s');
		$this->user_id = $this->session->userdata('sess_intUserId');
		$this->ip = $this->input->ip_address();
		$this->load->model("employeetds_model",'tds',true);
	}
	
	public function index(){
        $searchCriteria = array();
        $rsSales = $this->tds->getemptds();
        $rsListing['rsList']	=	$rsSales;
		$this->load->view('employeetds/list', $rsListing);
    }

    public function add(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->tds->get_by_id('id', $data["id"]);
        } else{
            $data["strAction"] = "A";
        }
        $this->load->view('employeetds/tds_form',$data);
    }

	public function process(){
		$tdsID = $this->input->post('hid_id');
		$data['empID'] = $this->input->post('EmpID');
		$data['tdsDate'] = $this->input->post('tdsDate');
		$data['tdsAmount'] = $this->input->post('tdsAmount');
		if($tdsID == ''){
			$data['insertDate'] = $this->datetime;
			$data['insertBy'] = $this->user_id;
			$data['insertIP'] = $this->ip;
			$add = $this->tds->addTds($data);
			if($add){
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to insert data</div>');
			}
		}else{
			$data['updateDate'] = $this->datetime;
			$data['updateBy'] = $this->user_id;
			$data['updateIP'] = $this->ip;
			$upd = $this->tds->updateTds($data,$tdsID);
			if($upd){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update data</div>');
			}
		}
		redirect('c=employeetds', 'location');exit;
	}
	
    public function delete(){
        $ids	=	$this->input->post('chk_lst_list1');
        $ids	=	implode(",", $ids);
        $strQuery = "DELETE FROM ".$this->tds->tbl_employee_tds." WHERE id IN (". $ids .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        redirect('c=employeetds', 'location');
    }

	function import(){
		
		$date = date('Y-m-d',strtotime($this->input->post('startDate')));
		$check = $this->tds->getMonthModule($date, $this->module);
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_tds';
			$config['upload_path'] = $path;
			$config['allowed_types'] = '*';
			$config['remove_spaces'] = TRUE;
			$this->load->library('upload');
			$this->upload->initialize($config);
			if (!$this->upload->do_upload('import')){
				$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=employeetds', 'location');		   
			} else {
				$data = array('upload_data' => $this->upload->data());
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				if(!in_array($fdata['type'],array('txt','xlsx'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
					redirect('c=employeetds', 'location');
				}
				$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['ModuleCode'] = 'EmployeeTDS';
				$fdata['Date'] = $date;
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				$addFile = $this->tds->addFileList($fdata);
				$fileID = $this->db->insert_id();
			}
			if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
				redirect('c=employeetds', 'location');exit;
			}
			if (!empty($data['upload_data']['file_name'])) {
				$import_xls_file = $data['upload_data']['file_name'];
			} else {
				$import_xls_file = 0;
			}
			$inputFileName = $path . $import_xls_file;
			if(@$fdata['type'] == 'xlsx'){
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
				} catch (Exception $e) {
					die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage());
				}
			
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
				$arrayCount = count($allDataInSheet);
				$flag = 0;
				$createArray = array('Employee','TDS Amount');
				$makeArray = array('Employee'=>'Employee','TDSAmount'=>'TDSAmount');
				$SheetDataKey = array();
				foreach ($allDataInSheet as $dataInSheet) {
					foreach ($dataInSheet as $key => $value) {
						if (in_array(trim($value), $createArray)) {
							$value = preg_replace('/\s+/', '', $value);
							$SheetDataKey[trim($value)] = $key;
						} else {
							
						}
					}
				}
				
				$data = array_diff_key($makeArray, $SheetDataKey);
				
				if (empty($data)) $flag = 1;
				$errMsg = '';
				if ($flag == 1){
					$a = 1;
					for ($i = 2; $i <= $arrayCount; $i++) {
						$err 		= array();
						$Employee 	= $SheetDataKey['Employee'];
						$TDSAmount 	= $SheetDataKey['TDSAmount'];
						//pre($SheetDataKey);exit;
						$Employee 	= filter_var(trim($allDataInSheet[$i][$Employee]), FILTER_SANITIZE_STRING);
						$TDSAmount 	= filter_var(trim($allDataInSheet[$i][$TDSAmount]), FILTER_SANITIZE_EMAIL);
						
						$EMPData = $this->tds->get_employee_by_code($Employee);
						$EmployeeID = isset($EMPData[0]['id']) ? $EMPData[0]['id'] : '';
						$EmployeeName = @$EMPData[0]['EmpFullName'];
						
						if($EmployeeID == ''){
							$err['EmployeeID'] = '1';
							$EmployeeName = $Employee;
							$errMsg .= $a.' - '.$Employee.' is not found <br>';
						}
						
						if($TDSAmount == ''){
							$err['TDSAmount'] = '1';
							$errMsg .= $a.' - TDSAmount is empty <br>';
						}
						
						
						
						$fetchData[] = array(
							'EmployeeID' => $EmployeeID, 
							'EmployeeName' => $EmployeeName, 
							'TDSAmount' => $TDSAmount,
							'error'=>$err
						);
						$a++;
					}           
						
					$data['data'] = $fetchData;
					$data['fileID'] = @$fileID;
					$data['errMsg'] = $errMsg;
					$data['date'] = $date;
					$data['checkDate'] = count($check);
					//pre($data);exit;
					$this->load->view('employeetds/import_list',$data);
				} else {
					$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
					redirect(base_url('c=employeetds','location'));
				}
			}else{
				$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
				redirect(base_url('c=employeetds','location'));
			}
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=employeetds', 'location');
		}
	}
	
	function import_add_process(){
		$empID = $this->input->post('EmployeeID');
		$tdsAmount = $this->input->post('TDSAmount');
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=employeetds', 'location');
		}
		
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$check = $this->tds->getMonthModule($date, $this->module);
		if(!empty($check)){
			foreach($check as $file){
				$this->tds->removeOldData($file['id'],$fileID);
			}
		}
		
		for($i = 0; $i < $totalLength; $i++){
			$data['empID'] = $empID[$i];
			$data['tdsDate'] = date('Y-m-d',strtotime($date));
			$data['tdsAmount'] = $tdsAmount[$i];
			$data['FileID'] = $fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIp'] = $this->input->ip_address();
			$add[] = $this->tds->addTds($data);
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=employeetds', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/TDS.xlsx', NULL);
	}
	
	function checkModuleUpload(){
		//error_reporting(-1);
		$date = $this->input->post('date');
		if($date == ''){
			$msg['error'] = 1;
			$msg['message'] = 'Date is empty!';
		}else{
			$check = $this->tds->getMonthModule($date, $this->module);
			if(count($check) > 0){
				$msg['error'] = 1;
				$msg['message'] = 'This month data already added! \n Are you sure to remove and upload new data?';
			}else{
				$msg['error'] = 0;
				$msg['message'] = 'This month data already added!';
			}
		}
		echo json_encode($msg);
	}
}