<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Empoyee_details extends CI_Controller {
 
    
	function __construct(){
		parent::__construct();
		$this->load->model("employee_details_model",'',true);
		
	}
	
	public function index(){
		$arrWhere	=	array();
		// Get All Customers
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "*";
		$searchCriteria["orderField"] = "insertDate";
		$searchCriteria["orderDir"] = "DESC";
		$this->employee_details_model->searchCriteria=$searchCriteria;
		$rsDetails = $this->employee_details_model->getDetails();
		$rsListing['rsDetails']	=	$rsDetails;
		
		// Load Views
		$this->load->view('employee/details_list', $rsListing);	
	}

   public function addDetails(){
		$this->employee_details_model->tbl="employee_details";
		$data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->employee_details_model->get_by_id('id', $data["id"]);
        } else {
            $data["strAction"] = "A";
        }
		$this->load->view('employee/details_from',$data);
	}
	
	public function SaveDetails(){
        $imagePath = '';
        if ($_FILES['profilepic']['name'] && $_FILES['profilepic']['name'] != '') {
            $config['upload_path'] = './images/employee';
            $config['allowed_types'] = '*';
            $config['max_size'] = '2000';
            $config['max_width'] = '0';
            $config['max_height'] = '0';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('profilepic')) {
                $strMessage	=	'<div class="msg_error">'.$this->upload->display_errors().'</div>';
                $this->Page->setMessage($strMessage);
                redirect('c=empoyee_details&m=addDetails&action=E&id='.$this->Page->getRequest('hid_id'), 'location');
                return;
            } else {
                $data = array('upload_data' => $this->upload->data());
                $imagePath = './images/employee/' . $data['upload_data']['orig_name'];
            }
            $arrHeader["profilepic	"] =   $imagePath;
        }

		$this->employee_details_model->tbl="employee_details";
		$strAction = $this->input->post('action');
		
		// Check Customer
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "*";
		$searchCriteria["email"] = $this->Page->getRequest('email');
		$searchCriteria["empid"] = $this->Page->getRequest('empid');
		 if ($strAction == 'E')
		   {
			  $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
		   }
		$this->employee_details_model->searchCriteria=$searchCriteria;
		$rsCustomers = $this->employee_details_model->getDetails();
		if(count($rsCustomers) > 0){
			$this->Page->setMessage('ALREADY_EXISTS');
			redirect('c=empoyee_details&m=addDetails', 'location');
		}
		if($this->Page->getRequest('password') != $this->Page->getRequest('cpassword')){
			$this->Page->setMessage('MATCH_PASSWORD');
			redirect('c=empoyee_details&m=addDetails', 'location');
		}
		
		$arrHeader["name"]				=   $this->Page->getRequest('name');
		$arrHeader["empid"]				=   $this->Page->getRequest('empid');
          $arrHeader["email"]				=   $this->Page->getRequest('email');
		$arrHeader['status']   			=   $this->Page->getRequest('status');
 		   if($this->Page->getRequest('password') != ""){
			  $arrHeader["password"]        =  md5($this->Page->getRequest('password'));
		   }
       
		if ($strAction == 'A' || $strAction == 'R')
		{
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIp'] 		= 	$this->input->ip_address();
			$intCenterID = $this->employee_details_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
        }
		elseif ($strAction == 'E')
		{
            $detailsid			= 	$this->Page->getRequest('hid_id');
		  $arrHeader['updateBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['updateDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['updateIp'] 		= 	$this->input->ip_address();

			
            $this->employee_details_model->update($arrHeader, array('id' => $detailsid));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
		
		redirect('c=empoyee_details', 'location');
	}
	
	public function delete()
	{
		$this->employee_details_model->tbl="employee_details";
		$arrCustomerIds	=	$this->input->post('chk_lst_list1');
		$strCustomerIds	=	implode(",", $arrCustomerIds);
		$strQuery = "update employee_details set delete_flag = 1 WHERE id IN (". $strCustomerIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		// redirect to listing screen
		redirect('c=empoyee_details', 'location');
	}
   
	public function deleteImage(){
	    if ($this->Page->getRequest('id')){
        $data = array(
            'image' => null
        );
        $this->db->where('id', $this->Page->getRequest('id'));
        $this->db->update('customer_master', $data);
        if(unlink($this->Page->getRequest('filename'))){
            $strMessage	=	'<div class="msg_success">Image removed successfully</div>';
            $this->Page->setMessage($strMessage);
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
    }
	function checkEmail(){
        $field = $this->Page->getRequest("field");
        if ($field == 'txt_email'){
            $dbField = 'email';
            $returnValue = 'emailExists';
        }

        $fieldVal = $this->Page->getRequest("fieldVal");

        if ($this->Page->getRequest('id') && $this->Page->getRequest('id') != 'null'){
            $query = $this->db->get_where('employee_details', array('id' => $this->Page->getRequest('id')));
            $row = $query->row();
            if ($row->$dbField !== $fieldVal){
                $query1 = $this->db->get_where('employee_details', array($dbField => trim($fieldVal)));
                if ($query1->num_rows() > 0) {
                    echo $returnValue;
                }
            }
        }
        else {
            $query = $this->db->get_where('employee_details', array($dbField => trim($fieldVal)));
            if ($query->num_rows() > 0) {
                echo $returnValue;
            }
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */