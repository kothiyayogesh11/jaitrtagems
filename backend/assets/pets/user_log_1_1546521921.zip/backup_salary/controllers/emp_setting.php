<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emp_setting extends CI_Controller {
 
	function __construct(){
		parent::__construct();
		$this->load->model("emp_setting_model",'',true);
		
	}
	
	public function index(){
		$arrWhere	=	array();
		// Get All Customers
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "c.*,shm.code as code,shm_str.code AS code_store";
		$searchCriteria["orderField"] = "c.insertDate";
		$searchCriteria["orderDir"] = "DESC";
		$this->emp_setting_model->searchCriteria=$searchCriteria;
		$rsDetails = $this->emp_setting_model->getDetails();
		$rsListing['rsDetails']	=	$rsDetails;
		// Load Views
		$this->load->view('emp_setting/list', $rsListing);	
	}
	
   public function addDetails(){
		$this->emp_setting_model->tbl="employeesettings";
		$data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->emp_setting_model->get_by_id('id', $data["id"]);
        } else {
            $data["strAction"] = "A";
        }
		$this->load->view('emp_setting/settingForm',$data);
	}
	
	public function SaveDetails(){
		$this->emp_setting_model->tbl="employeesettings";
		$strAction = $this->input->post('action');
		
		$searchCriteria = array(); 
		
		$arrHeader["name"]				=   $this->Page->getRequest('name');
		$arrHeader["type"]				=   $this->Page->getRequest('type');
		$arrHeader["value"]				=   $this->Page->getRequest('value');
		$arrHeader["min_limit"] 		= 	$this->Page->getRequest('min_limit');
		$arrHeader["max_limit"]			=   $this->Page->getRequest('max_limit');
		$arrHeader["salary_head_code"]	=   $this->Page->getRequest('salary_head_code');
		$arrHeader["salary_head_code_store"]	=   $this->Page->getRequest('salary_head_code_store');
		$arrHeader["is_calc_on_base_salary"]	=   $this->Page->getRequest('is_calc_on_base_salary');
        $arrHeader["isRange"]			=   $this->Page->getRequest('isRange');
		$arrHeader["cal_type"]			=   $this->Page->getRequest('cal_type');
	   
		if($arrHeader['isRange'] == ''){
			$arrHeader['isRange'] = 0;
			$arrHeader["from"]		=   '';
         	$arrHeader["to"]		=   '';
		}
		if($arrHeader["isRange"] == 1){
			$arrHeader["from"]		=   $this->Page->getRequest('from');
         	$arrHeader["to"]		=   $this->Page->getRequest('to');
		}
		if ($strAction == 'A' || $strAction == 'R')
		{
            $arrHeader['insertBy']			=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();
			$intCenterID = $this->emp_setting_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
        }
		elseif ($strAction == 'E')
		{
        	$detailsid				= 	$this->Page->getRequest('hid_id');
		  	$arrHeader['updateBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['updateDate'] 	= 	date('Y-m-d H:i:s');
            $arrHeader['updateIP'] 	= 	$this->input->ip_address();
            $this->emp_setting_model->update($arrHeader, array('id' => $detailsid));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
		
		redirect('c=emp_setting', 'location');
	}
	
	public function delete()
	{
		$this->emp_setting_model->tbl="employeesettings";
		$arrCustomerIds	=	$this->input->post('chk_lst_list1');
		$strCustomerIds	=	implode(",", $arrCustomerIds);
		$strQuery = "update employeesettings set delete_flag = 1 WHERE id IN (". $strCustomerIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		// redirect to listing screen
		redirect('c=emp_setting', 'location');
	}
   
	public function deleteImage(){
	    if ($this->Page->getRequest('id')){
        $data = array(
            'image' => null
        );
        $this->db->where('id', $this->Page->getRequest('id'));
        $this->db->update('customer_master', $data);
        if(unlink($this->Page->getRequest('filename'))){
            $strMessage	=	'<div class="msg_success">Image removed successfully</div>';
            $this->Page->setMessage($strMessage);
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
    }
	function checkEmail(){
        $field = $this->Page->getRequest("field");
        if ($field == 'txt_email'){
            $dbField = 'email';
            $returnValue = 'emailExists';
        }

        $fieldVal = $this->Page->getRequest("fieldVal");

        if ($this->Page->getRequest('id') && $this->Page->getRequest('id') != 'null'){
            $query = $this->db->get_where('employee_details', array('id' => $this->Page->getRequest('id')));
            $row = $query->row();
            if ($row->$dbField !== $fieldVal){
                $query1 = $this->db->get_where('employee_details', array($dbField => trim($fieldVal)));
                if ($query1->num_rows() > 0) {
                    echo $returnValue;
                }
            }
        }
        else {
            $query = $this->db->get_where('employee_details', array($dbField => trim($fieldVal)));
            if ($query->num_rows() > 0) {
                echo $returnValue;
            }
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */