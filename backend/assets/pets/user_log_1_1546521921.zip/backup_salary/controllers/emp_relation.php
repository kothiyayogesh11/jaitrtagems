<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Emp_relation extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model("emp_relation_model", '', true);
    }
	
    public function index() {
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "insertDate";
        $searchCriteria["orderDir"] = "DESC";
        $this->emp_relation_model->searchCriteria=$searchCriteria;
        $rsRelation = $this->emp_relation_model->getRelation();
        $rsListing['rsRelation']	=	$rsRelation;
        $this->load->view('emp_relation/list', $rsListing);
    }

    public function Addrelation(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->emp_relation_model->get_by_id('id', $data["id"]);
        }else{
            $data["strAction"] = "A";
        }
        $this->load->view('emp_relation/relationFrom',$data);
    }

    public function saveRelation(){
        $strAction = $this->input->post('action');
        // Check User
       /* $searchCriteria = array();
        $searchCriteria["selectField"] = "w.workid";
        $searchCriteria["city_name"] = $this->Page->getRequest('txt_city_name');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->emp_relation_model->searchCriteria=$searchCriteria;
        $rsCityName = $this->emp_relation_model->getCityList();
        if(count($rsCityName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=city&m=addCity', 'location');
        }*/
	   
	    $searchCriteria = array();
         $searchCriteria["selectField"] = "id";
	    $searchCriteria["code"] = trim($this->Page->getRequest('code'));
	   if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
	   $this->emp_relation_model->searchCriteria=$searchCriteria;
        $rsCheckName = $this->emp_relation_model->getRelation();
        if(count($rsCheckName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=emp_relation', 'location');
        }

	   
       	$arrHeader["code"]    =	trim($this->Page->getRequest('code'));
	   	$arrHeader["name"]    =	trim($this->Page->getRequest('name'));
	   
       
		/*print_r($arrHeader);
		print_r($strAction);exit;*/
		if ($strAction == 'A' || $strAction == 'R'){
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();
            $intCenterID = $this->emp_relation_model->insert($arrHeader);		  
            $this->Page->setMessage('REC_ADD_MSG');
        } elseif ($strAction == 'E') {
			$worklocationid				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  	$arrHeader['updateIP'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');
            $update_record = $this->emp_relation_model->update($arrHeader, array('id' => $worklocationid));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
        redirect('c=emp_relation', 'location');
    }

    public function delete(){
		$arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate relationmaster set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=emp_relation', 'location');
    }
    
    function checkDeptCode(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'code'){
			$dbField = 'code';
			$returnValue = 'codeExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('relationmaster', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('relationmaster', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('relationmaster', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}

    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
			if ($query->num_rows() > 0) {
				$retstr = '';
				$retstr .="<option value='' selected>Select State</option>";
				$selectedArr = array();
				foreach ($query->result_array() as $row) {
					if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
						$selectedArr = explode(" ", $this->Page->getRequest("state_id"));
						$Val = $row["state_id"];
					}
					if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
						$sel = "selected";
					else
						$sel = "";
					$retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
				}
				echo $retstr;
			}
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
}