<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:37 PM
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class worklocation extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("worklocation_model", '', true);
    }
    public function index()
    {
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "w.insertDate";
        $searchCriteria["orderDir"] = "DESC";
        $this->worklocation_model->searchCriteria=$searchCriteria;
        $rsLocations = $this->worklocation_model->getlocation();
        $rsListing['rsLocations']	=	$rsLocations;

        // Load Views
        $this->load->view('worklocation/list', $rsListing);
    }

    public function Addworklocation()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->worklocation_model->get_by_id('id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('worklocation/locationForm',$data);
    }

    public function saveLocation()
    {
        $strAction = $this->input->post('action');

        // Check User
       /* $searchCriteria = array();
        $searchCriteria["selectField"] = "w.workid";
        $searchCriteria["city_name"] = $this->Page->getRequest('txt_city_name');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->worklocation_model->searchCriteria=$searchCriteria;
        $rsCityName = $this->worklocation_model->getCityList();
        if(count($rsCityName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=city&m=addCity', 'location');
        }*/
	   
	    $searchCriteria = array();
         $searchCriteria["selectField"] = "w.id";
	    $searchCriteria["LocationCode"] = trim($this->Page->getRequest('LocationCode'));
	   if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
	   $this->worklocation_model->searchCriteria=$searchCriteria;
        $rsDesignationName = $this->worklocation_model->getlocation();
	  // echo $this->db->last_query();exit;
        if(count($rsDesignationName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=worklocation', 'location');
        }
	   
        $arrHeader["LocationCityID"]    =	$this->Page->getRequest('LocationCityID');
        $arrHeader["LocationCode"]        = 	trim($this->Page->getRequest('LocationCode'));
        $arrHeader["LocationName"]    = 	$this->Page->getRequest('LocationName');
        $arrHeader["LocationCompany"]      = 	$this->Page->getRequest('LocationCompany');
        $arrHeader["OfficeNo"]     = 	$this->Page->getRequest('OfficeNo');

		/*print_r($arrHeader);
		print_r($strAction);exit;*/
        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['inserBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();

            $intCenterID = $this->worklocation_model->insert($arrHeader);
		  if($intCenterID){
				$insertlocatioID = $this->worklocation_model->insertlocationID($intCenterID);
		  }
		  
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $worklocationid				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  $arrHeader['updateIP'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');

            $update_record = $this->worklocation_model->update($arrHeader, array('id' => $worklocationid));
		  $insertlocatioID = $this->worklocation_model->insertlocationID($worklocationid);  
		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=worklocation', 'location');
    }

    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate worklocationmaster set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=worklocation', 'location');
    }
		
	function checkLocationCode(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'LocationCode'){
			$dbField = 'LocationCode';
			$returnValue = 'LocationCodeExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('worklocationmaster', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('worklocationmaster', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('worklocationmaster', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";

                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
}
