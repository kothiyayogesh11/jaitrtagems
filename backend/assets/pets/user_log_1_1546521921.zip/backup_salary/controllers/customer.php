<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class customer extends CI_Controller {
 
    
	function __construct(){
		parent::__construct();
		$this->load->model("customer_model",'',true);
		
	}
	
	public function index(){
		$arrWhere	=	array();
		// Get All Customers
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "cm.*";
		$searchCriteria["orderField"] = "insertdate";
		$searchCriteria["orderDir"] = "DESC";
		$this->customer_model->searchCriteria=$searchCriteria;
		$rsCustomers = $this->customer_model->getCustomers();
		$rsListing['rsCustomers']	=	$rsCustomers;
		
		// Load Views
		$this->load->view('customer/list', $rsListing);	
	}

    public function creditList(){
        $arrWhere	=	array();
        // Get All Customers
        $searchCriteria = array();
        $searchCriteria["selectField"] = "cc.*,cm.first_name as customer_name";
        $searchCriteria["orderField"] = "insertdate";
        $searchCriteria["orderDir"] = "DESC";
        $this->customer_model->searchCriteria=$searchCriteria;
        $rsCredits = $this->customer_model->getCustomersCredits();
        $rsListing['rsCredits']	= $rsCredits;

        // Load Views
        $this->load->view('customer/creditlist', $rsListing);
    }
	
	public function AddCustomer(){
		$this->customer_model->tbl="customer_master";
		$data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->customer_model->get_by_id('id', $data["id"]);
        } else {
            $data["strAction"] = "A";
        }
		$this->load->view('customer/customerForm',$data);
	}

    public function AddCustomerCredit(){
        $this->customer_model->tbl="customer_credit";
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->customer_model->get_by_id('credit_id', $data["id"]);
        }else{
            $data["strAction"] = "A";
        }
        $this->load->view('customer/customerCreditForm',$data);
    }
	
	public function SaveCustomer(){
        $imagePath = '';
        if ($_FILES['userfile']['name'] && $_FILES['userfile']['name'] != '') {
            $config['upload_path'] = './upload/user/images';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '2000';
            $config['max_width'] = '0';
            $config['max_height'] = '0';
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload()) {
                $strMessage	=	'<div class="msg_error">'.$this->upload->display_errors().'</div>';
                $this->Page->setMessage($strMessage);
                redirect('c=customer&m=addCustomer&&action=E&id='.$this->Page->getRequest('hid_id'), 'location');
                return;
            } else {
                $data = array('upload_data' => $this->upload->data());
                $imagePath = './upload/user/images/' . $data['upload_data']['orig_name'];
            }
            $arrHeader["image"]				        =   $imagePath;
        }

		$this->customer_model->tbl="customer_master";
		$strAction = $this->input->post('action');
		
		// Check Customer
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "cm.id";
		$searchCriteria["email"] = $this->Page->getRequest('txt_email');
		if ($strAction == 'E'){
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
		}
		$this->customer_model->searchCriteria=$searchCriteria;
		$rsCustomers = $this->customer_model->getCustomers();
		if(count($rsCustomers) > 0){
			$this->Page->setMessage('ALREADY_EXISTS');
			redirect('c=customer&m=addCustomer', 'location');
		}
		$arrHeader["first_name"]				=   $this->Page->getRequest('txt_first_name');
        $arrHeader["middle_name"]				=   $this->Page->getRequest('txt_middle_name');
        $arrHeader["last_name"]				    =   $this->Page->getRequest('txt_last_name');
        $arrHeader["mobile_no"]				    =   $this->Page->getRequest('txt_mobile_no');
        $arrHeader["email"]				        =   $this->Page->getRequest('txt_email');
		$arrHeader['allow_COD']					= 	$this->input->post('allow_cod') == 1 ? 1 : 0;
        if($this->Page->getRequest('txt_password') != ""){
            $arrHeader["password"]        =  md5($this->Page->getRequest('txt_password'));
        }
        $arrHeader["gender"]				    =   $this->Page->getRequest('slt_gender');
        $arrHeader["dob"]				        =   $this->Page->getRequest('txt_dob');
        $arrHeader["passport_id"]				=   $this->Page->getRequest('txt_passport_id');
        $arrHeader["nationality"]				=   $this->Page->getRequest('txt_nationality');
        $arrHeader["marital_status"]			=   $this->Page->getRequest('slt_marital_status');
		$arrHeader["address1"]     	            =	$this->Page->getRequest('txt_address1');
        $arrHeader["address2"]     	            =	$this->Page->getRequest('txt_address2');
        $arrHeader["city"]                      =   $this->Page->getRequest('slt_city');
        $arrHeader["state"]                     =   $this->Page->getRequest('slt_state');
        $arrHeader["country"]                   =   $this->Page->getRequest('slt_country');
        $arrHeader["status"]        			= 	$this->Page->getRequest('slt_status');
		
		if ($strAction == 'A' || $strAction == 'R')
		{
            $arrHeader['insertby']		=	$this->Page->getSession("intCustomerId");
            $arrHeader['insertdate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['updatedate'] 		= 	date('Y-m-d H:i:s');
			
			$intCenterID = $this->customer_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
        }
		elseif ($strAction == 'E')
		{
            $customer_id				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateby'] 		= 	$this->Page->getSession("intUserId");
            $arrHeader['updatedate'] =	date('Y-m-d H:i:s');
			
            $this->customer_model->update($arrHeader, array('id' => $customer_id));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
		
		redirect('c=customer', 'location');
	}


    public function saveCredit()
    {
        $this->customer_model->tbl="customer_credit";
        $strAction = $this->input->post('action');

        // Check Customer
        $searchCriteria = array();
        $searchCriteria["selectField"] = "cc.credit_id";
        $searchCriteria["customer_id"] = $this->Page->getRequest('slt_customer');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->customer_model->searchCriteria=$searchCriteria;
        $rsCredits = $this->customer_model->getCustomersCredits();
        if(count($rsCredits) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=customer&m=addCustomerCredit', 'addCustomerCredit');
        }
        $arrHeader["customer_id"]				=   $this->Page->getRequest('slt_customer');
        $arrHeader["credit_amount"]				=   $this->Page->getRequest('txt_amount');
        $arrHeader["allocated_on_date"]				    =   $this->Page->getRequest('txt_allocation_date');
        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertby']		=	$this->Page->getSession("intCustomerId");
            $arrHeader['insertdate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['updatedate'] 		= 	date('Y-m-d H:i:s');

            $intCenterID = $this->customer_model->insert($arrHeader);
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $customer_id				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateby'] 		= 	$this->Page->getSession("intUserId");
            $arrHeader['updatedate'] =	date('Y-m-d H:i:s');

            $this->customer_model->update($arrHeader, array('credit_id' => $customer_id));
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=customer&m=creditList', 'creditList');
    }
	
	public function delete()
	{
		$this->customer_model->tbl="customer_master";
		$arrCustomerIds	=	$this->input->post('chk_lst_list1');
		$strCustomerIds	=	implode(",", $arrCustomerIds);
		$strQuery = "DELETE FROM customer_master WHERE id IN (". $strCustomerIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		// redirect to listing screen
		redirect('c=customer', 'location');
	}

    public function deleteCredits()
    {
        $this->customer_model->tbl="customer_credit";
        $arrCustomerIds	=	$this->input->post('chk_lst_list1');
        $strCustomerIds	=	implode(",", $arrCustomerIds);
        $strQuery = "DELETE FROM customer_credit WHERE credit_id IN (". $strCustomerIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=customer&m=creditList', 'creditList');
    }

	public function deleteImage(){
	    if ($this->Page->getRequest('id')){
        $data = array(
            'image' => null
        );
        $this->db->where('id', $this->Page->getRequest('id'));
        $this->db->update('customer_master', $data);
        if(unlink($this->Page->getRequest('filename'))){
            $strMessage	=	'<div class="msg_success">Image removed successfully</div>';
            $this->Page->setMessage($strMessage);
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
    }
	function checkEmail(){
        $field = $this->Page->getRequest("field");
        if ($field == 'txt_email'){
            $dbField = 'email';
            $returnValue = 'emailExists';
        }

        $fieldVal = $this->Page->getRequest("fieldVal");

        if ($this->Page->getRequest('id') && $this->Page->getRequest('id') != 'null'){
            $query = $this->db->get_where('customer_master', array('id' => $this->Page->getRequest('id')));
            $row = $query->row();
            if ($row->$dbField !== $fieldVal){
                $query1 = $this->db->get_where('customer_master', array($dbField => trim($fieldVal)));
                if ($query1->num_rows() > 0) {
                    echo $returnValue;
                }
            }
        }
        else {
            $query = $this->db->get_where('customer_master', array($dbField => trim($fieldVal)));
            if ($query->num_rows() > 0) {
                echo $returnValue;
            }
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */