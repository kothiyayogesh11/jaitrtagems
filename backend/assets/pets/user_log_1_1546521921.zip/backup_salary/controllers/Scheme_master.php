<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Scheme_master extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("scheme_master_model",'scheme',true);
	}
	
	public function index(){
		$data['rsList'] = $this->scheme->getList();
		//pre($data);exit;
		$this->load->view('scheme/list', $data);
	}

	public function addScheme(){
		//$data['bfType'] = $this->scheme->getbftype_combo();
		
		$data["strAction"] 	= $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] 		= $this->Page->getRequest("id");

        if($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
			$data["rsEdit"] = $this->scheme->get_by_id($data["id"],true);
			$data['bf_dd'] = $this->get_beneficiary_type_list(array('type'=>@$data["rsEdit"]->beneficiary_type,'id'=>@$data["rsEdit"]->beneficiary_id));
			$data['emp_data']  = $this->get_beneficiary_employee(array('type'=>@$data["rsEdit"]->beneficiary_type,'id'=>@$data["rsEdit"]->beneficiary_id),@$data["rsEdit"]->employee_id);
        }else{
           $data["strAction"] = "A";
        }
		$this->load->view('scheme/scheme_from',$data);
	}
	
	function process(){
		//pre($this->input->post());exit;
		$scheme_id = $this->input->post('hid_id');
		$data['beneficiary_type'] 	= $this->input->post('beneficiary_type');
		$data['beneficiary_id'] 	= $this->input->post('Beneficiary');
		$data['month'] 	= $this->input->post('Month');
		$data['SchemeBase'] 	= $this->input->post('SchemeBase');
		$data['employee_id'] 	= $this->input->post('Employee');
		$data['inactive_type'] 	= $this->input->post('inactive_type');
		$data['inactive_value'] = $this->input->post('inactive_value');
		
		$errMsg = '';
		
		if($data['beneficiary_type'] == '') $errMsg .= "Beneficiary type is empty <br>";	
		if($data['beneficiary_id'] == '') $errMsg .= "Beneficiary id is empty <br>";	
		if($data['month'] == '') $errMsg .= "Month is empty <br>";	
		if($data['SchemeBase'] == '') $errMsg .= "SchemeBase is empty <br>";	
		if($data['employee_id'] == '') $errMsg .= "employee is empty <br>";	
		if($data['inactive_type'] == '') $errMsg .= "inactive_type is empty <br>";	
		
		if($errMsg != '' ){
			$this->Page->setMessage('<div class="msg_error">'.$errMsg.'</div>');
			redirect('?c=branch');
		}
		
		if($scheme_id == ''){
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertIP'] = $this->input->ip_address();
			$res = $this->scheme->addScheme($data);
			if($res){
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to add record</div>');
			}
		}else{
			
			$data['updateBy'] = $this->Page->getSession("intUserId");
			$data['updateDate'] = date('Y-m-d H:i:s');
			$data['updateIP'] = $this->input->ip_address();
			$res = $this->scheme->updateScheme($data, $scheme_id);
			if($res){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update record</div>');
			}
		}
		redirect('c=scheme_master', 'location');
	}
	
	function get_beneficiary_type_list($data = array()){
		$type = $this->input->post('type') == '' ? @$data['type'] : $this->input->post('type');
		$id = $this->input->post('id') == '' ? @$data['id'] : $this->input->post('id');
		if($type == 1){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$id,"Select Employee");
		}else if($type == 2){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_branch_master,"id","BranchName","","where delete_flag = 0",$id,"Select Branch");
		}else if($type == 3){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_designation,"id","name","","where delete_flag = 0",$id,"Select Designation");
		}else{
			$get = "<option value=''>No data found</option>";
		}
		if(isset($data) && !empty($data['id'])) return $get;
		else echo $get;
	}
	
	function get_beneficiary_employee($data = array(),$sel = NULL){
		$type = $this->input->post('type') == '' ? @$data['type'] : $this->input->post('type');
		$id = $this->input->post('id') == '' ? @$data['id'] : $this->input->post('id');
		$sel = $sel == '' ? $id : $sel;
		if($type == 1){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where id = ".$id." AND delete_flag = 0",$sel,"Select Employee");
		}else if($type == 2){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where BranchID = ".$id." AND delete_flag = 0",$sel,"Select Employee");
		}else if($type == 3){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where DesignationID = ".$id." AND delete_flag = 0",$sel,"Select Employee");
		}else{
			$get = "<option value=''>No data found</option>";
		}
		//echo $this->db->last_query();exit;
		if(isset($data) && !empty($data['id'])) return $get;
		else echo $get;
	}
	
	function delete(){
		$arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "DELETE FROM scheme_master WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        redirect('c=scheme_master', 'location');
	}
	
}