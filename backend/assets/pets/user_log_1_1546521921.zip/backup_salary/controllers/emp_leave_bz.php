<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Emp_leave extends CI_Controller{
	var $module = 'emp_leave';
    function __construct() {
	   parent::__construct();
        $this->load->model("emp_leave_model", '', true);
    }
    public function index(){
        $searchCriteria = array();
        $searchCriteria["orderField"] = "l.id";
        $searchCriteria["orderDir"] = "DESC";
        $this->emp_leave_model->searchCriteria=$searchCriteria;
        $rsLeave = $this->emp_leave_model->getLeave();
        $rsListing['rsLeave']	=	$rsLeave;
		$this->load->view('emp_leave/list', $rsListing);
    }

    public function addleave(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->emp_leave_model->get_by_id('id', $data["id"]);
        } else{
            $data["strAction"] = "A";
        }
        $this->load->view('emp_leave/leaveFrom',$data);
    }

	public function saveleave(){
		$strAction 	= $this->input->post('action');
		
		$arrHeader["employeeId"]    =	trim($this->Page->getRequest('employeeId'));
		$arrHeader["fromdate"]        =	trim($this->Page->getRequest('fromdate'));
		$arrHeader["no_of_leave"]    = 	$this->Page->getRequest('no_of_leave');
		
		if ($strAction == 'A' || $strAction == 'R'){
			$arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
			$arrHeader['insertDate'] 	= 	date('Y-m-d H:i:s');
			$arrHeader['insertIP'] 		= 	$this->input->ip_address();
			$intCenterID = $this->emp_leave_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
		}elseif ($strAction == 'E'){
			$salesID					= 	$this->Page->getRequest('hid_id');
			$arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
			$arrHeader['updateIP'] 		= 	$this->input->ip_address();
			$arrHeader['updateDate'] 	=	date('Y-m-d H:i:s');
			$update_record = $this->emp_leave_model->update($arrHeader, array('id' => $salesID));
			$this->Page->setMessage('REC_EDIT_MSG');
		}
		
		redirect('c=emp_leave', 'location');
	}

	
	
    public function delete(){
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate emp_leave set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=emp_leave', 'location');
    }
	
	function import(){
		
		error_reporting(-1);
		$fileDate = date('Y-m-d',strtotime($this->input->post('startDate')));
		$check = $this->emp_leave_model->getMonthModule($fileDate, $this->module);
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_salse';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')){
			   	$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=emp_leave', 'location');		   
            } else {
				
                $data = array('upload_data' => $this->upload->data());
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				if(!in_array($fdata['type'],array('txt','xlsx'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            		redirect('c=emp_leave', 'location');
				}
				
				$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['ModuleCode'] = $this->module;
				$fdata['Date'] = $fileDate;
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				$addFile = $this->emp_leave_model->addFileList($fdata);
				$fileID = $this->db->insert_id();
            }
			
            if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            	redirect('c=emp_leave', 'location');
			}
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            $inputFileName = $path . $import_xls_file;
			
			
			
			
			try {
				$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
				$objReader = PHPExcel_IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);
			} catch (Exception $e) {
				die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage());
			}
			
			$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
			$arrayCount = count($allDataInSheet);
			$flag = 0;
			$createArray = array('Employee Code','date','Day');
			$makeArray = array('EmployeeCode'=>'EmployeeCode','date'=>'date','Day'=>'Day');
			$SheetDataKey = array();
			foreach ($allDataInSheet as $dataInSheet) {
				foreach ($dataInSheet as $key => $value) {
					if (in_array(trim($value), $createArray)) {
						$value = preg_replace('/\s+/', '', $value);
						$SheetDataKey[trim($value)] = $key;
					} else {
						
					}
				}
			}
			
			$data = array_diff_key($makeArray, $SheetDataKey);
			if (empty($data)) $flag = 1;
			$errMsg = '';
			
			if ($flag == 1){
				$a = 1;
				for ($i = 2; $i <= $arrayCount; $i++) {
					$err 		= array();
					
					$empCode 	= $SheetDataKey['EmployeeCode'];
					$Date 		= $SheetDataKey['date'];
					$Day 		= $SheetDataKey['Day'];
					
					$tmpDate = $allDataInSheet[$i][$Date];
					
					$empCode 	= filter_var(trim($allDataInSheet[$i][$empCode]), FILTER_SANITIZE_STRING);
					$Date 		= date('Y-m-d',strtotime($tmpDate));
					$Day 		= filter_var(trim($allDataInSheet[$i][$Day]), FILTER_SANITIZE_STRING);
					
					$empData 	= $this->emp_leave_model->get_employee_by_code($empCode);
					$empID 		= isset($empData[0]['id']) ? $empData[0]['id'] : '';
					$empName 	= isset($empData[0]['EmpFullName']) ? $empData[0]['EmpFullName'] : '';
					
					if($empID == ''){
						$err['EmployeeID'] = '1';
						$empName = $empCode;
						$errMsg .= $a.' - '.$empName.' is not found <br>';
					}
					
					if(strtotime($Date) == 0){
						$err['Date'] = '1';
						$errMsg .= $a.' - Date is empty or invalide <br>';
					}
					
					if($Day == ''){
						$err['Day'] = '1';
						$errMsg .= $a.' - Day is empty <br>';
					}
					
					$fetchData[] = array('EmployeeID' => $empID, 'EmployeeName'=>$empName, 'Date' => $Date, 'Day' => $Day,'error'=>$err);
					$a++;
				}           
				
				$data['data'] = $fetchData;
				$data['fileID'] = @$fileID;
				$data['errMsg'] = $errMsg;
				$data['date'] = $fileDate;
				$data['checkDate'] = count($check);
				$this->load->view('emp_leave/import_list',$data);
			} else {
				$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
				redirect(base_url('c=emp_leave','location'));
			}
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=emp_leave', 'location');
		}
	}
	
	function import_add_process(){
		
		$employeeId = $this->input->post('EmployeeID');
		$fromdate = $this->input->post('ld_date');
		$no_of_leave = $this->input->post('Day');
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=emp_leave', 'location');
		}
		
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$check = $this->emp_leave_model->getMonthModule($date, $this->module);
		if(!empty($check)){
			foreach($check as $file){
				$this->emp_leave_model->removeOldData($file['id'],$fileID);
			}
		}
		
		for($i = 0; $i < $totalLength; $i++){
			$data['employeeId'] = $employeeId[$i];
			$data['fromdate'] = date('Y-m-d',strtotime($fromdate[$i]));
			$data['no_of_leave'] = $no_of_leave[$i];
			$data['FileID'] = $fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIp'] = $this->input->ip_address();
			$add[] = $this->emp_leave_model->addLeave($data);
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=emp_leave', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/monthlygpimport.xlsx', NULL);
	}
	
	function checkModuleUpload(){
		//error_reporting(-1);
		$date = $this->input->post('date');
		if($date == ''){
			$msg['error'] = 1;
			$msg['message'] = 'Date is empty!';
		}else{
			$check = $this->emp_leave_model->getMonthModule($date, $this->module);
			if(count($check) > 0){
				$msg['error'] = 1;
				$msg['message'] = 'This month data already added! \n Are you sure to remove and upload new data?';
			}else{
				$msg['error'] = 0;
				$msg['message'] = 'This month data already added!';
			}
		}
		echo json_encode($msg);
	}
	
}
