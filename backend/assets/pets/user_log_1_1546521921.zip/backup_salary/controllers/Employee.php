<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Employee extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("employee_model",'',true);
	}
	public function index(){
		$this->employee_model->tbl="employee_masater";
		$arrWhere	=	array();
		$searchCriteria = array();
		$searchCriteria["orderField"] = "um.insertdate";
		$searchCriteria["orderDir"] = "DESC";
		$this->employee_model->searchCriteria=$searchCriteria;
		$rsUsers = $this->employee_model->getUsers();
		$rsListing['rsUsers']	=	$rsUsers;
		$this->load->view('employee/list', $rsListing);
	}

	public function AddEmployee(){
		
		$this->employee_model->tbl="employee_masater";
		$data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->employee_model->get_by_id('id', $data["id"]);
        }else{
            $data["strAction"] = "A";
        }
		$this->load->view('employee/employeeFrom',$data);
	}

	public function saveEmp(){
		//pre($this->input->post());exit;
		$this->employee_model->tbl="employee_masater";
		$strAction = $this->input->post('action');

		$searchCriteria = array();
        $searchCriteria["selectField"] = "um.id";
	    $searchCriteria["EmpCode"] = trim($this->Page->getRequest('EmpCode'));
	    $searchCriteria["EmpExtCode"] = trim($this->Page->getRequest('EmpExtCode'));
	   	if ($strAction == 'E'){
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
	   	$this->employee_model->searchCriteria=$searchCriteria;
        $rsDesignationName = $this->employee_model->getUsers();
        if(count($rsDesignationName) > 0){
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=employee', 'location');
        }
		
		$arrHeader["EmpCode"]			= $this->Page->getRequest('EmpCode');
		$arrHeader["EmpFName"]			= $this->Page->getRequest('EmpFName');
		$arrHeader["EmpMName"]     		= $this->Page->getRequest('EmpMName');
		$arrHeader["EmpLname"]     		= $this->Page->getRequest('EmpLname');
		$arrHeader['EmpFullName']     	= $arrHeader["EmpFName"].' '.$arrHeader["EmpMName"].' '.$arrHeader['EmpLname'];
        $arrHeader["EmpExtCode"]       	= $this->Page->getRequest('EmpExtCode');
        $arrHeader["EmpWorkLocationId"] = $this->Page->getRequest('EmpWorkLocationId');
        $arrHeader["EmpDeptID"]        	= $this->Page->getRequest('EmpDeptID');
		$arrHeader["DesignationID"]    	= $this->Page->getRequest('DesignationID');
		$arrHeader["CompanyID"]        	= $this->Page->getRequest('CompanyID');
		$arrHeader["BranchID"]        	= $this->Page->getRequest('BranchID');
		$date 							= $this->Page->getRequest('date');
		$month 							= $this->Page->getRequest('month');
		$year 							= $this->Page->getRequest('year');
		$arrHeader['DOB'] 				= date('Y-m-d',strtotime($year.'-'.$month.'-'.$date)) ;
		$arrHeader["gender"]			= $this->input->post('gender');
		$arrHeader["DOJ"]        		= $this->Page->getRequest('dojdate');
		$arrHeader["DOL"]        		= $this->Page->getRequest('doldate');
		$arrHeader["BankName"]        	= $this->Page->getRequest('BankName');
		$arrHeader["BankAcNo"]        	= $this->Page->getRequest('BankAcNo');
		$arrHeader["IFSCCode"]        	= $this->Page->getRequest('IFSCCode');
		$arrHeader["WorkEmai"]        	= $this->Page->getRequest('WorkEmai');
		$arrHeader["Email"]        		= $this->Page->getRequest('Email');
		$arrHeader["Moblie"]        	= $this->Page->getRequest('Moblie');
		$arrHeader["Mobile1"]       	= $this->Page->getRequest('Moblie1');
		$arrHeader["MaritalStatus"]     = $this->Page->getRequest('MaritalStatus');
		$arrHeader["PAN"]        		= $this->Page->getRequest('PAN');
		$arrHeader["AadharNo"]        	= $this->Page->getRequest('AadharNo');
		$arrHeader["EsiNumber"]        	= $this->Page->getRequest('EsiNumber');
		$arrHeader["PFNumber"]        	= $this->Page->getRequest('PFNumber');
		$arrHeader["PFUANNo"]        	= $this->Page->getRequest('PFUANNo');
		$arrHeader["FatherHusbandName"] = $this->Page->getRequest('FatherHusbandName');
		$arrHeader["FathHusb"]        	= $this->Page->getRequest('FathHusb');
		$arrHeader["NickName"]        	= $this->Page->getRequest('NickName');
		$arrHeader["IsPPStr"]        	= $this->Page->getRequest('IsPPStr');
		$arrHeader["IsCalByEarn"]       = $this->Page->getRequest('IsCalByEarn');
		$arrHeader["prCountry"]			= $this->Page->getRequest('prCountry');
		$arrHeader["prState"]			= $this->Page->getRequest('prState');
		$arrHeader["prCity"]			= $this->Page->getRequest('prCity');
		$arrHeader["prAddress"]			= $this->Page->getRequest('prAddress');
		$arrHeader["rsCountry"]			= $this->Page->getRequest('rsCountry');
		$arrHeader["rsState"]			= $this->Page->getRequest('rsState');
		$arrHeader["rsCity"]			= $this->Page->getRequest('rsCity');
		$arrHeader["rsAddress"]			= $this->Page->getRequest('rsAddress');
		// New field for employee -- 09 / 08 / 18
		
		
		$arrHeader["status"]        	= $this->Page->getRequest('status') == 'ACTIVE' ? 1 : 0;
		
		if	($strAction == 'A' || $strAction == 'R'){
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 	= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 	= 	$this->input->ip_address();
			$intCenterID = $this->employee_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
        }else if($strAction == 'E'){
            $user_id				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 	= 	$this->Page->getSession("intUserId");
            $arrHeader['updateDate'] 	=	date('Y-m-d H:i:s');
			$arrHeader['updateIP'] 	= 	$this->input->ip_address();
            $this->employee_model->update($arrHeader, array('id' => $user_id));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
		redirect('c=employee', 'location');
	}
	
	public function delete(){
		$this->employee_model->tbl="employee_masater";
		$arrUserIds		= $this->input->post('chk_lst_list1');
		$strUserIds		= implode(",", $arrUserIds);
		$strQuery = "update employee_masater set delete_flag = 1 WHERE id IN (". $strUserIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		redirect('c=employee', 'location');
	}
	
	public function userTypesList(){
		$arrWhere	=	array();
		$rsUserTypes = $this->employee_model->getUserTypes();
		$rsListing['rsUserTypes']	=	$rsUserTypes;
		$this->load->view('user/userTypesList', $rsListing);	
	}
	
	public function addUserTypes(){
		$this->employee_model->tbl="user_types";
		$data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->employee_model->get_by_id('u_typ_id', $data["id"]);
        } else {
            $data["strAction"] = "A";
        }
		$this->load->view('user/userTypesForm',$data);
	}
	
	public function saveUserTypes(){
		$this->employee_model->tbl="user_types";
		$strAction = $this->input->post('action');
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "u_typ_id";
		$searchCriteria["userTypesName"] = $this->Page->getRequest('txt_u_typ_name');
		if ($strAction == 'E'){
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
		}
		$this->employee_model->searchCriteria=$searchCriteria;
		$rsUserTypes = $this->employee_model->getUserTypes();
		if(count($rsUserTypes) > 0){
			$this->Page->setMessage('ALREADY_EXISTS');
			redirect('c=user&m=addUserTypes', 'location');
		}
		$arrHeader["u_typ_name"]				=   $this->Page->getRequest('txt_u_typ_name');
		$arrHeader["u_typ_code"]     	=	$this->Page->getRequest('txt_u_typ_code');
        $arrHeader["u_typ_desc"]     	=	$this->Page->getRequest('txt_u_typ_desc');
        $arrHeader["status"]        			= 	$this->Page->getRequest('slt_status');
		
		if ($strAction == 'A' || $strAction == 'R'){
            $arrHeader['insertby']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertdate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['updatedate'] 		= 	date('Y-m-d H:i:s');
			$intCenterID = $this->employee_model->insert($arrHeader);
			$intCenterID;
			$this->Page->setMessage('REC_ADD_MSG');
        }elseif ($strAction == 'E'){
            $u_typ_id				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateby'] 		= 	$this->Page->getSession("intUserId");
            $arrHeader['updatedate'] =	date('Y-m-d H:i:s');
            $this->employee_model->update($arrHeader, array('u_typ_id' => $u_typ_id));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
		
		redirect('c=user&m=userTypesList', 'location');
	}
	
	public function deleteUserTypes(){
		$arrUserTypesIds	=	$this->input->post('chk_lst_list1');
		$strUserTypesIds	=	implode(",", $arrUserTypesIds);
		$strQuery = "DELETE FROM user_types WHERE u_typ_id IN (". $strUserTypesIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		redirect('c=user&m=userTypesList', 'location');
	}
	
	function checkEmployeeCode(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'EmpCode'){
			$dbField = 'EmpCode';
			$returnValue = 'EmpCodeExists';
		}else if ($field == 'EmpExtCode'){
			$dbField = 'EmpExtCode';
			$returnValue = 'EmpExtCodeExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('employee_masater', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('employee_masater', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('employee_masater', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
	function active_welcome_mail(){
		$data['userList'] = $this->employee_model->getFailedWelcomeMail();
		$this->load->view('user/welcome_mail_list',$data);
	}
	
	function activeFauledMailCustomer(){
		$id = $this->input->post('id');
		if($id != ''){
			$res = $this->employee_model->activeFauledMailCustomer($id);
			$msg = $res ? array('error'=>0) : array('error'=>1);
		}else{
			$msg = array('error'=>1);
		}
		echo json_encode($msg);
	}
	
	function getDepByCompany(){
		$compID = $this->input->post('compID');
		$id = $this->input->post('EmpDeptID');
		if($compID != ''){
			$where = " where delete_flag = 0 AND ToComp = ".$compID;
			echo $this->Page->generateComboByTable("departmentmaster","id","Name","",$where,$id,"Select Department");
		}
	}
	
	function excel(){
		require(APPPATH . '/third_party/PHPExcel-1.8/Classes/PHPExcel.php');
		require(APPPATH . '/third_party/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');
		
		$data = array(
			array('task_id' => 1,'user_id' => 12,'task' => 'task 1','date_added' => date('Y-m-d H:i:s'),'date_modified' => date('Y-m-d H:i:s')),
			array('task_id' => 2,'user_id' => 13,'task' => 'task 2','date_added' => date('Y-m-d H:i:s'),'date_modified' => date('Y-m-d H:i:s')),
			array('task_id' => 3,'user_id' => 14,'task' => 'task 3','date_added' => date('Y-m-d H:i:s'),'date_modified' => date('Y-m-d H:i:s')),
			array('task_id' => 4,'user_id' => 15,'task' => 'task 4','date_added' => date('Y-m-d H:i:s'),'date_modified' => date('Y-m-d H:i:s')),
			array('task_id' => 5,'user_id' => 16,'task' => 'task 5','date_added' => date('Y-m-d H:i:s'),'date_modified' => date('Y-m-d H:i:s')),
			array('task_id' => 6,'user_id' => 17,'task' => 'task 6','date_added' => date('Y-m-d H:i:s'),'date_modified' => date('Y-m-d H:i:s'))
		);
		
		$excel = new PHPExcel();
		$excel->getProperties()->setCreator("");
		$excel->getProperties()->setLastModifiedBy("");
		$excel->getProperties()->setTitle("");
		$excel->getProperties()->setSubject("");
		$excel->getProperties()->setDescription("");
		
		$excel->setActiveSheetIndex(0);
		
		$excel->getActiveSheet()->SetCellValue('A1','Task ID');
		$excel->getActiveSheet()->SetCellValue('B1','User ID');
		$excel->getActiveSheet()->SetCellValue('C1','Task');
		
		$excel->getActiveSheet()->SetCellValue('D1','Date End');
		$excel->getActiveSheet()->SetCellValue('E1','Date Changed');
		
		$row = 2;
		
		foreach($data as $key => $val){
			$excel->getActiveSheet()->SetCellValue('A'.$row,$val['task_id']);
			$excel->getActiveSheet()->SetCellValue('B'.$row,$val['user_id']);
			$excel->getActiveSheet()->SetCellValue('C'.$row,$val['task']);
			$excel->getActiveSheet()->SetCellValue('D'.$row,date('Y-m-d',strtotime($val['date_added'])));
			$excel->getActiveSheet()->SetCellValue('E'.$row,date('Y-m-d',strtotime($val['date_modified'])));
			
			$row++;
		}
		
		$fname = 'excel'.time().'.xlsx';
		$excel->getActiveSheet()->setTitle("Excel Tut");
		
		header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		header("Content-Disposition: attachment;filename='".$fname."'");
		header("Cache-Control: max-age=0");
		
		$writer = PHPExcel_IOFactory::createWriter($excel,'Excel2007');
		$writer->save('php://output');
		exit;
	}
	
	function getstate_by_country(){
		$id = $this->input->post('id');
		$state_id = (string) @$this->input->post('state_id');
		$rsStateWhere = "where status = 'ACTIVE' AND country_id = ".$id." ";
		$state_option = $this->Page->generateComboByTable("state_master","state_id","state_name","",$rsStateWhere,$state_id,"Select State");
		$error = $state_option != '' ? 0 : 1;
		$data['error'] = $error;
		$data['option'] = $state_option;
		json($data,200);
	}
	
	function getcity_by_state(){
		$id = $this->input->post('id');
		$state_id = $this->input->post('state_id');
		$city_id = $this->input->post('city_id');
		$rsCityIDWhere = "where status = 'ACTIVE' AND country_id = ".$id." AND state_id = ".$state_id;
		$state_option = $this->Page->generateComboByTable("city_master","city_id","city_name","",$rsCityIDWhere,$city_id,"Select City");
		$error = $state_option != '' ? 0 : 1;
		$data['error'] = $error;
		$data['option'] = $state_option;
		json($data,200);
	}
}