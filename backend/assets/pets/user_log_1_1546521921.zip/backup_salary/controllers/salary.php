<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Salary extends CI_Controller{
	var $module = 'salary_details';
	var $datetime;
	var $user_id;
	var $ip;
    function __construct(){
        parent::__construct();
		$this->datetime = date('Y-m-d H:i:s');
		$this->user_id = $this->session->userdata('sess_intUserId');
		$this->ip = $this->input->ip_address();
        $this->load->model("salary_model", '', true);
        $this->load->model("salary_monthly_head_model",'salary_monthly_head_model',true);
    }
	
    public function index(){
        $searchCriteria = array();
        $searchCriteria["orderField"] = "s.id";
        $searchCriteria["orderDir"] = "DESC";
        $this->salary_model->searchCriteria=$searchCriteria;
        $rsSalary = $this->salary_model->getSalary();
        $rsListing['rsSalary']	=	$rsSalary;
        $this->load->view('salary/list', $rsListing);
    }

    public function Addsalary(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->salary_model->get_by_id('id', $data["id"]);
        } else {
            $data["strAction"] = "A";
        }
        $this->load->view('salary/salaryForm',$data);
    }

	public function saveSalary(){
       	$strAction = $this->input->post('action');	   
       	$arrHeader["empID"]    =	trim($this->Page->getRequest('empID'));
	   	$arrHeader["salary"]    =	trim($this->Page->getRequest('salary'));
		$arrHeader['totalsalary'] =  trim($this->Page->getRequest('totalsalary'));
	   	$arrHeader["commitmentSalary"]    =	$this->Page->getRequest('commitmentSalary');
		
		$arrHeader["conveyence_allowence"]    =	$this->Page->getRequest('conveyence_allowence');
		$arrHeader["standard_allowence"]    =	$this->Page->getRequest('standard_allowence');
		$arrHeader["special_allowence"]    =	$this->Page->getRequest('special_allowence');
		
	   	$arrHeader["startDate"]    =	$this->Page->getRequest('startDate');
	   	//$arrHeader["endDate"]    =	$this->Page->getRequest('endDate');
	   	$arrHeader["isLast"]    =	1;
	   	$arrHeader["isFix"]    =	$this->Page->getRequest('isFix');
		
		/* New field added from 14-08-18*/
		$arrHeader["TDS "]        	= $this->Page->getRequest('TDS');
		$arrHeader["PF"]        	= $this->Page->getRequest('PF');
		$arrHeader["ESI"] 			= $this->Page->getRequest('ESI');
		$arrHeader["HRA"]        	= $this->Page->getRequest('HRA');
		$arrHeader["SPLALL"]        = $this->Page->getRequest('SPLALL');
		$arrHeader["INC"]        	= $this->Page->getRequest('INC');
		$arrHeader["Trans"]       	= $this->Page->getRequest('Trans');
		$arrHeader["PTAX"]       	= $this->Page->getRequest('PTAX');

        // get employee details form id
		$getEmpData = $this->salary_monthly_head_model->get_employee_by_id($this->Page->getRequest('empID'));
	  	$arrHeader["branchID"] 		= @$getEmpData[0]['BranchID'];
		$arrHeader["compID"] 		= @$getEmpData[0]['CompanyID'];
	   	/*$startdate=strtotime($arrHeader["startDate"]);
	   	$enddate=strtotime($arrHeader["endDate"]);

		if($startdate > $enddate){
			$this->Page->setMessage('<div class="msg_error">Start date should not be greater than end date</div>');
            redirect('c=salary&m=Addsalary', 'location');
		}*/
		
        if ($strAction == 'A' || $strAction == 'R'){
			if($arrHeader["empID"] != ''){
				$update_Salary_last = $this->salary_model->update_is_last(array('empID' => $arrHeader["empID"],'isLast'=>1)); 
		  	}
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();
            $intCenterID = $this->salary_model->insert($arrHeader);	  
            $this->Page->setMessage('REC_ADD_MSG');
        } elseif ($strAction == 'E') {
			$worklocationid				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  	$arrHeader['updateIP'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');
            $update_record = $this->salary_model->update($arrHeader, array('id' => $worklocationid));		  		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=salary', 'location');
    }
	
    public function delete(){
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate emp_salary_detail set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        redirect('c=salary', 'location');
    }
	
	function import(){
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')) {
               echo $this->upload->display_errors();  exit;
            } else {
                $data = array('upload_data' => $this->upload->data());
            	$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				$fdata['ModuleCode'] = $this->module;
				$fdata['Date'] = date('Y-m-d');
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				$addFile = $this->salary_model->addFileList($fdata);
				$fileID = $this->db->insert_id();
            }
            if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            	redirect('c=salary', 'location');
			}
            
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            $inputFileName = $path . $import_xls_file;
            try {
				
                $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
                $objReader = PHPExcel_IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch (Exception $e) {
                die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME)
                        . '": ' . $e->getMessage());
            }
            $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
            
            $arrayCount = count($allDataInSheet);
            $flag = 0;
            $createArray = array('EmpCode', 'BasicSalary','HRA','TotalSalary','ConveyenceAllowence','StandardAllowence','SpecialAllowence','CommitmentSalary','StartDate','isFix','TDS','PF','ESI','SPLALL','INC','Trans','PTAX');
            $makeArray = array('EmpCode'=>'EmpCode', 'BasicSalary'=>'BasicSalary','HRA'=>'HRA','TotalSalary'=>'TotalSalary','ConveyenceAllowence'=>'ConveyenceAllowence','StandardAllowence'=>'StandardAllowence','SpecialAllowence'=>'SpecialAllowence','CommitmentSalary'=>'CommitmentSalary','StartDate'=>'StartDate','isFix'=>'isFix','TDS'=>'TDS','PF'=>'PF','ESI'=>'ESI','SPLALL'=>'SPLALL','INC'=>'INC','Trans'=>'Trans','PTAX'=>'PTAX');
            $SheetDataKey = array();

            foreach ($allDataInSheet as $dataInSheet) {
                foreach ($dataInSheet as $key => $value) {
                    if (in_array(trim($value), $createArray)) {
                        $value = preg_replace('/\s+/', '', $value);
                        $SheetDataKey[trim($value)] = $key;
                    }
                }
            }

            $data = array_diff_key($makeArray, $SheetDataKey);
            if (empty($data))  $flag = 1;
            $fetchData = array();
			$err = array();
			$errMsg = '';
			if ($flag == 1) {
				$a = 1;
                for ($i = 2; $i <= $arrayCount; $i++) {
                    $addresses = array();
					
                    $EmpCode 				= $SheetDataKey['EmpCode'];
					$BasicSalary 			= $SheetDataKey['BasicSalary'];
					$TotalSalary 			= $SheetDataKey['TotalSalary'];
					$HRA 					= $SheetDataKey['HRA'];
                    $ConveyenceAllowence 	= $SheetDataKey['ConveyenceAllowence'];
                    $StandardAllowence 		= $SheetDataKey['StandardAllowence'];
					$SpecialAllowence 		= $SheetDataKey['SpecialAllowence'];
					$CommitmentSalary 		= $SheetDataKey['CommitmentSalary'];
                    $StartDate 				= $SheetDataKey['StartDate'];
                    $isFix 					= $SheetDataKey['isFix'];
					$TDS 					= $SheetDataKey['TDS'];
					$PF 					= $SheetDataKey['PF'];
                    $ESI 					= $SheetDataKey['ESI'];
                    $SPLALL 				= $SheetDataKey['SPLALL'];
					$INC 					= $SheetDataKey['INC'];
					$Trans 					= $SheetDataKey['Trans'];
					$PTAX 					= $SheetDataKey['PTAX'];
					
                    $EmpCode 				= filter_var(trim($allDataInSheet[$i][$EmpCode]), FILTER_SANITIZE_STRING);
					$BasicSalary 			= filter_var(trim($allDataInSheet[$i][$BasicSalary]), FILTER_SANITIZE_STRING);
					$TotalSalary 			= filter_var(trim($allDataInSheet[$i][$TotalSalary]), FILTER_SANITIZE_STRING);
                    $HRA 					= filter_var(trim($allDataInSheet[$i][$HRA]), FILTER_SANITIZE_STRING);
					$ConveyenceAllowence 	= filter_var(trim($allDataInSheet[$i][$ConveyenceAllowence]), FILTER_SANITIZE_STRING);
                    $StandardAllowence 		= filter_var(trim($allDataInSheet[$i][$StandardAllowence]), FILTER_SANITIZE_STRING);
					$SpecialAllowence 		= filter_var(trim($allDataInSheet[$i][$SpecialAllowence]), FILTER_SANITIZE_STRING);
					$CommitmentSalary 		= filter_var(trim($allDataInSheet[$i][$CommitmentSalary]), FILTER_SANITIZE_STRING);
                    $StartDate 				= date('Y-m-d',strtotime(filter_var(trim($allDataInSheet[$i][$StartDate]), FILTER_SANITIZE_STRING)));
					$isFix 					= filter_var(trim($allDataInSheet[$i][$isFix]), FILTER_SANITIZE_STRING);
					$TDS 					= filter_var(trim($allDataInSheet[$i][$TDS]), FILTER_SANITIZE_STRING);
                    $PF 					= filter_var(trim($allDataInSheet[$i][$PF]), FILTER_SANITIZE_STRING);
                    $ESI 					= filter_var(trim($allDataInSheet[$i][$ESI]), FILTER_SANITIZE_STRING);
					$SPLALL 				= filter_var(trim($allDataInSheet[$i][$SPLALL]), FILTER_SANITIZE_STRING);
					$INC 					= filter_var(trim($allDataInSheet[$i][$INC]), FILTER_SANITIZE_STRING);
					$Trans 					= filter_var(trim($allDataInSheet[$i][$Trans]), FILTER_SANITIZE_STRING);
					$PTAX 					= filter_var(trim($allDataInSheet[$i][$PTAX]), FILTER_SANITIZE_STRING);
					
					$empData = $this->salary_model->get_employee_by_code($EmpCode);

					if($EmpCode == ''){
						$err['EmpCode']['error'] = 1;
						$errMsg .= $a.' - EmpCode is empty. <br>';
					}
					
					$empID 		= @$empData[0]['id'];
					$empName 	= @$empData[0]['EmpFullName'];
                    $branchID = isset($empData[0]['BranchID']) ? $empData[0]['BranchID'] : '';
                    $compID = isset($empData[0]['CompanyID']) ? $empData[0]['CompanyID'] : '';
					if($empID == ''){
						$err['EmpCode']['error'] = 1;
						$errMsg .= $a.' - EmpCode is invalide. <br>';
					}

					if($branchID == ''){
						$err['BranchCode']['error'] = 1;
						$errMsg .= $a.' - Employee branch not found. <br>';
					}

					if($compID == ''){
						$err['CompanyCode']['error'] = 1;
						$errMsg .= $a.' - employee company not found. <br>';
					}
					
					if($HRA == ''){
						$err['HRA']['error'] = 1;
						$errMsg .= $a.' - HRA is empty. <br>';
					}
					
					if($BasicSalary == ''){
						$err['BasicSalary']['error'] = 1;
						$errMsg .= $a.' - Basic Salary is empty. <br>';
					}
					
					if($TotalSalary == ''){
						$err['TotalSalary']['error'] = 1;
						$errMsg .= $a.' - Total salary is empty. <br>';
					}
					
					if($ConveyenceAllowence == ''){
						$err['ConveyenceAllowence']['error'] = 1;
						$errMsg .= $a.' - Conveyence Allowence is empty. <br>';
					}
					
					if($StandardAllowence == ''){
						$err['StandardAllowence']['error'] = 1;
						$errMsg .= $a.' - Standard Allowence is empty. <br>';
					}
					
					if($SpecialAllowence== ''){
						$err['SpecialAllowence']['error'] = 1;
						$errMsg .= $a.' - Special Allowence is empty. <br>';
					}
					
					if($CommitmentSalary== ''){
						$err['CommitmentSalary']['error'] = 1;
						$errMsg .= $a.' - Commitment Salary is empty. <br>';
					}
					
					if(strtotime($StartDate) == 0){
						$err['StartDate']['error'] = 1;
						$errMsg .= $a.' - Start Date is empty or invalide. <br>';
					}
					
					
					if($isFix== ''){
						$err['isFix']['error'] = 1;
						$errMsg .= $a.' - isFix is empty. <br>';
					}
					
					if($TDS == ''){
						$err['TDS']['error'] = 1;
						$errMsg .= $a.' - TDS is empty. <br>';
					}
					
					if($PF == ''){
						$err['PF']['error'] = 1;
						$errMsg .= $a.' - PF is empty. <br>';
					}
					
					if($ESI == ''){
						$err['ESI']['error'] = 1;
						$errMsg .= $a.' - ESI is empty. <br>';
					}
					
					if($SPLALL == ''){
						$err['SPLALL']['error'] = 1;
						$errMsg .= $a.' - SPLALL is empty. <br>';
					}
					
					if($INC == ''){
						$err['INC']['error'] = 1;
						$errMsg .= $a.' - INC is empty. <br>';
					}
					
					if($Trans == ''){
						$err['Trans']['error'] = 1;
						$errMsg .= $a.' - Trans is empty. <br>';
					}
					
					if($PTAX == ''){
						$err['PTAX']['error'] = 1;
						$errMsg .= $a.' - PTAX is empty. <br>';
					}
					
					$fetchData[] = array('EmpCode' => $EmpCode, 'empID' => $empID, 'empName' => $empName, 'branchID'=>$branchID, 'compID'=>$compID, 'BasicSalary'=>$BasicSalary, 'TotalSalary'=>$TotalSalary, 'HRA'=>$HRA, 'ConveyenceAllowence'=>$ConveyenceAllowence, 'StandardAllowence'=>$StandardAllowence, 'SpecialAllowence'=>$SpecialAllowence, 'CommitmentSalary'=>$CommitmentSalary, 'StartDate'=>$StartDate, 'isFix'=>$isFix, 'TDS'=>$TDS, 'PF'=>$PF, 'ESI'=>$ESI, 'SPLALL'=>$SPLALL, 'INC'=>$INC, 'Trans'=>$Trans, 'PTAX'=>$PTAX, 'error'=>$err);
					$a++;
                }
               
				$data['list'] = $fetchData;
				$data['errMsg'] = $errMsg;
				$data['fileID'] = $fileID;
				$this->load->view('salary/import_list',$data);
            } else {
				$this->Page->setMessage('<div class="msg_error">Invalide key added in file!</div>');
				redirect('c=salary', 'location');
            }
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=salary', 'location');
		}
	}
	
	function import_add_process(){
		$empID = $this->input->post('empID');
		$branchID = $this->input->post('branchID');
		$compID = $this->input->post('compID');
		$BasicSalary = $this->input->post('BasicSalary');
		$TotalSalary = $this->input->post('TotalSalary');
		$HRA = $this->input->post('HRA');
		$ConveyenceAllowence = $this->input->post('ConveyenceAllowence');
		$StandardAllowence = $this->input->post('StandardAllowence');
		$SpecialAllowence = $this->input->post('SpecialAllowence');
		$CommitmentSalary = $this->input->post('CommitmentSalary');
		$StartDate = $this->input->post('StartDate');
		$isFix = $this->input->post('isFix');
		$TDS = $this->input->post('TDS');
		$PF = $this->input->post('PF');
		$ESI = $this->input->post('ESI');
		$SPLALL = $this->input->post('SPLALL');
		$INC = $this->input->post('INC');
		$Trans = $this->input->post('Trans');
		$PTAX = $this->input->post('PTAX');
		
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=salary', 'location');
		}
		for($i = 0; $i < $totalLength; $i++){
			$data['empID'] = @$empID[$i];
			$this->salary_model->updateLastRec(array('isLast'=>0,'endDate'=>date('Y-m-d')),array('empID'=>$data['empID'],'isLast'=>1));
			$data['branchID'] = @$branchID[$i];
			$data['compID'] = @$compID[$i];
			$data['salary'] = @$BasicSalary[$i];
			$data['totalsalary'] = @$TotalSalary[$i];
			$data['HRA'] = @$HRA[$i];
			$data['conveyence_allowence'] = @$ConveyenceAllowence[$i];
			$data['standard_allowence'] = @$StandardAllowence[$i];
			$data['special_allowence'] = @$SpecialAllowence[$i];
			$data['commitmentSalary'] = @$CommitmentSalary[$i];
			$data['startDate'] = date('y-m-d',strtotime(@$StartDate[$i]));
			$data['isFix'] = strtolower(@$isFix[$i]) == 'yes' ? 1 : 0;
			$data['TDS'] = strtolower(@$TDS[$i]) == 'yes' ? 1 : 0;
			$data['PF'] = strtolower(@$PF[$i]) == 'yes' ? 1 : 0;;
			$data['ESI'] = strtolower(@$ESI[$i]) == 'yes' ? 1 : 0;;
			$data['SPLALL'] = strtolower(@$SPLALL[$i]) == 'yes' ? 1 : 0;;
			$data['INC'] = strtolower(@$INC[$i]) == 'yes' ? 1 : 0;;
			$data['Trans'] = strtolower(@$Trans[$i]) == 'yes' ? 1 : 0;;
			$data['PTAX'] = strtolower(@$PTAX[$i]) == 'yes' ? 1 : 0;;
			
			$data['FileID'] = @$fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIP'] = $this->input->ip_address();
			$data['isLast'] = 1;
			$add[] = $this->salary_model->addImportSalary($data);
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=salary', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/salaryimport.xlsx', NULL);
	}
}
