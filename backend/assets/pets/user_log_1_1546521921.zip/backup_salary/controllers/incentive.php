<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class incentive extends CI_Controller{
	var $modual = "incentive";
	var $salesPerson = "";
	var $branchName;
    function __construct(){
        parent::__construct();
        $this->load->model("incentive_model", '', true);
    }
	
    public function index(){
        $searchCriteria = array();
        $searchCriteria["orderField"] = "ms.id";
        $searchCriteria["orderDir"] = "DESC";
        $this->incentive_model->searchCriteria=$searchCriteria;
        $rsSales = $this->incentive_model->getincentive();
	   $rsListing['rsSales']	=	$rsSales;
        $this->load->view('incentive/list', $rsListing);
    }

   
	function import(){
		$startDate = $this->input->post('startDate');
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_incentive';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')) {
               	$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=incentive', 'location');
            } else {
                $data = array('upload_data' => $this->upload->data());
				$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				$fdata['ModuleCode'] = $this->modual;
				$fdata['Date'] = date('Y-m-d');
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				
				if(!in_array($fdata['type'],array('txt'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            		redirect('c=incentive', 'location');
				}
				
				$addFile = $this->incentive_model->addFileList($fdata);
				$fileID = $this->db->insert_id();
            }
			
            if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            	redirect('c=incentive', 'location');
			}
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            
			$inputFileName = $path . $import_xls_file;
			
			if(@$fdata['type'] == 'txt'){
				$txt = file_get_contents($inputFileName);
				$convert = explode("\n", $txt);
                //echo count($convert);die;
				$length = count($convert);
				if(empty($convert)){
					$this->Page->setMessage('<div class="msg_error">File is empty</div>');
            		redirect('c=incentive', 'location');
				}
				$a = 1;
				$BranchID = '';
				$empID = '';
                
                //Get All employee Ravi
                $EmpArryByName = array();
                $EmpArryById = array();
                //error_reporting(-1);
                $AllEmpArrByName = $this->incentive_model->getAllEmpbyNaame();
                foreach($AllEmpArrByName as $EMprec)
                {
                    $EmpArryByName[strtolower(trim($EMprec['EmpFullName']))] =  $EMprec['id'];
                    $EmpArryById[$EMprec['id']] =  $EMprec['EmpFullName'];
                }
                
                
                // Get All Branch Ravi
                $BranchArryByName = array();
                $BranchArryByid = array();
                //error_reporting(-1);
                $AllBraanchArrByName = $this->incentive_model->getAllBranchbyAPXNaame();
                foreach($AllBraanchArrByName as $Branchrec)
                {
                    $BranchArryByName[$Branchrec['BranchAPXName']] =  $Branchrec['id'];
                    $BranchArryByid[$Branchrec['id']] =  $Branchrec['BranchAPXName'];
                }
                
                $errMsg="";
				for($i = 0; $i <= $length; $i++){
					if(!empty($convert[$i]) && $i > 4){
						
                        $err = array();
						$txtData = explode("\t",$convert[$i]);
						if(empty($txtData))	continue;
						if(
							in_array('Total',explode(' ',$txtData[0])) || in_array('Total',explode(' ',$txtData[1])) || 
							in_array('Total',explode(' ',$txtData[2])) || in_array('Total',explode(' ',$txtData[3])) ||
							in_array('Total',explode(' ',$txtData[4])) || in_array('Total',explode(' ',$txtData[5])) ||
							in_array('Total',explode(' ',$txtData[6])) || in_array('Total',explode(' ',$txtData[7])) || 
							in_array('Total',explode(' ',$txtData[8])) || in_array('Total',explode(' ',$txtData[9])) || 
							in_array('Total',explode(' ',$txtData[10])) || in_array('Total',explode(' ',$txtData[11]))
						) continue;
						
						if(strtolower(trim($txtData[3])) == strtolower('Grand Total')) continue;
						
						if($txtData[0] != ''){
							$this->branchName = $txtData[0];
							$BranchID = isset($BranchArryByName[$this->branchName])? $BranchArryByName[$this->branchName] : NULL;
						}
						
						if($BranchID != '' && trim($txtData[1]) != ''){
							$this->salesPerson = strtolower(trim($txtData[1]));
							//$userData = $this->incentive_model->getEmployeeIdByName($this->salesPerson);
							//$empID = @$userData[0]['id'] != '' ? @$userData[0]['id'] : NULL;
                            $empID = isset($EmpArryByName[$this->salesPerson])? $EmpArryByName[$this->salesPerson] : NULL;
						}
												
						$scheme = @$txtData[3];
						$qty = @$txtData[6];
						$benefit_amt = @$txtData[10];
						
						if($BranchID == ''){
							$err['BranchID'] = '1';
							$errMsg .= $a.' - Branch is Blanck <br>';
						}else{
							//$checkBrach = $this->incentive_model->getBranchById($BranchID);
							if(!isset($BranchArryByid[$BranchID])){
								$err['BranchID'] = '1';
								$errMsg .= $a.' - Branch Name not Found in Master<br>';
							}
						}
						
						if($empID == ''){
                            //echo $this->salesPerson;die;
							$err['empID'] = '1';
							$errMsg .= $a." - ".$this->salesPerson.' - Employee is not found <br>';
						}
						
						if($scheme == ''){
							$err['scheme'] = '1';
							$errMsg .= $a.' - scheme is empty <br>';
						}
						
						if($qty == ''){
							$err['qty'] = '1';
							$errMsg .= $a.' - qty is empty<br>';
						}
						
						if($benefit_amt == ''){
							$err['benefit_amt'] = '1';
							$errMsg .= $a.' - benefit_amt is empty<br>';
						}
						
						$fetchData[] = array('BranchID' => $BranchID, 'BranchName' => $BranchArryByid[$BranchID], 'empID' => $empID, 'EmpName' => $EmpArryById[$empID], 'scheme' => $scheme, 'qty' => $qty, 'benefit_amt' => $benefit_amt,'error'=>$err);
						$a++;
					}
				}
			}
			$data['data'] = $fetchData;
			$data['fileID'] = @$fileID;
			$data['errMsg'] = $errMsg;
			$data['date'] = $startDate;
			//pre($data);exit;
			$this->load->view('incentive/import_list',$data);
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=incentive', 'location');
		}
	}
	
	function import_add_process(){
		
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$fileID = $this->input->post('fileID');
		$getFileData = $this->incentive_model->getFileDataByFileID($fileID);
		
		if($fileID == '' && isset($getFileData[0])){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=incentive', 'location');
		}
		
		$path = '../upload/csv/';		
		$import_file = $getFileData[0];
		$inputFileName = $path . $import_file['file'];
		
		if(@$import_file['type'] == 'txt'){
			$txt = file_get_contents($inputFileName);
			$convert = explode("\n", $txt);

			$length = count($convert);
			if(empty($convert)){
				$this->Page->setMessage('<div class="msg_error">File is empty</div>');
				redirect('c=incentive', 'location');
			}
			$a = 1;
			$BranchID = '';
			$empID = '';
			
			//Get All employee Ravi
			$EmpArryByName = array();
			$EmpArryById = array();
			//error_reporting(-1);
			$AllEmpArrByName = $this->incentive_model->getAllEmpbyNaame();
			foreach($AllEmpArrByName as $EMprec)
			{
				$EmpArryByName[strtolower(trim($EMprec['EmpFullName']))] =  $EMprec['id'];
				$EmpArryById[$EMprec['id']] =  $EMprec['EmpFullName'];
			}
			
			
			// Get All Branch Ravi
			$BranchArryByName = array();
			$BranchArryByid = array();
			//error_reporting(-1);
			$AllBraanchArrByName = $this->incentive_model->getAllBranchbyAPXNaame();
			foreach($AllBraanchArrByName as $Branchrec)
			{
				$BranchArryByName[$Branchrec['BranchAPXName']] =  $Branchrec['id'];
				$BranchArryByid[$Branchrec['id']] =  $Branchrec['BranchAPXName'];
			}
			
			
			for($i = 0; $i <= $length; $i++){
				if(!empty($convert[$i]) && $i > 4){
					$txtData = explode("\t",$convert[$i]);
					if(empty($txtData))	continue;
					if(
						in_array('Total',explode(' ',$txtData[0])) || in_array('Total',explode(' ',$txtData[1])) || 
						in_array('Total',explode(' ',$txtData[2])) || in_array('Total',explode(' ',$txtData[3])) ||
						in_array('Total',explode(' ',$txtData[4])) || in_array('Total',explode(' ',$txtData[5])) ||
						in_array('Total',explode(' ',$txtData[6])) || in_array('Total',explode(' ',$txtData[7])) || 
						in_array('Total',explode(' ',$txtData[8])) || in_array('Total',explode(' ',$txtData[9])) || 
						in_array('Total',explode(' ',$txtData[10])) || in_array('Total',explode(' ',$txtData[11]))
					) continue;
					
					if(strtolower(trim($txtData[3])) == strtolower('Grand Total')) continue;
					
					if($txtData[0] != ''){
						$this->branchName = $txtData[0];
						$BranchID = isset($BranchArryByName[$this->branchName])? $BranchArryByName[$this->branchName] : NULL;
					}
					
					if($BranchID != '' && trim($txtData[1]) != ''){
						$this->salesPerson = strtolower(trim($txtData[1]));
						$empID = isset($EmpArryByName[$this->salesPerson])? $EmpArryByName[$this->salesPerson] : NULL;
					}
					
					if($empID == ''){
						continue;
					}
						
					if($BranchID == ''){
						continue;
					}
											
					$scheme = @$txtData[3];
					$qty = @$txtData[6];
					$benefit_amt = @$txtData[10];
					
					$insertDate = date('Y-m-d H:i:s');
					$insertBy = $this->Page->getSession("intUserId");
					$insertIp = $this->input->ip_address();
					
					$fetchData[] = array(
						'BranchID' => $BranchID, 
						'empID' => $empID,
						'scheme' => $scheme,
						'qty' => $qty,
						'benefit_amt' => floatval(str_replace(array("'",","),'',$benefit_amt)),
						'Date'=>$date,
						'FileID'=>$fileID,
						'EntryType'=>1,
						'insertDate'=>$insertDate,
						'insertBy'=>$insertBy,
						'insertIp'=>$insertIp
					);
					$a++;
				}
			}
		}
		
		
		
		$check = $this->incentive_model->getMonthModule($date, $this->modual);
		if(!empty($check)){
			foreach($check as $file){
				$this->incentive_model->removeOldData($file['id'],$fileID);
			}
		}
		
		if(isset($fetchData) && !empty($fetchData)){
			$ins_flag = $this->incentive_model->batch_insert_incentive($fetchData);
		}else{
			$ins_flag = FALSE;
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=incentive', 'location');
	}
	
	function report(){
		$data['rsSales'] = $this->incentive_model->getALLEmployeeIncentive();
		$this->load->view('incentive/report',$data);
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/incentive_main.txt', NULL);
	}
}
