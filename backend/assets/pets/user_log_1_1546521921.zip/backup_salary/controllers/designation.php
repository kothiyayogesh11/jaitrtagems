<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:37 PM
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class designation extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("designation_model", '', true);
    }
    public function index()
    {
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "insertDate";
        $searchCriteria["orderDir"] = "DESC";
        $this->designation_model->searchCriteria=$searchCriteria;
        $rsDesignation = $this->designation_model->getdesignation();
        $rsListing['rsDesignation']	=	$rsDesignation;

        // Load Views
        $this->load->view('designation/list', $rsListing);
    }

    public function Adddesignation()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
	   
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->designation_model->get_by_id('id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('designation/designationForm',$data);
    }

    public function saveDesignation(){
        $strAction = $this->input->post('action');
	    $searchCriteria = array();
        $searchCriteria["selectField"] = "id";
	    $searchCriteria["Code"] = trim($this->Page->getRequest('Code'));
	    $searchCriteria["name"] = trim($this->Page->getRequest('name'));
	   	if ($strAction == 'E'){
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
	   	$this->designation_model->searchCriteria=$searchCriteria;
       	$rsDesignationName = $this->designation_model->getdesignation();
	  
        if(count($rsDesignationName) > 0){
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=designation', 'location');
        }

	   
	   	$arrHeader["Code"]    =	trim($this->Page->getRequest('Code'));
        $arrHeader["name"]    =	trim($this->Page->getRequest('name'));
       
	 
        if ($strAction == 'A' || $strAction == 'R'){
            $arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();

            $intCenterID = $this->designation_model->insert($arrHeader);
		  
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $worklocationid				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
		  $arrHeader['updateIP'] 		= 	$this->input->ip_address();
            $arrHeader['updateDate'] =	date('Y-m-d H:i:s');

            $update_record = $this->designation_model->update($arrHeader, array('id' => $worklocationid));
		  		  
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=designation', 'location');
    }

    public function delete(){
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate designation set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=designation', 'location');
    }
    
    function checkDesignationCode(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'Code'){
			$dbField = 'Code';
			$returnValue = 'CodeExists';
		}else if ($field == 'name'){
			$dbField = 'name';
			$returnValue = 'nameExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('designation', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('designation', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('designation', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}

    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";

                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
}
