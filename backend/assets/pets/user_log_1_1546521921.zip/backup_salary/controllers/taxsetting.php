<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Taxsetting extends CI_Controller {
 
	function __construct(){
		parent::__construct();
		$this->load->model("taxsetting_model",'',true);
		
	}
	
	public function index(){
		$arrWhere	=	array();
		// Get All Customers
		$searchCriteria = array(); 
		$searchCriteria["selectField"] = "*,c.id as id";
		$searchCriteria["orderField"] = "c.insertDate";
		$searchCriteria["orderDir"] = "DESC";
		$this->taxsetting_model->searchCriteria=$searchCriteria;
		$rsDetails = $this->taxsetting_model->getDetails();
		$rsListing['rsDetails']	=	$rsDetails;
		// Load Views
		$this->load->view('taxsetting/list', $rsListing);	
	}

   public function addDetails(){
		$this->taxsetting_model->tbl="professional_tax_settings";
		$data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
		   $data["rsEdit"] = $this->taxsetting_model->get_by_id('id', $data["id"]);
        } else {
            $data["strAction"] = "A";
        }
		$this->load->view('taxsetting/taxFrom',$data);
	}
	
	public function SaveDetails(){
		$this->taxsetting_model->tbl="professional_tax_settings";
		$strAction = $this->input->post('action');
		
		// Check Customer
		$searchCriteria = array(); 
		/*$searchCriteria["selectField"] = "*";
		$searchCriteria["name"] = $this->Page->getRequest('name');
		$searchCriteria["type"] = $this->Page->getRequest('type');
		 if ($strAction == 'E')
		   {
			  $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
		   }
		$this->taxsetting_model->searchCriteria=$searchCriteria;
		$rsCustomers = $this->taxsetting_model->getDetails();
		if(count($rsCustomers) > 0){
			$this->Page->setMessage('ALREADY_EXISTS');
			redirect('c=emp_setting&m=addDetails', 'location');
		}
		if($this->Page->getRequest('password') != $this->Page->getRequest('cpassword')){
			$this->Page->setMessage('MATCH_PASSWORD');
			redirect('c=empoyee_details&m=addDetails', 'location');
		}*/
		
		$arrHeader["lowerlimit"]			=   $this->Page->getRequest('lowerlimit');
		$arrHeader["higherlimit"]		=   $this->Page->getRequest('higherlimit');
		$arrHeader["value"]				=   $this->Page->getRequest('value');
		$arrHeader["value_type"]			=   $this->Page->getRequest('value_type');
		$arrHeader["salary_head_code"]	=   $this->Page->getRequest('salary_head_code');
	   
		
		if ($strAction == 'A' || $strAction == 'R')
		{
            $arrHeader['insertBy']			=	$this->Page->getSession("intUserId");
            $arrHeader['insertDate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['insertIP'] 		= 	$this->input->ip_address();
			$intCenterID = $this->taxsetting_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
        }
		elseif ($strAction == 'E')
		{
        		$detailsid				= 	$this->Page->getRequest('hid_id');
		  	$arrHeader['updateBy']		=	$this->Page->getSession("intUserId");
            $arrHeader['updateDate'] 	= 	date('Y-m-d H:i:s');
            $arrHeader['updateIP'] 	= 	$this->input->ip_address();
            $this->taxsetting_model->update($arrHeader, array('id' => $detailsid));
            $this->Page->setMessage('REC_EDIT_MSG');
        }
		
		redirect('c=taxsetting', 'location');
	}
	
	public function delete()
	{
		$this->taxsetting_model->tbl="professional_tax_settings";
		$arrCustomerIds	=	$this->input->post('chk_lst_list1');
		$strCustomerIds	=	implode(",", $arrCustomerIds);
		$strQuery = "update professional_tax_settings set delete_flag = 1 WHERE id IN (". $strCustomerIds .")";
		$this->db->query($strQuery);
		$this->Page->setMessage("DELETE_RECORD");
		// redirect to listing screen
		redirect('c=taxsetting', 'location');
	}
   
	public function deleteImage(){
	    if ($this->Page->getRequest('id')){
        $data = array(
            'image' => null
        );
        $this->db->where('id', $this->Page->getRequest('id'));
        $this->db->update('customer_master', $data);
        if(unlink($this->Page->getRequest('filename'))){
            $strMessage	=	'<div class="msg_success">Image removed successfully</div>';
            $this->Page->setMessage($strMessage);
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
        }
        else{
            $strMessage	=	'<div class="msg_error">Something went wrong!</div>';
            $this->Page->setMessage($strMessage);
        }
    }
	function checkEmail(){
        $field = $this->Page->getRequest("field");
        if ($field == 'txt_email'){
            $dbField = 'email';
            $returnValue = 'emailExists';
        }

        $fieldVal = $this->Page->getRequest("fieldVal");

        if ($this->Page->getRequest('id') && $this->Page->getRequest('id') != 'null'){
            $query = $this->db->get_where('employee_details', array('id' => $this->Page->getRequest('id')));
            $row = $query->row();
            if ($row->$dbField !== $fieldVal){
                $query1 = $this->db->get_where('employee_details', array($dbField => trim($fieldVal)));
                if ($query1->num_rows() > 0) {
                    echo $returnValue;
                }
            }
        }
        else {
            $query = $this->db->get_where('employee_details', array($dbField => trim($fieldVal)));
            if ($query->num_rows() > 0) {
                echo $returnValue;
            }
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */