<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:37 PM
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class country extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("country_model", '', true);
    }
    public function index()
    {
        // Get All countries
        $searchCriteria = array();
        $searchCriteria["selectField"] = "cm.*";
        $searchCriteria["orderField"] = "insertdate";
        $searchCriteria["orderDir"] = "DESC";
        $this->country_model->searchCriteria=$searchCriteria;
        $rsCountries = $this->country_model->getCountryList();
        $rsListing['rsCountries']	=	$rsCountries;

        // Load Views
        $this->load->view('country/list', $rsListing);
    }

    public function AddCountry()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->country_model->get_by_id('country_id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('country/countryForm',$data);
    }

    public function SaveCountry()
    {
        $strAction = $this->input->post('action');

        // Check User
        $searchCriteria = array();
        $searchCriteria["selectField"] = "cm.country_id";
        $searchCriteria["country_name"] = $this->Page->getRequest('txt_country_name');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->country_model->searchCriteria=$searchCriteria;
        $rsCountryName = $this->country_model->getCountryList();
        if(count($rsCountryName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=country&m=addCountry', 'location');
        }

        $arrHeader["country_name"]     	=	$this->Page->getRequest('txt_country_name');
        $arrHeader["country_code"]     	=	$this->Page->getRequest('txt_country_code');
        $arrHeader["status"]        		= 	$this->Page->getRequest('slt_status');

        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertby']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertdate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['updatedate'] 		= 	date('Y-m-d H:i:s');

            $intCenterID = $this->country_model->insert($arrHeader);
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $country_id				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateby'] 		= 	$this->Page->getSession("intUserId");
            $arrHeader['updatedate'] =	date('Y-m-d H:i:s');

            $this->country_model->update($arrHeader, array('country_id' => $country_id));
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=country', 'location');
    }

    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "DELETE FROM country_master WHERE country_id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=country', 'location');
    }
}