<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:37 PM
 */
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class state extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("state_model", '', true);
    }
    public function index()
    {
        // Get All countries
        $searchCriteria = array();
        //$searchCriteria["selectField"] = "sm.*,cm.*";
        $searchCriteria["orderField"] = "insertdate";
        $searchCriteria["orderDir"] = "DESC";
        $this->state_model->searchCriteria=$searchCriteria;
        $rsStates = $this->state_model->getStateList();
        $rsListing['rsStates']	=	$rsStates;

        // Load Views
        $this->load->view('state/list', $rsListing);
    }

    public function AddState()
    {
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");

        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R')
        {
            $data["rsEdit"] = $this->state_model->get_by_id('state_id', $data["id"]);
        }
        else
        {
            $data["strAction"] = "A";
        }
        $this->load->view('state/stateForm',$data);
    }

    public function SaveState()
    {
        $strAction = $this->input->post('action');

        // Check User
        $searchCriteria = array();
        $searchCriteria["selectField"] = "sm.state_id";
        $searchCriteria["state_name"] = $this->Page->getRequest('txt_state_name');
        if ($strAction == 'E')
        {
            $searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
        }
        $this->state_model->searchCriteria=$searchCriteria;
        $rsStateName = $this->state_model->getStateList();
        if(count($rsStateName) > 0)
        {
            $this->Page->setMessage('ALREADY_EXISTS');
            redirect('c=state&m=addState', 'location');
        }

        $arrHeader["state_name"]     	    =	$this->Page->getRequest('txt_state_name');
        $arrHeader["state_code"]            =   $this->Page->getRequest('txt_state_code');
        $arrHeader["status"]        		= 	$this->Page->getRequest('slt_status');
        $arrHeader["country_id"]        	= 	$this->Page->getRequest('slt_country');

        if ($strAction == 'A' || $strAction == 'R')
        {
            $arrHeader['insertby']		=	$this->Page->getSession("intUserId");
            $arrHeader['insertdate'] 		= 	date('Y-m-d H:i:s');
            $arrHeader['updatedate'] 		= 	date('Y-m-d H:i:s');

            $intCenterID = $this->state_model->insert($arrHeader);
            $this->Page->setMessage('REC_ADD_MSG');
        }
        elseif ($strAction == 'E')
        {
            $state_id				= 	$this->Page->getRequest('hid_id');
            $arrHeader['updateby'] 		= 	$this->Page->getSession("intUserId");
            $arrHeader['updatedate'] =	date('Y-m-d H:i:s');

            $this->state_model->update($arrHeader, array('state_id' => $state_id));
            $this->Page->setMessage('REC_EDIT_MSG');
        }

        redirect('c=state', 'location');
    }

    public function delete()
    {
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "DELETE FROM state_master WHERE state_id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=state', 'location');
    }
}