<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Predefine_salary extends CI_Controller {
	var $module = 'predefine_salary';
	var $datetime;
	var $user_id;
	var $ip;
	function __construct(){
		parent::__construct();
		$this->datetime = date('Y-m-d H:i:s');
		$this->user_id = $this->session->userdata('sess_intUserId');
		$this->ip = $this->input->ip_address();
		$this->load->model("Predefine_salary_model",'salary',true);
		$this->load->model("salaryhead_model",'salaryhead_model',true);
	}
	
	public function index(){
        $searchCriteria = array();
        $rsSales = $this->salary->get_salary_data();
        $rsListing['rsList']	=	$rsSales;
		$this->load->view('predefine_salary/list', $rsListing);
    }

    public function add(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->salary->get_by_id('id', $data["id"]);
        } else{
            $data["strAction"] = "A";
        }
        $this->load->view('predefine_salary/salary_form',$data);
    }

	public function process(){
		/*pre($this->input->post());
		exit;*/
		$salID = $this->input->post('hid_id');
		$empID = $this->input->post('empID');
		$getEmpData = $this->salary->get_employee_by_id($empID);

		// get salary head master details
        $searchCriteria = array();
        $searchCriteria['id'] = $this->input->post('headID');
        $this->salaryhead_model->searchCriteria = $searchCriteria;
		
        $resSalaryHead = $this->salaryhead_model->getSalaryhead();		
		if(!empty($resSalaryHead)){
            $is_pre_defined = @$resSalaryHead[0]['is_pre_defined'];
        }else{
            $this->Page->setMessage('<div class="msg_error">Invalid Salary Head..!</div>');
            redirect('c=predefine_salary', 'location');exit;
        }
		
		
		if(!empty($getEmpData)){
			if($salID == ''){
				$data['start_date'] = date('Y-m-d',strtotime($this->input->post('start_date')));
				$data['empID'] = $empID;
				$data['headID'] = $this->input->post('headID');
				$data['empCode'] 	= @$getEmpData[0]['EmpCode'];
				$data['empBranch'] 	= @$getEmpData[0]['BranchID'];
				$data['empCompany'] = @$getEmpData[0]['CompanyID'];
				$data['empESINumber'] = @$getEmpData[0]['EsiNumber'];
				$data['PFNo'] = @$getEmpData[0]['PFNumber'];
				$data['is_pre_defined'] = $is_pre_defined;
				$data['is_last'] = 1;
			}else{
				$oldData = $this->salary->get_by_id('id', $salID);
				if(!empty($oldData)){
					$data['start_date'] = date('Y-m-d');
					$data['empID'] = @$oldData->empID;
					$data['headID'] = @$oldData->headID;
					$data['empCode'] 	= @$oldData->empCode;
					$data['empBranch'] 	= @$oldData->empBranch;
					$data['empCompany'] = @$oldData->empCompany;
					$data['empESINumber'] = @$oldData->empESINumber;
					$data['PFNo'] = @$oldData->PFNo;
					$data['is_pre_defined'] = $oldData->is_pre_defined;
				}
				$data['is_last'] = 1;
			}
		}else{
			$this->Page->setMessage('<div class="msg_error">Invalid employee..!</div>');
			redirect('c=predefine_salary', 'location');exit;
		}

		$data['amount'] = $this->input->post('amount');
		$data['note'] = $this->input->post('note');	
		$data['insertDate'] = $this->datetime;
		$data['insertBy'] = $this->user_id;
		$data['insertIP'] = $this->ip;
		$add = $this->salary->addSalaryHead($data);
		if($add){
			$salID = $this->db->insert_id();
			$updData['is_last'] = 0;
			$updData['end_date'] = date('Y-m-d');
			$upd = $this->salary->updateLast($updData, " id != ". $salID . " AND empID = ".@$empID);
			$this->Page->setMessage('REC_ADD_MSG');
		}else{
			$this->Page->setMessage('<div class="msg_error">Failed to insert data</div>');
		}
		/*}else{
			$data['insertDate'] = $this->datetime;
			$data['insertBy'] = $this->user_id;
			$data['insertIP'] = $this->ip;
			$upd = $this->salary->updateSalaryHead($data,$salID);
			if($upd){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update data</div>');
			}
		}*/
		redirect('c=predefine_salary', 'location');exit;
	}
	
    public function delete(){
        $ids	=	$this->input->post('chk_lst_list1');
        $ids	=	implode(",", $ids);
        $strQuery = "DELETE FROM ".$this->salary->tbl_salary_employee_monthly_head." WHERE id IN (". $ids .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        redirect('c=predefine_salary', 'location');
    }

	function import(){
		
		$date = date('Y-m-d',strtotime($this->input->post('startDate')));
		$check = $this->salary->getMonthModule($date, $this->module);
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_tds';
			$config['upload_path'] = $path;
			$config['allowed_types'] = '*';
			$config['remove_spaces'] = TRUE;
			$this->load->library('upload');
			$this->upload->initialize($config);
			if (!$this->upload->do_upload('import')){
				$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=predefine_salary', 'location');		   
			} else {
				$data = array('upload_data' => $this->upload->data());
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				if(!in_array($fdata['type'],array('txt','xlsx'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
					redirect('c=predefine_salary', 'location');
				}
				$fdata['file'] = $data['upload_data']['file_name'];
				$fdata['ModuleCode'] = $this->module;
				$fdata['Date'] = $date;
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				$addFile = $this->salary->addFileList($fdata);
				$fileID = $this->db->insert_id();
			}
			if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
				redirect('c=predefine_salary', 'location');exit;
			}
			if (!empty($data['upload_data']['file_name'])) {
				$import_xls_file = $data['upload_data']['file_name'];
			} else {
				$import_xls_file = 0;
			}
			$inputFileName = $path . $import_xls_file;
			if(@$fdata['type'] == 'xlsx'){
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
				} catch (Exception $e) {
					die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage());
				}
			
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);

				$arrayCount = count($allDataInSheet);
				$flag = 0;
				$createArray = array('Employee Code','headCode','amount','start_date','note');
				$makeArray = array('EmployeeCode'=>'EmployeeCode','headCode'=>'headCode','amount'=>'amount','start_date'=>'start_date','note'=>'note');
				$SheetDataKey = array();
				foreach ($allDataInSheet as $dataInSheet) {
					foreach ($dataInSheet as $key => $value) {
						if (in_array(trim($value), $createArray)) {
							$value = preg_replace('/\s+/', '', $value);
							$SheetDataKey[trim($value)] = $key;
						} else {
							
						}
					}
				}

				$data = array_diff_key($makeArray, $SheetDataKey);
				
				if (empty($data)) $flag = 1;
				$errMsg = '';
				if ($flag == 1){
					$a = 1;
					for ($i = 2; $i <= $arrayCount; $i++) {
						$err 		= array();
						$empCode 	= $SheetDataKey['EmployeeCode'];
						$headCode 	= $SheetDataKey['headCode'];
						$amount 	= $SheetDataKey['amount'];
						$start_date 	= $SheetDataKey['start_date'];
						//$end_date = $SheetDataKey['end_date'];
						$note 	= $SheetDataKey['note'];
						
						$empCode 	= filter_var(trim($allDataInSheet[$i][$empCode]), FILTER_SANITIZE_STRING);
						$headCode 	= filter_var(trim($allDataInSheet[$i][$headCode]), FILTER_SANITIZE_STRING);
						$amount 	= filter_var(trim($allDataInSheet[$i][$amount]), FILTER_SANITIZE_STRING);
						$start_date 	= filter_var(trim($allDataInSheet[$i][$start_date]), FILTER_SANITIZE_STRING);
						//$end_date 	= filter_var(trim($allDataInSheet[$i][$end_date]), FILTER_SANITIZE_STRING);
						$note 	= filter_var(trim($allDataInSheet[$i][$note]), FILTER_SANITIZE_STRING);
						
						// get employee details form employee code
						$EMPData = $this->salary->get_employee_by_code($empCode);

						$empID = isset($EMPData[0]['id']) ? $EMPData[0]['id'] : '';
						$empBranch = isset($EMPData[0]['BranchID']) ? $EMPData[0]['BranchID'] : '';
						$empCompany = isset($EMPData[0]['CompanyID']) ? $EMPData[0]['CompanyID'] : '';
                        $empESINumber 	= isset($EMPData[0]['EsiNumber']) ? $EMPData[0]['EsiNumber'] : ''; $SheetDataKey['EsiNumber'];
                        $PFNo 	= isset($EMPData[0]['PFUANNo']) ? $EMPData[0]['PFUANNo'] : ''; $SheetDataKey['PFUANNo'];
						$EmployeeName = @$EMPData[0]['EmpFullName'];
						
						if($empCode == '' || $empID == ''){
							$err['empCode'] = '1';
							$errMsg .= $a.' - employee code is empty or invalide<br>';
						}
						
						$getSalaryHeadIdByHeadCode = $this->salary->getSalaryHeadIdByHeadCode($headCode);
						$headID = @$getSalaryHeadIdByHeadCode[0]['id'];
                        $isPreDefined = @$getSalaryHeadIdByHeadCode[0]['is_pre_defined'];

						if($headCode == '' || $headID == ''){
							$err['headCode'] = '1';
							$errMsg .= $a.' - headCode is empty or invalide<br>';
						}
						
						if($amount == ''){
							$err['amount'] = '1';
							$errMsg .= $a.' - amount is empty <br>';
						}
						
						if($start_date == ''){
							$err['start_date'] = '1';
							$errMsg .= $a.' - start date is empty <br>';
						}
						
						/*if($end_date == ''){
							$err['end_date'] = '1';
							$errMsg .= $a.' - end date is empty <br>';
						}*/
						
						$fetchData[] = array(
							'empID' => $empID, 
							'empCode' => $empCode, 
							'EmployeeName' => $EmployeeName, 
							'empBranch' => $empBranch, 
							'empCompany' => $empCompany,
							'headCode' => $headCode,
							'headID' => $headID,
							'amount' => $amount,
							'is_pre_defined' => $isPreDefined,
							'empESINumber' => $empESINumber,
							'PFNo' => $PFNo,
							'start_date' => $start_date,
							
							'note' => $note,
							'error'=>$err
						);
						$a++;
					}

					$data['data'] = $fetchData;
					$data['fileID'] = @$fileID;
					$data['errMsg'] = $errMsg;
					$data['date'] = $date;
					$data['checkDate'] = count($check);
					//pre($data);exit;
					$this->load->view('predefine_salary/import_list',$data);
				} else {
					$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
					redirect(base_url('c=predefine_salary','location'));
				}
			}else{
				$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
				redirect(base_url('c=predefine_salary','location'));
			}
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=predefine_salary', 'location');
		}
	}
	
	function import_add_process(){
		//pre($this->input->post());exit;
		$empID = $this->input->post('empID');
		$empCode = $this->input->post('empCode');
		$empBranch = $this->input->post('empBranch');
		$empCompany = $this->input->post('empCompany');
		$amount = $this->input->post('amount');
		$is_pre_defined = $this->input->post('is_pre_defined');
		//$end_date = $this->input->post('end_date');
		$headID = $this->input->post('headID');
		$empESINumber = $this->input->post('empESINumber');
		$PFNo = $this->input->post('PFNo');
		$start_date = $this->input->post('start_date');
		$note = $this->input->post('note');
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=predefine_salary', 'location');
		}
		
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$check = $this->salary->getMonthModule($date, $this->module);
		if(!empty($check))	foreach($check as $file) $this->salary->removeOldData($file['id'],$fileID);
		$addData = array();
		for($i = 0; $i < $totalLength; $i++){
			$data['empID'] = $empID[$i];
			$data['empCode'] = $empCode[$i];
			$data['empBranch'] = $empBranch[$i];
			$data['empCompany'] = $empCompany[$i];
			$data['amount'] = $amount[$i];
			$data['is_pre_defined'] = $is_pre_defined[$i];
			$data['headID'] = $headID[$i];
			$data['empESINumber'] = $empESINumber[$i];
			$data['PFNo'] = $PFNo[$i];
			$data['start_date'] = date('Y-m-d',strtotime($start_date[$i]));
			//$data['end_date'] = date('Y-m-d',strtotime($end_date[$i]));
			$data['is_last'] = 1;
			$data['note'] = $note[$i];
			$data['FileID'] = $fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIp'] = $this->input->ip_address();
			
			$whereGetOld = array('empID'=>$data['empID'],'headID'=>$data['headID'],'is_last'=>'1');
			$checkOldData = $this->salary->getExistsIDByHeadAndEmployee($whereGetOld);
			if(!empty($checkOldData)) foreach($checkOldData as $val) $headIDS[] = $val['id'];
			$addData[] = $data;
			
			//$add[] = $this->salary->addSalaryHead($data);
		}
		
		if(!empty($addData)){
			$add = $this->salary->addBatchSalaryHead($addData);
			if(!empty($headIDS)){
				$headid = implode(",", $headIDS);
				$upData['end_date'] = date('Y-m-d');
				$upData['is_last'] = 0;
				$upWhere = " id IN(".$headid.") ";
				$upd = $this->salary->updateLast($upData, $upWhere);
			}
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=predefine_salary', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/predefine_salary.xlsx', NULL);
	}
	
	function checkModuleUpload(){
		//error_reporting(-1);
		$date = $this->input->post('date');
		if($date == ''){
			$msg['error'] = 1;
			$msg['message'] = 'Date is empty!';
		}else{
			$check = $this->tds->getMonthModule($date, $this->module);
			if(count($check) > 0){
				$msg['error'] = 1;
				$msg['message'] = 'This month data already added! \n Are you sure to remove and upload new data?';
			}else{
				$msg['error'] = 0;
				$msg['message'] = 'This month data already added!';
			}
		}
		echo json_encode($msg);
	}
}