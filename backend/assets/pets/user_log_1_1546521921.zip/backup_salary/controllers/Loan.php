<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Loan extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model("loan_model",'loan',true);
		$this->load->library('table');
	}
	
	public function index(){
		$data['rsList'] = $this->loan->getList();
		$this->load->view('loan/list', $data);
	}

	public function addLoan(){
		$data["strAction"] 	= $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] 		= $this->Page->getRequest("id");

        if($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
			$data["rsEdit"] = $this->loan->get_by_id($data["id"],true);
        }else{
           $data["strAction"] = "A";
        }
	  	$this->load->view('loan/loan_from',$data);
	}
	
	function process(){
		//pre($this->input->post());exit;
		
		$loan = $this->input->post('hid_id');
		$data['EmployeeId'] 	= $this->input->post('beneficiary_type');
		$data['Amount'] 	= $this->input->post('Amount');
		$data['LoneIntrest'] 	= $this->input->post('LoneIntrest');
		$data['EMIAmount'] 	= $this->input->post('EMIAmount');
		$data['NoOfEmi'] 	= $this->input->post('NoOfEmi');
		$data['LoneStartDate'] 	= $this->input->post('LoneStartDate');
		$data['EmiStartDate'] 	= $this->input->post('EMIStartDate');
		$data['LoneEndDate'] 	= $this->input->post('LoneEndDate');
		$data['Note'] 	= $this->input->post('Note');
		$data['LoneApproveBy'] 	= $this->input->post('LoneApproveBy');
		
		$errMsg = '';
		
		if($data['EmployeeId'] == '') $errMsg .= "Employee is empty <br>";	
		if($data['Amount'] == '') $errMsg .= "Amount is empty <br>";	
		if($data['LoneIntrest'] == '') $errMsg .= "Loan Intersest is empty <br>";	
		if($data['EMIAmount'] == '') $errMsg .= "EMI Amount is empty <br>";	
		if($data['NoOfEmi'] == '') $errMsg .= "No of EMI is empty <br>";	
		if($data['LoneStartDate'] == '') $errMsg .= "Lone Start Date is empty <br>";
		if($data['EmiStartDate'] == '') $errMsg .= "EMI Start Date is empty <br>";
		if($data['LoneEndDate'] == '') $errMsg .= "Lone End Date is empty <br>";
		if($data['Note'] == '') $errMsg .= "Note is empty <br>";
		if($data['LoneApproveBy'] == '') $errMsg .= "Lone Approved By is empty <br>";	
		
		if($errMsg != '' ){
			$this->Page->setMessage('<div class="msg_error">'.$errMsg.'</div>');
			redirect('?c=loan');
		}
		
		if($loan == ''){
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertIP'] = $this->input->ip_address();
			$res = $this->loan->addLone($data);
			if($res){
				if($data['NoOfEmi'] != ''){
					$dataEmi = array();
					$getSalary = $this->loan->getsalary($data['EmployeeId']);
					//$dataEmi['EmiStartDate'] = $data['EmiStartDate'];
					for($i = 0;$i< $data['NoOfEmi']; $i++){
						$startDate = $data['EmiStartDate'];
						$t = strtotime("$startDate +$i months");
						$dataEmi['loan_id'] =  $res;
						$dataEmi['EMIAmount'] = $data['EMIAmount'];
						$dataEmi['EMIDate'] = date('Y-m-d', $t) ;
						$dataEmi['Status'] = 0;
						$dataEmi['EmiSalaryID'] = $getSalary[0]['id'];
						$dataEmi['insertBy'] = $this->Page->getSession("intUserId");
						$dataEmi['insertDate'] = date('Y-m-d H:i:s');
						$dataEmi['insertIP'] = $this->input->ip_address();

						$resEmi = $this->loan->addEMI($dataEmi);
					}				}
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to add record</div>');
			}
		}else{
			$dataupdate['EmployeeId'] = $data['EmployeeId'];
			$dataupdate['LoneIntrest'] = $data['LoneIntrest'];
			$dataupdate['Note'] = $data['Note'];
			$dataupdate['LoneApproveBy'] = $data['LoneApproveBy'];
			$dataupdate['updateBy'] = $this->Page->getSession("intUserId");
			$dataupdate['updateDate'] = date('Y-m-d H:i:s');
			$dataupdate['updateIP'] = $this->input->ip_address();
			$res = $this->loan->updateLoan($dataupdate, $loan);
			if($res){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update record</div>');
			}
		}
		redirect('c=loan', 'location');

		
		
		/*$loan = $this->input->post('hid_id');
		$data['beneficiary_type'] 	= $this->input->post('beneficiary_type');
		$data['beneficiary_id'] 	= $this->input->post('Beneficiary');
		$data['month'] 	= $this->input->post('Month');
		$data['SchemeBase'] 	= $this->input->post('SchemeBase');
		$data['employee_id'] 	= $this->input->post('Employee');
		$data['inactive_type'] 	= $this->input->post('inactive_type');
		
		$errMsg = '';
		
		if($data['beneficiary_type'] == '') $errMsg .= "Beneficiary type is empty <br>";	
		if($data['beneficiary_id'] == '') $errMsg .= "Beneficiary id is empty <br>";	
		if($data['month'] == '') $errMsg .= "Month is empty <br>";	
		if($data['SchemeBase'] == '') $errMsg .= "SchemeBase is empty <br>";	
		if($data['employee_id'] == '') $errMsg .= "employee is empty <br>";	
		if($data['inactive_type'] == '') $errMsg .= "inactive_type is empty <br>";	
		
		if($errMsg != '' ){
			$this->Page->setMessage('<div class="msg_error">'.$errMsg.'</div>');
			redirect('?c=loan');
		}
		
		if($loan == ''){
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertIP'] = $this->input->ip_address();
			$res = $this->loan->addScheme($data);
			if($res){
				$this->Page->setMessage('REC_ADD_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to add record</div>');
			}
		}else{
			
			$data['updateBy'] = $this->Page->getSession("intUserId");
			$data['updateDate'] = date('Y-m-d H:i:s');
			$data['updateIP'] = $this->input->ip_address();
			$res = $this->loan->updateScheme($data, $loan);
			if($res){
				$this->Page->setMessage('REC_EDIT_MSG');
			}else{
				$this->Page->setMessage('<div class="msg_error">Failed to update record</div>');
			}
		}
		redirect('c=loan', 'location');*/
	}
	
	function get_beneficiary_type_list($data = array()){
		$type = $this->input->post('type') == '' ? @$data['type'] : $this->input->post('type');
		$id = $this->input->post('id') == '' ? @$data['id'] : $this->input->post('id');
		if($type == 1){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$id,"Select Employee");
		}else if($type == 2){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_branch_master,"id","BranchName","","where delete_flag = 0",$id,"Select Branch");
		}else if($type == 3){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_designation,"id","name","","where delete_flag = 0",$id,"Select Designation");
		}else{
			$get = "<option value=''>No data found</option>";
		}
		if(isset($data) && !empty($data['id'])) return $get;
		else echo $get;
	}
	
	function get_beneficiary_employee($data = array(),$sel = NULL){
		$type = $this->input->post('type') == '' ? @$data['type'] : $this->input->post('type');
		$id = $this->input->post('id') == '' ? @$data['id'] : $this->input->post('id');
		$sel = $sel == '' ? $id : $sel;
		if($type == 1){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where id = ".$id." AND delete_flag = 0",$sel,"Select Employee");
		}else if($type == 2){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where BranchID = ".$id." AND delete_flag = 0",$sel,"Select Employee");
		}else if($type == 3){
			$get = $this->Page->generateComboByTable($this->scheme->tbl_employee_masater,"id","EmpFullName","","where DesignationID = ".$id." AND delete_flag = 0",$sel,"Select Employee");
		}else{
			$get = "<option value=''>No data found</option>";
		}
		//echo $this->db->last_query();exit;
		if(isset($data) && !empty($data['id'])) return $get;
		else echo $get;
	}
	
	function delete(){
		
	   $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "update loanmaster set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
	   
	   $strQuery_EMI = "update emimaster set delete_flag = 1 WHERE loan_id IN (". $strCountryIds .")";
	   $this->db->query($strQuery_EMI);
	   
        $this->Page->setMessage("DELETE_RECORD");
        redirect('c=loan', 'location');
	}
	function getEMIData(){
		$loanid = $this->input->post('id');
		if($loanid != ''){
			$data['Loan'] = $this->loan->getEMIList($loanid);
			if(!empty($data['Loan'])){
				$res['error'] = 0;
				$res['view'] = $this->load->view('loan/Emi_list',$data,TRUE);
			}else{
				$res['error'] = 1;
				$res['msg'] = 'No record found';
			}
		}else{
			$res['error'] = 1;
			$res['msg'] = 'EMI is empty ';
		}
		echo json_encode($res);
	}
	function loanDetails(){
		$id = $this->input->post('id');
		if($id != ''){
			//$data['loanDET'] = $this->loan->loanDEL($id);
			$data = $this->loan->loan_details($id);
			$t = '';
			if(!empty($data['loanDetails'])){
				$tmpl  = $this->table->set_heading(array('title'=>array('data'=>'Loan Details','colspan'=>10,'style'=>'text-align: center;')));
				$this->table->set_template($tmpl);
				foreach($data['loanDET'] as $val){
					$this->table->add_row(array('title'=>array('data'=>'Loan ID','style'=>'color:#bf1d11;font-weight:bold; width:25%;'),
					'amount'=>array('data'=>$val['loanid'],'style'=>'font-weight:bold;  width:25%;'),
					'Remaining'=>array('data'=>'Employee','style'=>'color:#bf1d11;font-weight:bold;  width:25%;'),
					'lamount'=>array('data'=>$val['empname'],'style'=>'font-weight:bold;  width:25%;')));					
				}
				$rs['table'] = '<div class="table table-striped table-bordered table-hover dataTable" style="border:1px solid #438eb9">'.$this->table->generate();

				if(!empty($data['loanDET'])){
					$tmpl = $this->table->set_heading(array('Sr.','Amount','LoneIntrest','EMIAmount','No Of Emi','LoneStartDate','LoneStartDate','LoneEndDate','Note','Loan Approve By'));
					$this->table->set_template($tmpl);
					$this->table->set_caption('<b>Loan details<b>');
					$i = $tta = 0;
					foreach($data['loanDET'] as $sval){
						$i++;
						$tdata['sr'] = $i;
						$tdata['amount'] = $sval['amount'];
						$tdata['LoneIntrest'] = $sval['LoneIntrest'];
						$tdata['EMIamount'] = $sval['EMIamount'];
						$tdata['noofemi'] = $sval['noofemi'];
						$tdata['loanstartdate'] = $sval['loanstartdate'];
						$tdata['emistartdate'] = $sval['emistartdate'];
						$tdata['loanenddate'] = $sval['loanenddate'];
						$tdata['Note'] = $sval['Note'];
						$tdata['LoneApproveBy'] = $sval['LoneApproveBy'];
						
						$this->table->add_row($tdata);
					
					}
					$rs['table'] .= '<br>'.$this->table->generate();	
				}
				
				$tmpl = $this->table->set_heading('Sr.','EMIAmount','EMIDate','Status');
				$this->table->set_template($tmpl);
				$this->table->set_caption('<b>EMI Detail<b>');
				$i = 0;
				$tdata = array();
				foreach($data['loanDetails'] as $val){
					$i++;
					$tdata['sr'] = $i;
					$tdata['EMA'] = $val['EMA'];
					$tdata['EMIDate'] = $val['EMIDate'];
					$tdata['EMIStatus'] = $val['EMIStatus'] == '0' ? '<input type="button" value="Incomplete" class="btn btn-warning btn-small incomplete" data-val="'.$val['emiid'].'" >' : '<input type="button" disabled style="cursor: no-drop;" value="Completed" class="btn btn-success btn-small"></td>';
					$this->table->add_row($tdata);					
				}
				$rs['table'] .= '<br>'.$this->table->generate().'<br>';
				
				
			}
			
		}else{
			$msg = array('error'=>1,'Failed to display record.');
		}
		echo json_encode($rs);
	} 
	
	
	function emicomplete(){
		$resi = array();
		$id = $this->input->post('id');
		if($id != ''){
			$dispatched = $this->loan->updateemi($id);
			if($dispatched){
				$resi['error'] = 0;
				$resi['msg'] = get_message('Record updated successfully...',0);	
			}	
			else{
				$resi['error'] = 1;
				$resi['msg'] = get_message('Failed update record...',1);
			}
		}else{
			$resi['error'] = 1;
			$resi['msg'] = get_message('Failed update record...',1);
		}
		echo json_encode($resi);	
	}
	
}