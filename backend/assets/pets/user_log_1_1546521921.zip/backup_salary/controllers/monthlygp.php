<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class monthlygp extends CI_Controller{
	var $module = 'monthlygp';
    function __construct() {
        parent::__construct();
        $this->load->model("monthlygp_model", '', true);
    }
    public function index(){
        $searchCriteria = array();
        $searchCriteria["orderField"] = "ms.id";
        $searchCriteria["orderDir"] = "DESC";
        $this->monthlygp_model->searchCriteria=$searchCriteria;
        $rsSales = $this->monthlygp_model->getgp();
        $rsListing['rsgp']	=	$rsSales;
		$this->load->view('managegp/list', $rsListing);
    }

    public function Addsales(){
        $data["strAction"] = $this->Page->getRequest("action");
        $data["strMessage"] = $this->Page->getMessage();
        $data["id"] = $this->Page->getRequest("id");
        if ($data["strAction"] == 'E' || $data["strAction"] == 'V' || $data["strAction"] == 'R'){
            $data["rsEdit"] = $this->monthlygp_model->get_by_id('id', $data["id"]);
        } else{
            $data["strAction"] = "A";
        }
        $this->load->view('managegp/gpForm',$data);
    }

	public function savegp(){
		$strAction 	= $this->input->post('action');
		$date 		= trim($this->Page->getRequest('date'));
		$d 			= date_parse_from_format("Y-m-d", $date);
		$searchCriteria["Month"] 	= $d["month"];
		$searchCriteria["BranchID"] = trim($this->Page->getRequest('BranchID'));
		
		if ($strAction == 'E'){
			$searchCriteria["not_id"] = $this->Page->getRequest('hid_id');
		}
		
		$searchCriteria["selectField"] = "ms.id";
		$this->monthlygp_model->searchCriteria=$searchCriteria;
		$rsCheckDate = $this->monthlygp_model->getgp();
		
		if(count($rsCheckDate) > 0){
			$this->Page->setMessage('ALREADY_EXISTS');
			redirect('c=monthlygp', 'location');
		}
		
		
		$arrHeader["BranchID"]    =	trim($this->Page->getRequest('BranchID'));
		$arrHeader["date"]        =	trim($this->Page->getRequest('date'));
		$arrHeader["GpAmount"]    = 	$this->Page->getRequest('GpAmount');
		
		if ($strAction == 'A' || $strAction == 'R'){
			$arrHeader['insertBy']		=	$this->Page->getSession("intUserId");
			$arrHeader['insertDate'] 	= 	date('Y-m-d H:i:s');
			$arrHeader['insertIp'] 		= 	$this->input->ip_address();
			$intCenterID = $this->monthlygp_model->insert($arrHeader);
			$this->Page->setMessage('REC_ADD_MSG');
		}elseif ($strAction == 'E'){
			$salesID					= 	$this->Page->getRequest('hid_id');
			$arrHeader['updateBy'] 		= 	$this->Page->getSession("intUserId");
			$arrHeader['updateIp'] 		= 	$this->input->ip_address();
			$arrHeader['updateDate'] 	=	date('Y-m-d H:i:s');
			$update_record = $this->monthlygp_model->update($arrHeader, array('id' => $salesID));
			$this->Page->setMessage('REC_EDIT_MSG');
		}
		
		redirect('c=monthlygp', 'location');
	}

	function datecheck(){
		$id = $this->Page->getRequest('id');
		$field = $this->Page->getRequest("field");
		if ($field == 'date'){
			$dbField = 'Date';
			$returnValue = 'dateExists';
		}
		$fieldVal = $this->Page->getRequest("fieldVal");
		if($id != ''){
			$query = $this->db->get_where('branchwisemonthlysales', array('id' => $id));
			$row = $query->row();
			if ($row->$dbField !== $fieldVal){
				$query1 = $this->db->get_where('branchwisemonthlysales', array($dbField => trim($fieldVal),'delete_flag' => '0'));
				if ($query1->num_rows() > 0) echo $returnValue;
			}
		}else{
			$query = $this->db->get_where('branchwisemonthlysales', array($dbField => trim($fieldVal)));
			if ($query->num_rows() > 0) {
				echo $returnValue;
			}
		}
	}
	
	
    public function delete(){
        $arrCountryIds	=	$this->input->post('chk_lst_list1');
        $strCountryIds	=	implode(",", $arrCountryIds);
        $strQuery = "UPdate branchwisemonthlygp set delete_flag = 1 WHERE id IN (". $strCountryIds .")";
        $this->db->query($strQuery);
        $this->Page->setMessage("DELETE_RECORD");
        // redirect to listing screen
        redirect('c=monthlygp', 'location');
    }

    public function getStates(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('state_master', array('country_id' => $fieldVal));
                if ($query->num_rows() > 0) {
                    $retstr = '';
                    $retstr .="<option value='' selected>Select State</option>";
                    $selectedArr = array();
                    foreach ($query->result_array() as $row) {
                        if ($this->Page->getRequest("state_id") != null && is_numeric($this->Page->getRequest("state_id"))) {
                            $selectedArr = explode(" ", $this->Page->getRequest("state_id"));
                            $Val = $row["state_id"];
                        }
                        if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                            $sel = "selected";
                        else
                            $sel = "";

                        $retstr .= "<option value='$row[state_id]' $sel>$row[state_name]</option>";
                    }
                    echo $retstr;
                }
        }
     }

    public function getCities(){
        $fieldVal = $this->Page->getRequest("fieldVal");
        if (isset($fieldVal) && $fieldVal != null){
            $query = $this->db->get_where('city_master', array('state_id' => $fieldVal));
            if ($query->num_rows() > 0) {
                $retstr = '';
                $retstr .="<option value='' selected>Select City</option>";
                $selectedArr = array();
                foreach ($query->result_array() as $row) {
                    if ($this->Page->getRequest("city_id") != null && is_numeric($this->Page->getRequest("city_id"))) {
                        $selectedArr = explode(" ", $this->Page->getRequest("city_id"));
                        $Val = $row["city_id"];
                    }
                    if (count($selectedArr) > 0 && in_array($Val, $selectedArr))
                        $sel = "selected";
                    else
                        $sel = "";

                    $retstr .= "<option value='$row[city_id]' $sel>$row[city_name]</option>";
                }
                echo $retstr;
            }
        }
    }
	
	function import(){
		$date = date('Y-m-d',strtotime($this->input->post('startDate')));
		$check = $this->monthlygp_model->getMonthModule($date, $this->module);
		$this->load->library('excel');
		if(isset($_FILES['import']['error']) && $_FILES['import']['error'] == 0){
			$path = '../upload/csv/';
			$config['file_name'] = time().'_import_salse';
			$config['upload_path'] = $path;
            $config['allowed_types'] = '*';
            $config['remove_spaces'] = TRUE;
            $this->load->library('upload');
			$this->upload->initialize($config);
            if (!$this->upload->do_upload('import')){
			   	$this->Page->setMessage('<div class="msg_error">'.$this->upload->display_errors().'</div>');
				redirect('c=managegp', 'location');		   
            } else {
				
                $data = array('upload_data' => $this->upload->data());
				$fdata['type'] = str_replace('.','',$data['upload_data']['file_ext']);
				if(!in_array($fdata['type'],array('txt','xlsx'))){
					$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            		redirect('c=monthlygp', 'location');
				}
				
				$fdata['file'] = $data['upload_data']['file_name'];
				
				$fdata['ModuleCode'] = $this->module;
				$fdata['Date'] = $date;
				$fdata['insertDate'] = date('Y-m-d H:i:s');
				$fdata['insertBy'] = $this->Page->getSession("intUserId");
				$fdata['insertIp'] = $this->input->ip_address();
				$addFile = $this->monthlygp_model->addFileList($fdata);
				$fileID = $this->db->insert_id();
            }
            if($fileID == ''){
				$this->Page->setMessage('<div class="msg_error">Failed to insert file</div>');
            	redirect('c=managegp', 'location');
			}
            if (!empty($data['upload_data']['file_name'])) {
                $import_xls_file = $data['upload_data']['file_name'];
            } else {
                $import_xls_file = 0;
            }
            $inputFileName = $path . $import_xls_file;
			
			
			
			if(@$fdata['type'] == 'xlsx'){
				try {
					$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
					$objReader = PHPExcel_IOFactory::createReader($inputFileType);
					$objPHPExcel = $objReader->load($inputFileName);
				} catch (Exception $e) {
					die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME). '": ' . $e->getMessage());
				}
				
				$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
				$arrayCount = count($allDataInSheet);
				$flag = 0;
				$createArray = array('Branch','Opening Stock','Direct Expense','Direct Income','Closing Stock','Gross Profit','Indirect Expense','Indirect Income','Net Profit');
				$makeArray = array('Branch'=>'Branch','OpeningStock'=>'OpeningStock','DirectExpense'=>'DirectExpense','DirectIncome'=>'DirectIncome','ClosingStock'=>'ClosingStock','GrossProfit'=>'GrossProfit','IndirectExpense'=>'IndirectExpense','IndirectIncome'=>'IndirectIncome','NetProfit'=>'NetProfit');
				$SheetDataKey = array();
				foreach ($allDataInSheet as $dataInSheet) {
					foreach ($dataInSheet as $key => $value) {
						if (in_array(trim($value), $createArray)) {
							$value = preg_replace('/\s+/', '', $value);
							$SheetDataKey[trim($value)] = $key;
						} else {
							
						}
					}
				}
				
				$data = array_diff_key($makeArray, $SheetDataKey);
				
				if (empty($data)) $flag = 1;
				$errMsg = '';
				if ($flag == 1){
					$a = 1;
					for ($i = 2; $i <= $arrayCount; $i++) {
						$err 		= array();
						$Branch 	= $SheetDataKey['Branch'];
						$Date 		= $date;
						$GpAmount 	= $SheetDataKey['GrossProfit'];
						$NetProfit 	= $SheetDataKey['NetProfit'];
						
						$Branch 	= filter_var(trim($allDataInSheet[$i][$Branch]), FILTER_SANITIZE_STRING);
						$txtBeanch 	=  $Branch;
						$Date 		= $date;
						$GpAmount 	= filter_var(trim($allDataInSheet[$i][$GpAmount]), FILTER_SANITIZE_EMAIL);
						$NetProfit 	= filter_var(trim($allDataInSheet[$i][$NetProfit]), FILTER_SANITIZE_EMAIL);
						
						$BranchData = $this->monthlygp_model->getBranchIdByName($Branch);
						$BranchID = isset($BranchData[0]['id']) ? $BranchData[0]['id'] : '';
						$BranchName = isset($BranchData[0]['BranchName']) ? $BranchData[0]['BranchName'] : '';
						
						if($BranchID == ''){
							$err['BranchID'] = '1';
							$BranchName = $txtBeanch;
							$errMsg .= $a.' - '.$txtBeanch.' is not found <br>';
						}
						
						if(strtotime($date) == 0){
							$err['Date'] = '1';
							$errMsg .= $a.' - Date is empty or invalide <br>';
						}
						
						if($GpAmount == ''){
							$err['GpAmount'] = '1';
							$errMsg .= $a.' - GpAmount is empty <br>';
						}
						
						if($NetProfit == ''){
							$err['NetProfit'] = '1';
							$errMsg .= $a.' - NetProfit is empty <br>';
						}
						
						//$checkIsExist = $this->monthlygp_model->checkRecExists($BranchID, $Date);
						
						
						$fetchData[] = array('BranchID' => $BranchID, 'BranchName' => $BranchName, 'Date' => $Date, 'GpAmount' => $GpAmount, 'NetProfit' => $NetProfit,'error'=>$err);
						$a++;
					}           
					
					$data['data'] = $fetchData;
					$data['fileID'] = @$fileID;
					$data['errMsg'] = $errMsg;
					$data['date'] = $date;
					$data['checkDate'] = count($check);
					//pre($data);exit;
					$this->load->view('managegp/import_list',$data);
				} else {
					$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
					redirect(base_url('c=monthlygp','location'));
				}
			}else{
				
				
				$txt = file_get_contents($inputFileName);
				$convert = explode("\n", $txt);
				if(empty($convert)){
					$this->Page->setMessage('<div class="msg_error">Files is invalide or empty</div>');
					redirect('c=monthlygp', 'location');
				}
				$length = count($convert);
				$a = 1;
				for($i = 2; $i <= $length; $i++){
					$sdata = explode("\t",$convert[$i]);
					if(!is_array($sdata) || empty($sdata)) continue;
					if($sdata[0] == '' && $sdata[5] == '' && $sdata[8] == '') continue;
					if(strtolower(trim($sdata[0])) == strtolower('Total')) continue;
					//pre($sdata);
					
					$err 		= array();
					$Branch 	= $sdata[0];
					$Date 		= $date;
					$GpAmount 	= $sdata[5];
					$NetProfit 	= $sdata[8];
					
					$txtBeanch 	=  $Branch;
					
					$BranchData = $this->monthlygp_model->getBranchIdByName($Branch);
					$BranchID = isset($BranchData[0]['id']) ? $BranchData[0]['id'] : '';
					$BranchName = isset($BranchData[0]['BranchName']) ? $BranchData[0]['BranchName'] : '';
					
					if($BranchID == ''){
						$err['BranchID'] = '1';
						$BranchName = $txtBeanch;
						$errMsg .= $a.' - '.$txtBeanch.' is not found <br>';
					}
					
					if(strtotime($date) == 0){
						$err['Date'] = '1';
						$errMsg .= $a.' - Date is empty or invalide <br>';
					}
					
					if($GpAmount == ''){
						$err['GpAmount'] = '1';
						$errMsg .= $a.' - GpAmount is empty <br>';
					}
					
					if($NetProfit == ''){
						$err['NetProfit'] = '1';
						$errMsg .= $a.' - NetProfit is empty <br>';
					}
					$fetchData[] = array('BranchID' => $BranchID, 'BranchName' => $BranchName, 'Date' => $Date, 'GpAmount' => $GpAmount, 'NetProfit' => $NetProfit,'error'=>$err);
					$a++;
					
				}
				$data['data'] = $fetchData;
				$data['fileID'] = @$fileID;
				$data['errMsg'] = $errMsg;
				$data['date'] = $date;
				$data['checkDate'] = count($check);
				$this->load->view('managegp/import_list',$data);
			}
		}else{
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=monthlygp', 'location');
		}
	}
	
	function import_add_process(){
		
		
		
		$BranchID = $this->input->post('BranchID');
		$Date = $this->input->post('Date');
		$GpAmount = $this->input->post('GpAmount');
		$NetProfit = $this->input->post('NetProfit');
		$totalLength = intval($this->input->post('totalLength'));
		$fileID = $this->input->post('fileID');
		if($fileID == ''){
			$this->Page->setMessage('<div class="msg_error">Please select file first</div>');
			redirect('c=monthlygp', 'location');
		}
		
		$date = date('Y-m-d',strtotime($this->input->post('date')));
		$check = $this->monthlygp_model->getMonthModule($date, $this->module);
		if(!empty($check)){
			foreach($check as $file){
				$this->monthlygp_model->removeOldData($file['id'],$fileID);
			}
		}
		
		for($i = 0; $i < $totalLength; $i++){
			$data['BranchID'] = $BranchID[$i];
			$data['Date'] = date('Y-m-d',strtotime($Date[$i]));
			$data['GpAmount'] = $GpAmount[$i];
			$data['NetProfit'] = $NetProfit[$i];
			$data['FileID'] = $fileID;
			$data['EntryType'] = 1;
			$data['insertDate'] = date('Y-m-d H:i:s');
			$data['insertBy'] = $this->Page->getSession("intUserId");
			$data['insertIp'] = $this->input->ip_address();
			$add[] = $this->monthlygp_model->addMonthlyGpData($data);
		}
		
		$this->Page->setMessage('REC_ADD_MSG');
		redirect('c=monthlygp', 'location');
	}
	
	function download_format(){
		$this->load->helper('download');
		force_download('../upload/file_format/monthlygpimport.xlsx', NULL);
	}
	
	function checkModuleUpload(){
		//error_reporting(-1);
		$date = $this->input->post('date');
		if($date == ''){
			$msg['error'] = 1;
			$msg['message'] = 'Date is empty!';
		}else{
			$check = $this->monthlygp_model->getMonthModule($date, $this->module);
			if(count($check) > 0){
				$msg['error'] = 1;
				$msg['message'] = 'This month data already added! \n Are you sure to remove and upload new data?';
			}else{
				$msg['error'] = 0;
				$msg['message'] = 'This month data already added!';
			}
		}
		echo json_encode($msg);
	}
	
}
