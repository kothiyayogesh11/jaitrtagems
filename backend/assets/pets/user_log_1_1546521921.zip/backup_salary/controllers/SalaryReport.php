<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SalaryReport extends CI_Controller {
    function __construct(){
        parent::__construct();
        $this->load->model("SalaryReport_model",'salary_report_model',true);
    }

    public function index(){
        $data = array();
		$search_date = $this->Page->getRequest('search_date');
     //   $search_date = $this->Page->getRequest('search_date');
		
        //if($search_date)
       // {
        $salaryHeadArr = array();
        $rsSalaryHeadMaster = $this->salary_report_model->getSalaryHeadMaster();
        if(count($rsSalaryHeadMaster) > 0)
        {
        	foreach ($rsSalaryHeadMaster AS $salaryHead)
            {
            	$salaryHeadArr[$salaryHead['code']] = $salaryHead['name'];
            }
        }

		$designationArr = array();
		$rsDesignationMaster = $this->salary_report_model->getDesignationMaster();
		if(count($rsDesignationMaster) > 0)
		{
			foreach ($rsDesignationMaster AS $designation)
			{
				$designationArr[$designation['id']] = $designation['name'];
			}
		}

		$rsLWPData = $this->salary_report_model->getEmployeeLeavereport($search_date);
		$searchCriteria = array();
		$this->salary_report_model->searchCriteria=$searchCriteria;
		$rsData = $this->salary_report_model->getReportData($search_date);
		$empArr = array();
		$empSalaryArr = array();
		if($rsData)
		{
			foreach ($rsData AS $data)
			{
				$empId = $data['empID'];
			
				if(!isset($empArr[$empId]))
				{
					$empArr[$empId]['EmpId'] = $empId;
					$empArr[$empId]['EmpCode'] = $data['EmpCode'];
					$empArr[$empId]['EmpExtCode'] = $data['EmpExtCode'];
					$empArr[$empId]['EmpFullName'] = $data['EmpFullName'];
					$empArr[$empId]['DesignationId'] = $data['DesignationID'];
					$empArr[$empId]['days'] = $data['days'];
					$empArr[$empId]['Branch'] = $data['BranchName'];
					$empArr[$empId]['Company'] = $data['companyName'];
					$empArr[$empId]['LWP'] = $rsLWPData[$empId];
				}
				if(isset($empArr[$empId]['days']) && $empArr[$empId]['days']<$data['days'])
				{
					$empArr[$empId]['days'] = $data['days'];
				}
				$empSalaryArr[$empId][$data['code']] = $data['amount'];
			}
		}

        $data['designationArr'] = $designationArr;
        $data['salaryHeadArr'] = $salaryHeadArr;
        $data['empSalaryArr'] = $empSalaryArr;
        $data['empArr'] = $empArr;
        $data['search_date'] = $search_date;
		
		$isExport = $this->input->post_get('export');
		if($isExport == 'excel'){
			//pre($data);exit;
			$this->excel($data);
		}else{
        	$this->load->view('salary_report/list', $data);
		}
    }
	
	function getAlphas($len = 0){
		$alphas = range('A', 'Z');
		$mainVal = $alphas;
		$i = 0;
		$ik = 0;
		foreach($alphas as $val){
			if($i > 25) $ik++;
			$mainVal[] = $alphas[$ik].''.$val;
			$i++;
		}
		return $mainVal[$len];
	}
	
	
	function excel($data = array()){
		error_reporting(-1);
		if(empty($data)){
			return FALSE;
		}
		require(APPPATH . '/third_party/PHPExcel-1.8/Classes/PHPExcel.php');
		require(APPPATH . '/third_party/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');
		
		$excel = new PHPExcel();
		$excel->getProperties()->setCreator();
		$excel->getProperties()->setLastModifiedBy();
		$excel->getProperties()->setTitle();
		$excel->getProperties()->setSubject();
		$excel->getProperties()->setDescription();
		
		$excel->setActiveSheetIndex(0);
		
		$excel->getActiveSheet()->SetCellValue('A1','Emp Code');
		$excel->getActiveSheet()->SetCellValue('B1','Employee Name');
		$excel->getActiveSheet()->SetCellValue('C1','Designation');
		$excel->getActiveSheet()->SetCellValue('D1','Branch');
		$excel->getActiveSheet()->SetCellValue('E1','Companay');
		$excel->getActiveSheet()->SetCellValue('F1','Days');
		$excel->getActiveSheet()->SetCellValue('G1','LWP');
		$excel->getActiveSheet()->SetCellValue('H1','Basic');
		$excel->getActiveSheet()->SetCellValue('I1','ConveyanceAllowence');
		$excel->getActiveSheet()->SetCellValue('J1','HRA');
		$excel->getActiveSheet()->SetCellValue('K1','SpecialAllowence');
		$excel->getActiveSheet()->SetCellValue('L1','Incentive');
		$excel->getActiveSheet()->SetCellValue('M1','Travel Allowance');
		$excel->getActiveSheet()->SetCellValue('N1','StandardAllowence');
		$excel->getActiveSheet()->SetCellValue('O1','OT');
		$excel->getActiveSheet()->SetCellValue('P1','Committed Pay');
		$excel->getActiveSheet()->SetCellValue('Q1','Gross Pay');
		$excel->getActiveSheet()->SetCellValue('R1','TDS');
		$excel->getActiveSheet()->SetCellValue('S1','PF');
		$excel->getActiveSheet()->SetCellValue('T1','ESIC');
		$excel->getActiveSheet()->SetCellValue('U1','LoneEmi');
		$excel->getActiveSheet()->SetCellValue('V1','Other Deduction');
		$excel->getActiveSheet()->SetCellValue('W1','Security Deposit');
		$excel->getActiveSheet()->SetCellValue('X1','P.TAX');
		$excel->getActiveSheet()->SetCellValue('Y1','Gross Diducation');
		$excel->getActiveSheet()->SetCellValue('Z1','Net Pay');
		
		$row = 2;
		foreach($data['empArr'] as $val){
			
			$ak = 0;
			$excel->getActiveSheet()->SetCellValue($this->getAlphas($ak).$row,$val['EmpCode']);
			$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,$val['EmpFullName']);
			$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,$data['designationArr'][$val['DesignationId']]);
			$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,$val['Branch']);
			$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,$val['Company']);
			$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,$val['days']);
			$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,($val['LWP']>0?$val['LWP']:0));
 			
			//pre($data['empSalaryArr'][$val['EmpId']][$code],1);
			
			$HeadVal = round($val['empSalaryArr'][$val['EmpId']][$code]);
			if(count($data['salaryHeadArr']) > 0): 
				foreach ($data['salaryHeadArr'] AS $code=>$name):
					$HeadVal = round($data['empSalaryArr'][$val['EmpId']][$code]);
					$excel->getActiveSheet()->SetCellValue($this->getAlphas(++$ak).$row,$HeadVal);
			   endforeach;
			endif;
			$row++;
		}
		
		$fname = 'salary_report_excel_ptpl_'.time().'.xlsx';
		$excel->getActiveSheet()->setTitle("PTPL_SALARY_REPORT");
		header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		header("Content-Disposition: attachment;filename='".$fname."'");
		header("Cache-Control: max-age=0");
		$writer = PHPExcel_IOFactory::createWriter($excel,'Excel2007');
		$writer->save('php://output');
		exit;
	}
}
