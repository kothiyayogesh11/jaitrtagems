<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class EmployeeTDS_model extends Data {
	public $searchCriteria; 
	var $tbl_employee_masater = "employee_masater";
	var $tbl_emp_salary_detail = 'emp_salary_detail';
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_scheme_master = "scheme_master";
	var $tbl_combo_master = "combo_master";
	var $tbl_designation = "designation";
	var $tbl_loanMaster = "LoanMaster";
	var $tbl_EMIMaster = "EMIMaster";
	var $tbl_employee_tds = "employee_tds";
	function __construct(){
        parent::__construct();
		$this->tbl = $this->tbl_employee_tds;
    }
	
	function addTds($data = array()){
		return $this->db->insert($this->tbl_employee_tds,$data);
	}
	
	function updateTds($data = array(), $id = NULL){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_employee_tds);
	}
	
	function getemptds(){
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selectField = "tds.id as id, tds.tdsDate as tdsDate, tds.tdsAmount as tdsAmount, em.EmpFullName as emp_name, cm.name as company_name, bm.BranchName as branch_name";		
		$whereClaue = " 1=1 AND tds.delete_flag = 0 ";
		$orderField = " tds.id";
		$orderDir = " DESC";
				
		$this->db->select($selectField);
		$this->db->from($this->tbl_employee_tds.' tds');
		$this->db->join($this->tbl_employee_masater.' em','em.id = tds.empID','left');
		$this->db->join($this->tbl_branch_master.' bm','bm.id = em.BranchID','left');
		$this->db->join($this->tbl_companymaster.' cm','cm.id = em.CompanyID','left');
		$this->db->where($whereClaue);
		$this->db->order_by($orderField,$orderDir);
		return $this->db->get()->result_array();
	}
	
    function update_employee($emp_id){
		$appointment = array('isLast' => 0);    
		$this->db->where('empID', $emp_id);
		$this->db->update('emp_salary_detail', $appointment);    
  	}
  
	function get_employee_by_code($code = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpCode'=>$code))->result_array();
	}
  
  	function update_is_last($where = array(),$status = 0){
		return $this->db->set(array('isLast'=>$status))->where($where)->update($this->tbl_emp_salary_detail);
	}
	/*
	function addImportSalary($data = array()){
		return $this->db->insert($this->tbl_emp_salary_detail,$data);
	}*/
   
	function addFileList($data){
		return $this->db->insert($this->tbl_file_list,$data);
	}
	
	
	function getEmployeeIdByName($name = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpFullName'=>$name))->result_array();	
	}
	
	function getMonthModule($date, $mod){
		$where = "ModuleCode = '".$mod."' AND MONTH(Date) = MONTH('".$date."') AND YEAR(Date) = YEAR('".$date."') AND delete_flag = 0 ";
		return $this->db->get_where($this->tbl_file_list,$where)->result_array();
	}
	
	function removeOldData($fileID = NULL, $newID = NULL){
		$this->db->set(array('delete_flag'=>1))->where('id = '.$fileID.' AND id NOT IN ('.$newID.')')->update($this->tbl_file_list);
		$this->db->set(array('delete_flag'=>1))->where('FileID = '.$fileID.' AND FileID NOT IN ('.$newID.')')->update($this->tbl_employee_tds);
	}
}