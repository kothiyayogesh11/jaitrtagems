<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class department_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'departmentmaster';
    }

    function getdepartment()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "d.Code as Code, d.Name as Name, d.ToComp as ToComp, d.id as id,cm.name as ComName";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 AND d.delete_flag = 0";

        // By city name
       /* if(isset($searchCriteria['city_name']) && $searchCriteria['city_name'] != "")
        {
            $whereClaue .= 	" AND ctm.city_name='".$searchCriteria['city_name']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND city_id !=".$searchCriteria['not_id']." ";
        }*/
	    if(isset($searchCriteria['Code']) && $searchCriteria['Code'] != "")
        {
            $whereClaue .= 	" AND (d.Code  = '".$searchCriteria['Code']."' ";
        }
	   
	   if(isset($searchCriteria['Name']) && $searchCriteria['Name'] != "")
        {
            $whereClaue .= 	" OR d.Name  = '".$searchCriteria['Name']."' )";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND d.id !=".$searchCriteria['not_id']." ";
        }
        $orderField = " d.id";
        $orderDir = " DESC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM departmentmaster as d left join companymaster as cm on cm.id = d.ToComp ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
   /* function insertlocationID($intCenterID){
	     $appointment = array('LocationID' => $intCenterID);    
		$this->db->where('id', $intCenterID);
		$this->db->update('worklocationmaster', $appointment); 
    }*/
}