<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_setting_model extends Data {
	public $searchCriteria; 
	function __construct() 
	{
        parent::__construct();
        //$this->tbl = 'customer_master';
    }
	
	function getDetails(){
        $this->tbl = 'employeesettings';
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		
		$selectField = "c.name as sname, c.isRange as isRange , c.from as from, c.to as to, cm.combo_value as typ,c.id as id, shm.code as code, cm.cal_type as cal_type";
		if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
			$selectField = 	$searchCriteria['selectField'];
		}
		
		$whereClaue = "WHERE 1=1 AND c.delete_flag = 0 and cm.combo_case  = 'SETTINGTYPE'";
        // By email
      /*  if(isset($searchCriteria['empid']) && $searchCriteria['empid'] != ""){
            $whereClaue .= 	" AND (empid='".$searchCriteria['empid']."' ";
        }
		if(isset($searchCriteria['email']) && $searchCriteria['email'] != ""){
            $whereClaue .= 	" OR email='".trim(strtolower($searchCriteria['email']))."') ";
        }*/

		// By Status
		/*if(isset($searchCriteria['status']) && $searchCriteria['status'] != ""){
			$whereClaue .= 	" AND cm.status='".$searchCriteria['status']."' ";
		}
		*/
		// Not In
		/*if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
			$whereClaue .= 	" AND c.id !=".$searchCriteria['not_id']." ";
		}*/
		
		$orderField = " c.id";
		$orderDir = " ASC";
		
		// Set Order Field
		if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
			$orderField = $searchCriteria['orderField'];
		}
		
		// Set Order Field
		if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
			$orderDir = $searchCriteria['orderDir'];
		}
		
		/*$sqlQuery = "SELECT
					  	".$selectField."
					 FROM employeesettings as s on left join combo_master ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";*/
		$sqlQuery = "SELECT ".$selectField." FROM employeesettings as c left join combo_master as cm on cm.combo_key = c.type left join salary_head_master as shm on c.salary_head_code = shm.id ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

		
		//echo $sqlQuery; exit;
		$result     = $this->db->query($sqlQuery);
		$rsData     = $result->result_array();
		return $rsData;
	}

    /*function getCustomersCredits(){
        $this->tbl = 'customer_credit';
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By Customer Id
        if(isset($searchCriteria['customer_id']) && $searchCriteria['customer_id'] != ""){
            $whereClaue .= 	" AND cc.customer_id='".$searchCriteria['customer_id']."' ";
        }


        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
            $whereClaue .= 	" AND credit_id !=".$searchCriteria['not_id']." ";
        }
        $orderField = " cc.allocated_on_date";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT
					  	".$selectField."
					 FROM customer_credit AS cc LEFT JOIN customer_master AS cm
							ON cc.customer_id = cm.id  ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }*/
}