<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class SalaryReport_model extends Data {
	
	var $tbl_employee_masater = "employee_masater";
	var $tbl_designation = "designation";
	var $tbl_branch_master = "branch_master";
	var $tbl_companymaster = "companymaster";

    public $searchCriteria;
    public $tbl;

    function __construct(){
        parent::__construct();
        $this->tbl = 'salary_employee_monthly_head';
    }

    // Get Salary Head Master
    public function getSalaryHeadMaster()
    {
        $this->db->select('shm.id,shm.code,shm.name,shm.type,shm.is_pre_defined');
        $this->db->from('salary_head_master shm');
        $this->db->where('shm.delete_flag=0');
        $this->db->order_by("headIndex", "ASC");
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        return $rsData;
    }

    // Get Designation Master
    public function getDesignationMaster()
    {
        $this->db->select('d.id,d.Code,d.name');
        $this->db->from('designation d');
        $this->db->where('d.delete_flag=0');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        return $rsData;
    }
    // Get Employee leave by month and year
    public function getEmployeeLeavereport($calc_date)
    {
        //echo $calc_date;die;
        $calc_dates = date("Y-m-01",strtotime($calc_date));
        $calc_datee = date("Y-m-t",strtotime($calc_date));
        $this->db->select('el.id,el.employeeId,el.no_of_leave');
        $this->db->from('emp_leave el');
        //$this->db->where('el.delete_flag=0 AND el.fromdate IS NOT NULL AND DATE_FORMAT(el.fromdate,"%Y-%m") = "'.$calc_date.'"');
        $this->db->where('el.delete_flag=0 AND el.fromdate IS NOT NULL AND el.fromdate BETWEEN "'.$calc_dates.'" AND "'.$calc_datee.'"');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        $empLeaveArr = array();
        if(count($rsData) > 0)
        {
            foreach ($rsData AS $data)
            {
                $empLeaveArr[$data['employeeId']] = $data['no_of_leave'];
            }
        }

        return $empLeaveArr;
    }
    
    function getReportData($date)
    {
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selEmp = $this->input->get('selEmp');
		$selDeg = $this->input->get('selDeg');
		$selBrch = $this->input->get('selBrch');
		$selComp = $this->input->get('selComp');
		$search_date = $this->input->get('search_date');
		
		
		$where = ' semh.delete_flag=0 ';
		
		if($search_date == '' && $selEmp == '' && $selDeg == '' && $selBrch == '' && $selComp == '' ){
			$where .= ' AND semh.year = YEAR(CURRENT_DATE()) AND semh.month = MONTH(CURRENT_DATE())';
		}
		
		//if($date != '') $where .= ' AND semh.year = YEAR("'.$date.'") AND semh.month = MONTH("'.$date.'")';
		if($search_date != '') $where .= ' AND semh.year = YEAR("'.$search_date.'") AND semh.month = MONTH("'.$search_date.'")';
		if($selEmp != '') $where .= " AND semh.empID = ".$selEmp." ";
		if($selDeg != '') $where .= " AND em.DesignationID = ".$selDeg." ";
		if($selBrch != '') $where .= " AND semh.empBranch = ".$selBrch." ";
		if($selComp != '') $where .= " AND semh.empCompany = ".$selComp." ";
		
        $this->db->select('semh.*,shm.code,em.EmpCode,em.EmpExtCode,em.EmpFullName,em.DesignationID');
        $this->db->select('bm.BranchName');
        $this->db->select('cm.Name AS companyName');
        $this->db->from('salary_employee_monthly_head semh');
        $this->db->join('salary_head_master shm','semh.headID = shm.id');
        $this->db->join('employee_masater em','semh.empID = em.id','left');
        $this->db->join('branch_master bm','semh.empBranch = bm.id','left');
        $this->db->join('companymaster cm','semh.empCompany = cm.id','left');
        $this->db->where($where);
		$this->db->order_by('semh.empID','ASC');
        $result = $this->db->get();

        //echo $this->db->last_query(); exit;

        $rsData = $result->result_array();
        return $rsData;
    }
}