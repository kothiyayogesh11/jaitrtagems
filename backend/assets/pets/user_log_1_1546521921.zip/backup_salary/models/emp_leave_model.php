<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_leave_model extends Data {
	var $tbl_employee_masater = "employee_masater";
	var $tbl_emp_salary_detail = 'emp_salary_detail';
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_scheme_master = "scheme_master";
	var $tbl_combo_master = "combo_master";
	var $tbl_designation = "designation";
	var $tbl_loanMaster = "LoanMaster";
	var $tbl_EMIMaster = "EMIMaster";
	var $tbl_employee_tds = "employee_tds";
	var $tbl_emp_leave = "emp_leave";
    function __construct(){
        parent::__construct();
        $this->tbl = 'emp_leave';
    }

    function getLeave(){
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*,l.id as ids";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 AND l.delete_flag = 0";
        $orderField = " l.id";
        $orderDir = " DESC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM emp_leave as l left join employee_masater as e  on e.id = l.employeeId ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
	
	function addLeave($data = array()){
		return $this->db->insert($this->tbl_emp_leave,$data);
	}
	
	function addFileList($data){
		return $this->db->insert($this->tbl_file_list,$data);
	}
	
	function get_employee_by_code($code = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpCode'=>$code))->result_array();
	}
	
	function getEmployeeIdByName($name = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpFullName'=>$name))->result_array();	
	}
	
	function getMonthModule($date, $mod){
		$where = "ModuleCode = '".$mod."' AND MONTH(Date) = MONTH('".$date."') AND YEAR(Date) = YEAR('".$date."') AND delete_flag = 0 ";
		return $this->db->get_where($this->tbl_file_list,$where)->result_array();
	}
	
	function removeOldData($fileID = NULL, $newID = NULL){
		$this->db->set(array('delete_flag'=>1))->where('id = '.$fileID.' AND id NOT IN ('.$newID.')')->update($this->tbl_file_list);
		$this->db->set(array('delete_flag'=>1))->where('FileID = '.$fileID.' AND FileID NOT IN ('.$newID.')')->update($this->tbl_emp_leave);
	}
}