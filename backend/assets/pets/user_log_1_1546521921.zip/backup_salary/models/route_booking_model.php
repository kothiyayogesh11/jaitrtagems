<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class route_booking_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'route_booking';
    }

    function getStopRouteList()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By airport name
        if(isset($searchCriteria['stop_route_code']) && $searchCriteria['stop_route_code'] != "")
        {
            $whereClaue .= 	" AND rs.stop_route_code='".$searchCriteria['stop_route_code']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND rs.id !=".$searchCriteria['not_id']." ";
        }

        $orderField = " rs.id";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM route_booking AS rs 
                            LEFT JOIN route AS rut
							ON rs.main_route_id = rut.id 
							LEFT JOIN city_master AS cm1
							ON rs.from_city_id = cm1.city_id 
							LEFT JOIN city_master AS cm2
							ON rs.to_city_id = cm2.city_id 
							LEFT JOIN air_master AS am
							ON rs.air_id = am.id
							LEFT JOIN airport_master AS apm
							ON rs.airport_id = apm.id
							".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
}