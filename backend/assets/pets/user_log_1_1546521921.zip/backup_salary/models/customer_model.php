<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class customer_model extends Data {
	public $searchCriteria; 
	function __construct() 
	{
        parent::__construct();
        //$this->tbl = 'customer_master';
    }
	
	function getCustomers(){
        $this->tbl = 'customer_master';
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selectField = "*";
		if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
			$selectField = 	$searchCriteria['selectField'];
		}
		
		$whereClaue = "WHERE 1=1 ";
        // By email
        if(isset($searchCriteria['email']) && $searchCriteria['email'] != ""){
            $whereClaue .= 	" AND cm.email='".$searchCriteria['email']."' ";
        }
		
		// By Status
		if(isset($searchCriteria['status']) && $searchCriteria['status'] != ""){
			$whereClaue .= 	" AND cm.status='".$searchCriteria['status']."' ";
		}
		
		// Not In
		if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
			$whereClaue .= 	" AND id !=".$searchCriteria['not_id']." ";
		}
		
		$orderField = " cm.first_name";
		$orderDir = " ASC";
		
		// Set Order Field
		if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
			$orderField = $searchCriteria['orderField'];
		}
		
		// Set Order Field
		if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
			$orderDir = $searchCriteria['orderDir'];
		}
		
		$sqlQuery = "SELECT
					  	".$selectField."
					 FROM customer_master AS cm ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";
		
		//echo $sqlQuery; exit;
		$result     = $this->db->query($sqlQuery);
		$rsData     = $result->result_array();
		return $rsData;
	}

    function getCustomersCredits(){
        $this->tbl = 'customer_credit';
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By Customer Id
        if(isset($searchCriteria['customer_id']) && $searchCriteria['customer_id'] != ""){
            $whereClaue .= 	" AND cc.customer_id='".$searchCriteria['customer_id']."' ";
        }


        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
            $whereClaue .= 	" AND credit_id !=".$searchCriteria['not_id']." ";
        }
        $orderField = " cc.allocated_on_date";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT
					  	".$selectField."
					 FROM customer_credit AS cc LEFT JOIN customer_master AS cm
							ON cc.customer_id = cm.id  ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
}