<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class user_model extends Data {
	var $tbl_employee_masater = "employee_masater";
	var $tbl_companymaster = "companymaster";
	var $tbl_designation = "designation";
	var $tbl_combo_master = "combo_master";
	var $tbl_departmentmaster = "departmentmaster";
	var $tbl_worklocationmaster = "worklocationmaster";
	public $searchCriteria; 
	function __construct() 
	{
        parent::__construct();
       // $this->tbl = 'user_master';
    }
	
	function getUsers(){
		error_reporting(-1);
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$Code = $this->input->get('Code');
		$selEmp = $this->input->get('selEmp');
		$selComp = $this->input->get('selComp');
		$designation = $this->input->get('designation');
		$status = $this->input->get('status');
		
		
		$selectField = "um.EmpCode as EmpCode, um.EmpFullName as EmpFullName , um.BranchID as userBranch,  wl.LocationName as LocationName,dm.name as dmname, de.name as dename ,cm.Name as cmname, um.Email as empemail , um.Moblie as empmobile ,um.status as empstatus,um.id as employeeid";
		
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "") $selectField = 	$searchCriteria['selectField'];
        
        $whereClaue = " 1=1 ";

        if(isset($searchCriteria['EmpCode']) && $searchCriteria['EmpCode'] != "") $whereClaue .= 	" AND (um.EmpCode  = '".$searchCriteria['EmpCode']."' ";  
	   	if(isset($searchCriteria['EmpExtCode']) && $searchCriteria['EmpExtCode'] != "") $whereClaue .= 	" OR um.EmpExtCode  = '".$searchCriteria['EmpExtCode']."' )";
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")  $whereClaue .= 	" AND um.id !=".$searchCriteria['not_id']." ";
        
		if($Code != '') $whereClaue .= " AND um.EmpCode = ".$Code." ";
		if($selEmp != '') $whereClaue .= " AND um.id = ".$selEmp." ";
		if($selComp != '') $whereClaue .= " AND um.CompanyID = ".$selComp." ";
		if($designation != '') $whereClaue .= " AND um.DesignationID = ".$designation." ";
		if($status != '') $whereClaue .= " AND um.delete_flag = ".$status." ";
		
		$orderField = " um.id";
        $orderDir = " DESC";

        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")  $orderField = $searchCriteria['orderField'];
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")  $orderDir = $searchCriteria['orderDir'];

		/*$sqlQuery = "SELECT ".$selectField." FROM employee_masater AS um left join companymaster as cm on cm.id = um.CompanyID left join designation as de on de.id = um.DesignationID left join departmentmaster as dm on dm.id = um.EmpDeptID left join 	worklocationmaster as wl on wl.LocationID = um.EmpWorkLocationId ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";*/
		
		$this->db->select($selectField);
		$this->db->from($this->tbl_employee_masater.' um');
		$this->db->join($this->tbl_companymaster.' cm','cm.id = um.CompanyID','left');
		$this->db->join($this->tbl_designation.' de','de.id = um.DesignationID','left');
		$this->db->join($this->tbl_departmentmaster.' dm','dm.id = um.EmpDeptID','left');
		$this->db->join($this->tbl_worklocationmaster.' wl','wl.LocationID = um.EmpWorkLocationId','left');
		$this->db->where($whereClaue);
		$this->db->order_by($orderField, $orderDir);
		return $this->db->get()->result_array();
	}
	
	public function getAssignCompanyDetail()
	{
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selectField = "*";
		if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
		{
			$selectField = 	$searchCriteria['selectField'];
		}
		
		$whereClaue = "WHERE 1=1 ";
		// By user
		if(isset($searchCriteria['userId']) && $searchCriteria['userId'] != "")
		{
			$whereClaue .= 	" AND map.user_id='".$searchCriteria['userId']."' ";
		}
		
		// By Company
		if(isset($searchCriteria['companyId']) && $searchCriteria['companyId'] != "")
		{
			$whereClaue .= 	" AND map.company_id='".$searchCriteria['companyId']."' ";
		}
		
		$orderField = " map.id";
		$orderDir = " ASC";
		
		// Set Order Field
		if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
		{
			$orderField = $searchCriteria['orderField'];
		}
		
		// Set Order Field
		if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
		{
			$orderDir = $searchCriteria['orderDir'];
		}
		
		$sqlQuery = "SELECT
					  	".$selectField."
					 FROM map_user_company AS map
					 	JOIN user_master AS um
							ON map.user_id = um.user_id
					  	JOIN company_master AS com
							ON map.company_id = com.com_id ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";
		
		//echo $sqlQuery; exit;
		$result     = $this->db->query($sqlQuery);
		$rsData     = $result->result_array();
		return $rsData;
	}
	
	public function getAssignDeptDetail()
	{
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selectField = "*";
		if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
		{
			$selectField = 	$searchCriteria['selectField'];
		}
		
		$whereClaue = "WHERE 1=1 ";
		// By user
		if(isset($searchCriteria['userId']) && $searchCriteria['userId'] != "")
		{
			$whereClaue .= 	" AND map.user_id='".$searchCriteria['userId']."' ";
		}
		
		// By Company
		if(isset($searchCriteria['statusid']) && $searchCriteria['statusid'] != "")
		{
			$whereClaue .= 	" AND map.status_id='".$searchCriteria['statusid']."' ";
		}
		
		$orderField = " map.id";
		$orderDir = " ASC";
		
		// Set Order Field
		if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
		{
			$orderField = $searchCriteria['orderField'];
		}
		
		// Set Order Field
		if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
		{
			$orderDir = $searchCriteria['orderDir'];
		}
		
		$sqlQuery = "SELECT
					  	".$selectField."
					 FROM map_user_status AS map
					 	JOIN user_master AS um
							ON map.user_id = um.user_id
					  	JOIN status_master AS status
							ON map.status_id = status.status_id ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";
		
		//echo $sqlQuery; exit;
		$result     = $this->db->query($sqlQuery);
		$rsData     = $result->result_array();
		return $rsData;
	}
	
	# Auther : Nikunj Bambhroliya
	# Date : 21-10-2015
	# Description : get all active user types
	public function getUserTypes()
	{
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selectField = "*";
		if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
		{
			$selectField = 	$searchCriteria['selectField'];
		}
		
		$whereClaue = "WHERE 1=1 ";
		// By user type name
		if(isset($searchCriteria['userTypesName']) && $searchCriteria['userTypesName'] != "")
		{
			$whereClaue .= 	" AND u_typ_name='".$searchCriteria['userTypesName']."' ";
		}
		
		// By user Type Code
		if(isset($searchCriteria['userTypesCode']) && $searchCriteria['userTypesCode'] != "")
		{
			$whereClaue .= 	" AND u_typ_code='".$searchCriteria['userTypesCode']."' ";
		}
		
		// By Status
		if(isset($searchCriteria['status']) && $searchCriteria['status'] != "")
		{
			$whereClaue .= 	" AND status='".$searchCriteria['status']."' ";
		}
		
		// Not In
		if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
		{
			$whereClaue .= 	" AND u_typ_id !=".$searchCriteria['not_id']." ";
		}
		
		$orderField = " u_typ_id ";
		$orderDir = " ASC";
		
		// Set Order Field
		if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
		{
			$orderField = $searchCriteria['orderField'];
		}
		
		// Set Order Field
		if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
		{
			$orderDir = $searchCriteria['orderDir'];
		}
		
		$sqlQuery = "SELECT
					  	".$selectField."
					  FROM user_types ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";
		
		//echo $sqlQuery; exit;
		$result     = $this->db->query($sqlQuery);
		$rsData     = $result->result_array();
		return $rsData;
	}
	
	function getFailedWelcomeMail(){
		return $this->db->get_where('customer_master',array('sent_mail'=>1))->result_array();
	}
	
	function activeFauledMailCustomer($id){
		return $this->db->set(array('status'=>'ACTIVE','sent_mail'=>0))->where(array('id'=>$id))->update('customer_master');
	}
}