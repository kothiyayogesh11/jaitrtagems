<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class company_model extends Data {

    function __construct()
    {
        parent::__construct();		
        $this->tbl = 'companymaster';
    }

    function getComapny()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "c.Code as Code, c.Name as Name , c.Address as Address, cm.combo_value as Cstatus,c.id as id";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 AND delete_flag = 0 and cm.combo_case  = 'STATUSYESNO'";

        // By city name
       /* if(isset($searchCriteria['city_name']) && $searchCriteria['city_name'] != "")
        {
            $whereClaue .= 	" AND ctm.city_name='".$searchCriteria['city_name']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND city_id !=".$searchCriteria['not_id']." ";
        }*/
	   if(isset($searchCriteria['Code']) && $searchCriteria['Code'] != "")
        {
            $whereClaue .= 	" AND (c.Code  = '".$searchCriteria['Code']."' ";
        }
	   
	   if(isset($searchCriteria['Name']) && $searchCriteria['Name'] != "")
        {
            $whereClaue .= 	" OR c.Name  = '".$searchCriteria['Name']."' )";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND c.id !=".$searchCriteria['not_id']." ";
        }
	   
        $orderField = " c.id";
        $orderDir = " DESC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM companymaster as c left join combo_master as cm on cm.combo_key = c.IsPtpl  ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
   /* function insertlocationID($intCenterID){
	     $appointment = array('LocationID' => $intCenterID);    
		$this->db->where('id', $intCenterID);
		$this->db->update('worklocationmaster', $appointment); 
    }*/
}