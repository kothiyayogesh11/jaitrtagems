<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Salary_monthly_head_model extends Data {
	public $searchCriteria; 
	var $tbl_employee_masater = "employee_masater";
	var $tbl_emp_salary_detail = 'emp_salary_detail';
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_scheme_master = "scheme_master";
	var $tbl_combo_master = "combo_master";
	var $tbl_designation = "designation";
	var $tbl_loanMaster = "LoanMaster";
	var $tbl_EMIMaster = "EMIMaster";
	var $tbl_employee_tds = "employee_tds";
	var $tbl_salary_head_master = "salary_head_master";
	var $tbl_salary_employee_monthly_head = "salary_employee_monthly_head";
	function __construct(){
        parent::__construct();
		$this->tbl = $this->tbl_salary_employee_monthly_head;
    }
	
	function addSalaryHead($data = array()){
		return $this->db->insert($this->tbl,$data);
	}
	
	function updateSalaryHead($data = array(), $id = NULL){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl);
	}
	
	function get_salary_data(){
		$select = " seh.id as semh_id, seh.empID as empID, seh.amount as amount, seh.is_pre_defined as is_pre_defined, seh.headID as headID, seh.empCode as empCode, seh.empBranch as empBranch, seh.empCompany as empCompany, seh.empESINumber as empESINumber, seh.PFNo as PFNo, seh.month as month, seh.year as year, seh.date as date, seh.days as days, em.EmpFullName as empName, bm.BranchName as branch_name, cm.name as comp_name, sm.code as smCode";
		$where = " 1=1 ";
		$this->db->select($select);
		$this->db->from($this->tbl.' seh');
		$this->db->join($this->tbl_employee_masater.' em','em.id = seh.empID','left');
		$this->db->join($this->tbl_branch_master.' bm','bm.id = seh.empBranch','left');
		$this->db->join($this->tbl_companymaster.' cm','cm.id = seh.empCompany','left');
		$this->db->join($this->tbl_salary_head_master.' sm','sm.id = seh.headID','left');
		$this->db->where($where);
		$this->db->order_by('seh.id','DESC');
		return $this->db->get()->result_array();
	}
	
	function getSalaryHeadIdByHeadCode($code = NULL){
		return $this->db->get_where($this->tbl_salary_head_master,array('code'=>$code))->result_array();
	}
	
  
	function get_employee_by_code($code = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpCode'=>$code))->result_array();
	}
	
	function get_employee_by_id($id = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('id'=>$id))->result_array();
	}
   
	function addFileList($data){
		return $this->db->insert($this->tbl_file_list,$data);
	}
	
	
	function getEmployeeIdByName($name = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpFullName'=>$name))->result_array();	
	}
	
	function getMonthModule($date, $mod){
		$where = "ModuleCode = '".$mod."' AND MONTH(Date) = MONTH('".$date."') AND YEAR(Date) = YEAR('".$date."') AND delete_flag = 0 ";
		return $this->db->get_where($this->tbl_file_list,$where)->result_array();
	}
	
	function removeOldData($fileID = NULL, $newID = NULL){
		$this->db->set(array('delete_flag'=>1))->where('id = '.$fileID.' AND id NOT IN ('.$newID.')')->update($this->tbl_file_list);
		$this->db->set(array('delete_flag'=>1))->where('FileID = '.$fileID.' AND FileID NOT IN ('.$newID.')')->update($this->tbl);
	}
}