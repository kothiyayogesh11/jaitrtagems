<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 12/28/2017
 * Time: 12:56 PM
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
class image_setting_model extends Data{
	var $tbl_home_image = "home_image";
	var $tbl_category = "home_image_category";
    function __construct(){
        parent::__construct();
    }
	
	function getAllSettingImage($type = 1){
		//return $this->db->get_where($this->tbl_home_image, array('status'=>'ACTIVE'))->result_array();
	
		$select = "hi.id as img_id, hi.title as img_name, hi.file as image, hi.status as img_status, ci.title as cat_name";
		$this->db->select($select);
		$this->db->from($this->tbl_home_image.' hi');
		$this->db->join($this->tbl_category.' ci','ci.id = hi.category_id','left');
		if($type != '') $this->db->where(array('type'=>$type));
		return $this->db->get()->result_array();
		
	}
	
	function saveImage($insData,$id){
		return $this->db->set($insData)->where(array('id'=>$id))->update($this->tbl_home_image);
	}
	
	function image_delete($id = NULL){
		$imgData = $this->db->get_where($this->tbl_home_image,' id IN('.$id.')')->result_array();
		$delQuery = $this->db->delete($this->tbl_home_image,' id IN('.$id.')');
		if($delQuery) foreach($imgData as $val)	unlink('../upload/'.$val['file']);
		return $delQuery;
	}
	
	function getImage($id = NULL){
		return $this->db->get_where($this->tbl_home_image,array('id'=>$id))->result_array();
	}
	
	function addImage($insData){
		return $this->db->insert($this->tbl_home_image, $insData);
	}
	
	function saveImageCategory($data = array(), $id = NULL){
		return $id != NULL ? $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_category) : $this->db->insert($this->tbl_category,$data);
	}
	
	function cateList($id = NULL){
		$this->db->select('*');
		$this->db->from($this->tbl_category);
		if($id != NULL) $this->db->where(array('id'=>$id));
		return $this->db->order_by('sort_order','ASC')->get()->result_array();
	}
	
	function cate_delete($ids = NULL){
		$imgData = $this->db->get_where($this->tbl_home_image,' category_id IN('.$ids.') ')->result_array();
		$delQuery = $this->db->delete($this->tbl_category,' id IN('.$ids.') ');
		if($delQuery) foreach($imgData as $val) if(unlink('../upload/'.$val['file'])) $this->db->delete($this->tbl_home_image,array('id'=>$val['id']));
		return $delQuery;
	}
	
}
?>