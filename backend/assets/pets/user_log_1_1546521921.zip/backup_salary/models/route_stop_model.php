<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class route_stop_model extends Data {

    function __construct(){
        parent::__construct();
        $this->tbl = 'route_stop';
    }

    function getStopRouteList(){
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By airport name
        if(isset($searchCriteria['stop_route_code']) && $searchCriteria['stop_route_code'] != ""){
            $whereClaue .= 	" AND rs.stop_route_code='".$searchCriteria['stop_route_code']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
            $whereClaue .= 	" AND rs.id !=".$searchCriteria['not_id']." ";
        }
		
		if($this->input->post('status') != ''){
			$whereClaue .= 	" AND rs.status = '".$this->input->post('status')."' ";
		}else{
			$whereClaue .= 	" AND rs.status = 'ACTIVE' ";
		}
		if($this->input->post('rout_code') != ''){
			$whereClaue .= 	" AND rs.stop_route_code = '".$this->input->post('rout_code')."' ";
		}
		if($this->input->post('from_city') != ''){
			$whereClaue .= 	" AND rs.from_city_id = '".$this->input->post('from_city')."' ";
		}
		if($this->input->post('to_city') != ''){
			$whereClaue .= 	" AND rs.to_city_id = '".$this->input->post('to_city')."' ";
		}
		if($this->input->post('departure_date') != ''){
			$whereClaue .= 	" AND DATE(rs.departure) = DATE('".$this->input->post('departure_date')."') ";
		}
		
        $orderField = " rs.id";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM route_stop AS rs 
                            LEFT JOIN route AS rut
							ON rs.main_route_id = rut.id 
							LEFT JOIN city_master AS cm1
							ON rs.from_city_id = cm1.city_id 
							LEFT JOIN city_master AS cm2
							ON rs.to_city_id = cm2.city_id 
							LEFT JOIN air_master AS am
							ON rs.air_id = am.id
							LEFT JOIN airport_master AS apm
							ON rs.airport_id = apm.id
							".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
	
	function getRouteStopData($id){
		return $this->db->get_where('route_stop',array('id'=>$id))->result_array();
	}
	
	function getCopyRoutData($id = NULL){
		return $this->db->get_where('route_stop',array('id'=>$id))->result_array();
	}
	
	function getRoutStopSeats($routID = NULL, $routStopID = NULL){
		return $this->db->get_where('rout_stop_seats',array('RoutStopid'=>$routStopID,'RoutID'=>$routID,'status'=>'ACTIVE'))->result_array();
	}
	
	function CopyRoutStop($data){
		return $this->db->insert('route_stop',$data);
	}
	
	function copySeat($insStopSeat){
		return $this->db->insert('rout_stop_seats',$insStopSeat);
	}
	
	function GetSeatFare($where){
		return $this->db->get_where('route_stop_seat_fare',$where)->result_array();
	}
	
	function copySeatFare($data){
		return $this->db->insert('route_stop_seat_fare',$data);
	}
	
	function addNewSeat($ArrInsSeat){
		return $this->db->insert('rout_stop_seats',$ArrInsSeat);
	}
	
	function addNewFare($data){
		return $this->db->insert('route_stop_seat_fare',$data);
	}
	
	function UpdateSeat($where = array(), $data = array()){
		return $this->db->set($data)->where($where)->update('rout_stop_seats');
	}
	
	function UpdateSeatFare($where =array(), $data = array()){
		return $this->db->set($data)->where($where)->update('route_stop_seat_fare');
	}
	
	function deleteSeat($id = NULL){
		$count_seat = $this->db->get_where('rout_stop_seats',array('id'=>$id))->result_array();
		if(count($count_seat) > 0 && !empty($count_seat) && $count_seat[0]['Is_Booked'] == 0){
			$flag = $this->db->set(array('status'=>'DEACTIVE'))->where(array('id'=>$id))->update('rout_stop_seats');
			if($flag){
				$flag = $this->db->set(array('status'=>'DEACTIVE'))->where(array('SeatID'=>$id))->update('route_stop_seat_fare');
			}
			return $flag;
		}else{
			return TRUE;
		}
	}
	
	function toggleStatus($set = array(), $where = array()){
		return $this->db->set($set)->where($where)->update('route_stop');
	}
	
	function getAllPSGROUP(){
		return $this->db->get_where('combo_master',array('combo_case'=>'PSGROUP','status'=>'ACTIVE'))->result_array();
	}
	
	function getAllRouteStop(){
		return $this->db->select('*')->from('route_stop')->order_by('id','ASC')->get()->result_array();
	}
	
	function AllCity(){
		return $this->db->select('*')->from('city_master')->order_by('city_id','ASC')->get()->result_array();
	}
}