<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Branch_model extends Data {
	public $searchCriteria; 
	var $tbl_employee_masater = "employee_masater";
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	function __construct(){
        parent::__construct();
    }
	
	function getList(){
		return $this->db->select('*')->from($this->tbl_branch_master)->order_by('id','desc')->get()->result_array();
	}
	
	function check_code($branchID = NULL, $code = NULL){
		$where = '1 = 1 ';
		if($branchID != '')	$where .= " AND id NOT IN(".$branchID.") ";
		$where .= " AND BranchCode = '".$code."'";
		return $this->db->get_where($this->tbl_branch_master,$where)->result_array();
	}
	
	function get_by_id($id = NULL,$flag = false){
		if(!$flag)
		return $this->db->get_where($this->tbl_branch_master,array('id'=>$id))->result_array();
		else
		return $this->db->get_where($this->tbl_branch_master,array('id'=>$id))->row();
	}
	
	function addBranch($data = array()){
		return $this->db->insert($this->tbl_branch_master,$data);
	}
	
	function updateBranch($data = array(), $id){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_branch_master);
	}
	
	function updateStatus($set = array(), $id = NULL){
		return $this->db->set($set)->where(array('id'=>$id))->update($this->tbl_branch_master);
	}
}