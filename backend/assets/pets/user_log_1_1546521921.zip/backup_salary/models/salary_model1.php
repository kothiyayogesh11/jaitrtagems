<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class salary_model extends Data {
	var $tbl_employee_masater = "employee_masater";
	var $tbl_emp_salary_detail = "emp_salary_detail";
	var $tbl_file_list = "file_list";
	
    function __construct(){
        parent::__construct();		
        $this->tbl = 'emp_salary_detail';
    }

    function getSalary() {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "s.id as salaryid , e.EmpFullName as empName , s.startDate as Startdate , s.endDate as Enddate ,  s.salary as salary , s.commitmentSalary as commitmentSalary, cm.combo_value as islast , com.combo_value as isFix";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 AND s.delete_flag = 0 and cm.combo_case  = 'STATUSYESNO' and com.combo_case  = 'STATUSYESNO'";

        $orderField = " s.id";
        $orderDir = " DESC";

        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM emp_salary_detail as s left join employee_masater as e on e.id = s.empID left join  combo_master as cm on  cm.combo_key  = s.isLast  left join  combo_master as com on com.combo_key = s.isFix ".$whereClaue." ORDER BY ".$orderField." ".$orderDir." ";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
    function update_employee($emp_id){
		$appointment = array('isLast' => 0);    
		$this->db->where('empID', $emp_id);
		$this->db->update('emp_salary_detail', $appointment);    
  	}
  
	function get_employee_by_code($code = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpCode'=>$code))->result_array();
	}
  
  	function update_is_last($where = array(),$status = 0){
		return $this->db->set(array('isLast'=>$status))->where($where)->update($this->tbl_emp_salary_detail);
	}
	
	function checkRecExists($empID = NULL, $Date){
		$where = "empID = ".$empID." AND MONTH(startDate) = MONTH('".$Date."') AND YEAR(startDate) = YEAR('".$Date."')";
		return $this->db->get_where($this->tbl_emp_salary_detail,$where)->result_array();
	}
	
	function addImportSalary($data = array()){
		return $this->db->insert($this->tbl_emp_salary_detail,$data);
	}
	
	function updateLastRec($set = array(), $where = array()){
		return $this->db->set($set)->where($where)->update($this->tbl_emp_salary_detail);
	}
	
	function addFileList($data){
		return $this->db->insert($this->tbl_file_list,$data);
	}
	
}