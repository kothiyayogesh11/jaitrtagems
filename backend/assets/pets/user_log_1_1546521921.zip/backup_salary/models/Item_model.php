<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Item_model extends Data {
	public $searchCriteria; 
	var $tbl_employee_masater = "employee_masater";
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_itemmaster = "itemmaster";
	function __construct(){
        parent::__construct();
    }
	
	function getList(){
		
		$this->db->select('*');
		$this->db->from($this->tbl_itemmaster);
		$this->db->where(array('delete_flag'=>0));
		$this->db->order_by('id','desc');
		return $this->db->get()->result_array();
	}
	
	function addItem($data = array()){
		return $this->db->insert($this->tbl_itemmaster,$data);
	}
	
	function updateItem($data = array(), $id = NULL){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_itemmaster);
	}
	
	function get_by_id($id = NULL,$flag = false){
		if(!$flag)
		return $this->db->get_where($this->tbl_itemmaster,array('id'=>$id))->result_array();
		else
		return $this->db->get_where($this->tbl_itemmaster,array('id'=>$id))->row();
	}
	
}