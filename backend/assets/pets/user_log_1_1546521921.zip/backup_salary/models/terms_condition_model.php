<?php
class Terms_condition_model extends Data{
	function __construct() {
        parent::__construct();
    }
	
	function add_booking_terms($terms_text = NULL){
		$insArr['terms'] = $terms_text;
		$insArr['insertby'] = $this->session->userdata('sess_intUserId'); 
		$insArr['insertDate'] = date('Y-m-d');
		return $this->db->insert('BookingTerms',$insArr);
	}
	
	function change_booking_terms($terms_text, $id = NULL){
		$insArr['terms'] = $terms_text;
		$insArr['updateBy'] = $this->session->userdata('sess_intUserId'); 
		$insArr['updateDate'] = date('Y-m-d');
		return $this->db->set($insArr)->where(array('id'=>$id))->update('BookingTerms');
	}
	
	function getBookingTerms(){
		return $this->db->get('BookingTerms')->result_array();
	}
}
?>