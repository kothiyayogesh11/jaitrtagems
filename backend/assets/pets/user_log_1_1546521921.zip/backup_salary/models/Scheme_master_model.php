<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Scheme_master_model extends Data {
	public $searchCriteria; 
	var $tbl_employee_masater = "employee_masater";
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_scheme_master = "scheme_master";
	var $tbl_combo_master = "combo_master";
	var $tbl_designation = "designation";
	function __construct(){
        parent::__construct();
    }
	
	function getList(){
		$this->db->select('sm.id as id, sm.beneficiary_type as beneficiary_type, sm.beneficiary_id as beneficiary_id, sm.month as month, sm.SchemeBase as SchemeBase, sm.employee_id as employee_id, sm.inactive_type as inactive_type, sm.inactive_value as inactive_value, sm.delete_flag as delete_flag, bft.combo_value as BFTYPE, scb.combo_value as SCHEME_BASE, inc.combo_value as inc_type, em.EmpFullName as emp_name');
		$this->db->from($this->tbl_scheme_master.' sm');
		$this->db->join($this->tbl_employee_masater.' em','em.id = sm.employee_id','left');
		$this->db->join($this->tbl_combo_master.' inc','sm.inactive_type = inc.combo_key AND inc.combo_case = "inactive_type"','LEFT');
		$this->db->join($this->tbl_combo_master.' bft','sm.beneficiary_type = bft.combo_key AND bft.combo_case = "BFTYPE"','LEFT');
		$this->db->join($this->tbl_combo_master.' scb','sm.SchemeBase = scb.combo_key AND scb.combo_case = "SCHEME_BASE"','LEFT');
		$this->db->where('sm.delete_flag = 0');
		return $this->db->order_by('sm.id','desc')->get()->result_array();
	}
	
	function get_by_id($id = NULL,$flag = false){
		if(!$flag)
		return $this->db->get_where($this->tbl_scheme_master,array('id'=>$id))->result_array();
		else
		return $this->db->get_where($this->tbl_scheme_master,array('id'=>$id))->row();
	}
	
	function getbftype_combo(){
		return $this->db->get_where($this->tbl_combo_master,array('combo_case'=>'BFTYPE'))->result_array();
	}
	
	function addScheme($data = array()){
		return $this->db->insert($this->tbl_scheme_master,$data);
	}
	
	function updateScheme($data = array(), $id){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_scheme_master);
	}
	
}