<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class designation_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'designation';
    }

    function getdesignation()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 AND delete_flag = 0";

        // By city name
        if(isset($searchCriteria['Code']) && $searchCriteria['Code'] != "")
        {
            $whereClaue .= 	" AND (Code  = '".$searchCriteria['Code']."' ";
        }
	   
	   if(isset($searchCriteria['name']) && $searchCriteria['name'] != "")
        {
            $whereClaue .= 	" OR name  = '".$searchCriteria['name']."' )";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND id !=".$searchCriteria['not_id']." ";
        }



        $orderField = " id";
        $orderDir = " DESC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM designation ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
   /* function insertlocationID($intCenterID){
	     $appointment = array('LocationID' => $intCenterID);    
		$this->db->where('id', $intCenterID);
		$this->db->update('worklocationmaster', $appointment); 
    }*/
}