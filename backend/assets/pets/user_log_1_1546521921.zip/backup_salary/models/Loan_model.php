<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Loan_model extends Data {
	public $searchCriteria; 
	var $tbl_employee_masater = "employee_masater";
	var $tbl_emp_salary_detail = 'emp_salary_detail';
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_scheme_master = "scheme_master";
	var $tbl_combo_master = "combo_master";
	var $tbl_designation = "designation";
	var $tbl_loanMaster = "LoanMaster";
	var $tbl_EMIMaster = "EMIMaster";
	function __construct(){
        parent::__construct();
    }
	
	function loanDEL($id){
		$this->db->select('l.id as loanid , em.EmpFullName as empname, l.Amount as amount , l.LoneIntrest as LoneIntrest, l.EMIAmount as EMIamount, l.NoOfEmi as noofemi, l.LoneStartDate as loanstartdate , l.EmiStartDate as emistartdate , l.LoneEndDate as loanenddate,l.LoneApproveBy as LoneApproveBy');
		$this->db->from($this->tbl_loanMaster .' l' );
		$this->db->join($this->tbl_employee_masater.' em','em.id = l.EmployeeId','left');
		$this->db->where('l.delete_flag = 0 AND em.delete_flag = 0 AND l.id = '.$id.'');
		return $this->db->order_by('l.id','desc')->get()->result_array();
	}
	function getList(){
		$this->db->select('l.id as loanid , em.EmpFullName as empname, l.Amount as amount , l.LoneIntrest as LoneIntrest, l.EMIAmount as EMIamount, l.NoOfEmi as noofemi, l.LoneStartDate as loanstartdate , l.EmiStartDate as emistartdate , l.LoneEndDate as loanenddate,l.LoneApproveBy as LoneApproveBy');
		$this->db->from($this->tbl_loanMaster .' l' );
		$this->db->join($this->tbl_employee_masater.' em','em.id = l.EmployeeId','left');
		$this->db->where('l.delete_flag = 0 AND em.delete_flag = 0');
		return $this->db->order_by('l.id','desc')->get()->result_array();
		
		
		/*$this->db->select('sm.id as id, sm.beneficiary_type as beneficiary_type, sm.beneficiary_id as beneficiary_id, sm.month as month, sm.SchemeBase as SchemeBase, sm.employee_id as employee_id, sm.inactive_type as inactive_type, sm.inactive_value as inactive_value, sm.delete_flag as delete_flag, bft.combo_value as BFTYPE, scb.combo_value as SCHEME_BASE, inc.combo_value as inc_type, em.EmpFullName as emp_name');
		$this->db->from($this->tbl_scheme_master.' sm');
		$this->db->join($this->tbl_employee_masater.' em','em.id = sm.employee_id','left');
		$this->db->join($this->tbl_combo_master.' inc','sm.inactive_type = inc.combo_key AND inc.combo_case = "inactive_type"','LEFT');
		$this->db->join($this->tbl_combo_master.' bft','sm.beneficiary_type = bft.combo_key AND bft.combo_case = "BFTYPE"','LEFT');
		$this->db->join($this->tbl_combo_master.' scb','sm.SchemeBase = scb.combo_key AND scb.combo_case = "SCHEME_BASE"','LEFT');
		$this->db->where('sm.delete_flag = 0');
		return $this->db->order_by('sm.id','desc')->get()->result_array();*/
	}
	function loan_details($loanid = NULL){
		
		$this->db->select('l.id as loanid , em.EmpFullName as empname, l.Amount as amount , l.LoneIntrest as LoneIntrest, l.EMIAmount as EMIamount, l.NoOfEmi as noofemi, l.LoneStartDate as loanstartdate , l.EmiStartDate as emistartdate , l.LoneEndDate as loanenddate,l.LoneApproveBy as LoneApproveBy');
		$this->db->from($this->tbl_loanMaster .' l' );
		$this->db->join($this->tbl_employee_masater.' em','em.id = l.EmployeeId','left');
		$this->db->where('l.delete_flag = 0 AND em.delete_flag = 0 AND l.id = '.$loanid.'');
		$rs['loanDET'] = $this->db->order_by('l.id','desc')->get()->result_array();
		
		
		if(!empty($rs['loanDET'])){
			$this->db->select('l.id as loanid , em.EmpFullName as empname, l.Amount as amount , l.LoneIntrest as LoneIntrest, l.EMIAmount as EMIamount, l.NoOfEmi as noofemi, l.LoneStartDate as loanstartdate , l.EmiStartDate as emistartdate , l.LoneEndDate as loanenddate,l.LoneApproveBy as LoneApproveBy,m.id as emiid,m.loan_id as loan_id, m.EMIAmount as EMA,m.EMIDate as EMIDate, m.Status as EMIStatus');
			$this->db->from($this->tbl_loanMaster .' l' );
			$this->db->join($this->tbl_EMIMaster .' m','m.loan_id = l.id');
			$this->db->join($this->tbl_employee_masater.' em','em.id = l.EmployeeId','left');
			$this->db->join($this->tbl_emp_salary_detail.' s','s.id = m.EmiSalaryID');
			$this->db->where('l.delete_flag = 0 AND em.delete_flag = 0 AND m.delete_flag = 0 AND l.id = '.$loanid.'');
			$rs['loanDetails'] = $this->db->order_by('m.id','desc')->get()->result_array();
			
			//echo $this->db->last_query();exit;
		}
		
		
		return $rs; 
	}
	
	
	function getEMIList($loanid){
		$this->db->select('e.*,s.*');
		$this->db->from($this->tbl_EMIMaster .' e' );
		$this->db->join($this->tbl_emp_salary_detail.' s','e.EmiSalaryID	= s.id','left');
		$this->db->where('e.delete_flag = 0 AND s.delete_flag = 0');
		return $this->db->order_by('e.id','desc')->get()->result_array();
	}
	
	function get_by_id($id = NULL,$flag = false){
		if(!$flag)
		return $this->db->get_where($this->tbl_loanMaster,array('id'=>$id))->result_array();
		else
		return $this->db->get_where($this->tbl_loanMaster,array('id'=>$id))->row();
	}
	
	function getbftype_combo(){
		return $this->db->get_where($this->tbl_combo_master,array('combo_case'=>'BFTYPE'))->result_array();
	}
	
	function addScheme($data = array()){
		return $this->db->insert($this->tbl_scheme_master,$data);
	}
	
	function addLone($data = array()){
		 $this->db->insert($this->tbl_loanMaster,$data);
		 return $this->db->insert_id();	
	}
	function updateLoan($data = array(), $id){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_loanMaster);
	}
	function addEMI($dataEmi = array()){
		return  $this->db->insert($this->tbl_EMIMaster,$dataEmi);
	}
	function updateemi($emiid = NULL){
		$where = 'id  = '.$emiid ;
		$set = array('Status'=>1);
		return $query = $this->db->set($set)->where($where)->update($this->tbl_EMIMaster);
	}
	function updateScheme($data = array(), $id){
		return $this->db->set($data)->where(array('id'=>$id))->update($this->tbl_scheme_master);
	}
	function getsalary($empid){
		return $this->db->get_where($this->tbl_emp_salary_detail,array('empID'=>$empid,'delete_flag'=>0,'isLast'=>1))->result_array();	
	}
}