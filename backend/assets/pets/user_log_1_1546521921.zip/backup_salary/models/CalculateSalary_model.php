<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class CalculateSalary_model extends Data {

    public $searchCriteria;
    public $tbl;

    function __construct(){
        parent::__construct();
        $this->tbl = 'salary_employee_monthly_head';
    }

    // Get Employee salary by month and year
    public function getEmployeeSalary($calc_date)
    {
        $calc_dates = date("Y-m-01",strtotime($calc_date));
        $calc_datee = date("Y-m-t",strtotime($calc_date));
        $this->db->select('esd.*,em.IsPPStr AS IsPP,em.IsCalByEarn AS IsEarn,em.EmpCode AS emp_code,em.BranchID AS emp_branch_id,em.CompanyID AS emp_company_id,em.EsiNumber,em.PFNumber');
        $this->db->from('emp_salary_detail esd');
        $this->db->join('employee_masater em','esd.empID = em.id');
        $this->db->where('esd.delete_flag=0 AND esd.isLast=1 AND esd.startDate IS NOT NULL AND esd.startDate <= "'.$calc_datee.'"');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        return $rsData;
    }
    
    // Get Employee DOJ 
    public function getEmployeedoj($calc_date)
    {
        $calc_dates = date("Y-m-01",strtotime($calc_date));
        $calc_datee = date("Y-m-t",strtotime($calc_date));
        $this->db->select('em.id,em.DOJ,em.DOL,em.EmpCode');
        $this->db->from('employee_masater em');
        $this->db->where('em.delete_flag=0 AND em.DOJ<= "'.$calc_datee.'" AND (em.DOL ="0000-00-00" OR em.DOL<="'.$calc_datee.'")');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;
        
        $empDOJArr = array();
        if(count($rsData) > 0)
        {
            foreach ($rsData AS $data)
            {
                $empDOJLArr['DOJ'][$data['id']] = $data['DOJ'];
                $empDOJLArr['DOL'][$data['id']] = $data['DOL'];
            }
        }

        return $empDOJLArr;
        //return $rsData;
    }

    // Get Employee leave by month and year
    public function getEmployeeLeave($calc_date)
    {
        //echo $calc_date;die;
        $calc_dates = date("Y-m-01",strtotime($calc_date));
        $calc_datee = date("Y-m-t",strtotime($calc_date));
        $this->db->select('el.id,el.employeeId,el.no_of_leave');
        $this->db->from('emp_leave el');
        //$this->db->where('el.delete_flag=0 AND el.fromdate IS NOT NULL AND DATE_FORMAT(el.fromdate,"%Y-%m") = "'.$calc_date.'"');
        $this->db->where('el.delete_flag=0 AND el.fromdate IS NOT NULL AND el.fromdate BETWEEN "'.$calc_dates.'" AND "'.$calc_datee.'"');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        $empLeaveArr = array();
        if(count($rsData) > 0)
        {
            foreach ($rsData AS $data)
            {
                $empLeaveArr[$data['employeeId']] = $data['no_of_leave'];
            }
        }

        return $empLeaveArr;
    }

    // Get Employee leave by month and year
    public function getEmployeeIncentive($calc_date)
    {
        $calc_dates = date("Y-m-01",strtotime($calc_date));
        $calc_datee = date("Y-m-t",strtotime($calc_date));
        $this->db->select('i.empID,SUM(i.benefit_amt) AS total_incentive_amt');
        $this->db->from('incentive i');
        $this->db->where('i.delete_flag=0 AND i.date IS NOT NULL AND i.date BETWEEN "'.$calc_dates.'" AND "'.$calc_datee.'"');
        $this->db->group_by('i.empID');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        $empIncentiveArr = array();
        if(count($rsData) > 0)
        {
            foreach ($rsData AS $data)
            {
                $empIncentiveArr[$data['empID']] = $data['total_incentive_amt'];
            }
        }

        return $empIncentiveArr;
    }

    // get Employee salary head settings
    public function getEmployeeSalarySetting()
    {
        $this->db->select('es.*,sm.code AS actual_sal_head_code,sm1.code AS actual_sal_head_code_store');
        $this->db->from('employeesettings es');
        $this->db->join('salary_head_master sm','es.salary_head_code = sm.id');
        $this->db->join('salary_head_master sm1','es.salary_head_code_store = sm1.id');
        $this->db->where('es.delete_flag=0');

        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        return $rsData; exit;
    }

    // Get Salary Head Master
    public function getSalaryHeadMaster()
    {
        $this->db->select('shm.id,shm.code, shm.type,shm.is_pre_defined');
        $this->db->from('salary_head_master shm');
        $this->db->where('shm.delete_flag=0');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        return $rsData;
    }

    public function getEmployeeMonthlyHeadSalary($calcDate)
    {
        $this->db->select('semh.empID,shm.code,SUM(semh.amount) AS amount');
        $this->db->from('salary_employee_monthly_head semh');
        $this->db->join('salary_head_master shm','semh.headID = shm.id');
        $this->db->where('semh.delete_flag=0 AND (semh.calc_id IS NULL OR semh.calc_id = 0) AND semh.year = YEAR("'.$calcDate.'") AND semh.month = MONTH("'.$calcDate.'")');
        $this->db->group_by('semh.empID,shm.code');
        $result = $this->db->get();
        $rsData = $result->result_array();

        //echo $this->db->last_query(); exit;

        return $rsData;
    }

    public function getProfessionalTaxSettings($amount)
    {
        $this->db->select('shm.code,pts.value');
        $this->db->from('professional_tax_settings pts');
        $this->db->join('salary_head_master shm','pts.salary_head_code = shm.id');
        $this->db->where('pts.delete_flag=0');
        $this->db->where("".round($amount)." >= pts.lowerlimit");
        $this->db->where("".round($amount)." <= pts.higherlimit");
        $result = $this->db->get();

        //echo $this->db->last_query(); exit;

        $rsData = $result->result_array();

        return $rsData;
    }

    function insertBatch($dataArr){
        /*$count = $this->db->get_where('customer_master','email = "'.$cusData['email'].'" OR  mobile_no = "'.$cusData['mobile_no'].'"')->result_array();
        if(count($count) == 0){
            return $this->db->insert('customer_master',$cusData);
        }else{
            return FALSE;
        }*/

        return $this->db->insert_batch($this->tbl,$dataArr);
    }

    function insertCalculation($dataArr){
        /*$count = $this->db->get_where('customer_master','email = "'.$cusData['email'].'" OR  mobile_no = "'.$cusData['mobile_no'].'"')->result_array();
        if(count($count) == 0){
            return $this->db->insert('customer_master',$cusData);
        }else{
            return FALSE;
        }*/

        $this->db->insert('salary_calculation',$dataArr);
        return $this->db->insert_id();
    }

    function deactiveOldRecords($calcDate)
    {
        $param = array();
        $param['delete_flag'] = 1;

        $this->db->where('month', date("m",strtotime($calcDate)));
        $this->db->where('year', date("Y",strtotime($calcDate)));
        //$this->db->where('calc_id IS NOT NULL');
        $this->db->where('(calc_id IS NOT NULL AND calc_id != 0)');

        $this->db->update($this->tbl, $param);
    }
}