<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class flight_schedule_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'flight_schedule';
        $this->tbl_alias = 'fs';
    }

    function getList()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By route_id
        if(isset($searchCriteria['route_id']) && $searchCriteria['route_id'] != "")
        {
            $whereClaue .= 	" AND ".$this->tbl_alias.".route_id='".$searchCriteria['route_id']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND id !=".$searchCriteria['not_id']." ";
        }

        $orderField = " ".$this->tbl_alias.".id";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM ".$this->tbl." AS ".$this->tbl_alias." ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
}
