<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class route_stop_seat_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'rout_stop_seats';
    }

    function getStopRouteseatList()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField =     $searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By airport name
        if(isset($searchCriteria['stop_route_code']) && $searchCriteria['stop_route_code'] != ""){
            $whereClaue .=     " AND rst.stop_route_code='".$searchCriteria['stop_route_code']."' ";
        }
        
        // By airport name
        if(isset($searchCriteria['SeatNM']) && $searchCriteria['SeatNM'] != ""){
            $whereClaue .=     " AND rs.SeatNM='".$searchCriteria['SeatNM']."' ";
        }
        
        // By airport name
        if(isset($searchCriteria['RoutStopid']) && $searchCriteria['RoutStopid'] != ""){
            $whereClaue .=     " AND rs.RoutStopid='".$searchCriteria['RoutStopid']."' ";
        }
		
		if($this->input->post('status') != ''){
			$whereClaue .= 	" AND rs.status = '".$this->input->post('status')."' ";
		}else{
			$whereClaue .= 	" AND rs.status = 'ACTIVE' ";
		}
		if($this->input->post('rout_code') != ''){
			$whereClaue .= 	" AND rst.stop_route_code = '".$this->input->post('rout_code')."' ";
		}
		if($this->input->post('from_city') != ''){
			$whereClaue .= 	" AND rst.from_city_id = '".$this->input->post('from_city')."' ";
		}
		if($this->input->post('to_city') != ''){
			$whereClaue .= 	" AND rst.to_city_id = '".$this->input->post('to_city')."' ";
		}
		if($this->input->post('departure_date') != ''){
			$whereClaue .= 	" AND DATE(rst.departure) = DATE('".$this->input->post('departure_date')."') ";
		}else{
			$whereClaue .= 	" AND DATE(rst.departure) = DATE('".date('Y-m-d')."') ";
		}
		
		if($this->input->post('book_status') != ''){
			$whereClaue .= 	" AND rs.Is_Booked = '".$this->input->post('book_status')."' ";
		}
		
        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
            $whereClaue .=     " AND rs.id !=".$searchCriteria['not_id']." ";
        }

        $orderField = " rs.id";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM rout_stop_seats as rs
                            JOIN route_stop AS rst ON rs.RoutStopid = rst.id
                            LEFT JOIN route AS rut ON rst.main_route_id = rut.id 
                            LEFT JOIN city_master AS cm1 ON rst.from_city_id = cm1.city_id 
                            LEFT JOIN city_master AS cm2 ON rst.to_city_id = cm2.city_id 
                            LEFT JOIN air_master AS am ON rst.air_id = am.id
                            LEFT JOIN airport_master AS apm ON rst.airport_id = apm.id
                            ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
	
	function getAllRouteStop(){
		return $this->db->select('*')->from('route_stop')->order_by('id','ASC')->get()->result_array();
	}
	
	function AllCity(){
		return $this->db->select('*')->from('city_master')->order_by('city_id','ASC')->get()->result_array();
	}
}