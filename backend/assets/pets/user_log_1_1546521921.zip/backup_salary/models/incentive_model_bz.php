<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class incentive_model extends Data {
    var $tbl_employee_masater = "employee_masater";
    var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
    var $tbl_file_list = "file_list";
    var $tbl_companymaster = "companymaster";
    var $tbl_branch_master = "branch_master";
    var $tbl_combo_master = "combo_master";
    var $tbl_incentive = "incentive";
    function __construct(){
        parent::__construct();        
        $this->tbl = $this->tbl_incentive;
    }

    function getincentive(){
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "ms.id as salesid, ms.BranchID as BranchID,ms.empID as empID, em.EmpFullName as empName, ms.Date as Date, ms.scheme as scheme, ms.qty as qty,ms.benefit_amt as benefit_amt, ms.FileID as FileID, ms.EntryType as EntryType, cm.combo_value as EntryType, c.BranchName as comName";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "") $selectField = $searchCriteria['selectField'];
        
        $gDate = $this->input->get('date');
        $gBranch = $this->input->get('branch');
        
        $whereClaue = " 1=1 AND ms.delete_flag = 0 and cm.combo_case  = 'ENTRYTYPE'";
        
           if($gDate != '') $whereClaue .=  " AND MONTH(ms.Date) = MONTH('".$gDate."') AND YEAR(ms.Date) = YEAR('".$gDate."') ";
        if($gBranch != '')  $whereClaue .=  " AND ms.BranchID =  ".$gBranch." ";
        $orderField = " ms.id";
        $orderDir = " DESC";
        
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "") $orderField = $searchCriteria['orderField'];
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "") $orderDir = $searchCriteria['orderDir'];

        $this->db->select($selectField);
        $this->db->from($this->tbl_incentive.' ms');
        $this->db->join($this->tbl_employee_masater.' em','em.id = ms.empID','left');
        $this->db->join($this->tbl_branch_master.' c','c.id = ms.BranchID','left');
        $this->db->join($this->tbl_combo_master.' cm','cm.combo_key = ms.EntryType','left');
        $this->db->where($whereClaue);
        $this->db->order_by($orderField,$orderDir);
        return $this->db->get()->result_array();
    }
    
    function getBranchIdByName($name = NULL){
        return $this->db->get_where($this->tbl_branch_master,array('BranchAPXName'=>$name))->result_array();        
    }
    function getAllBranchbyAPXNaame(){
        //return $this->db->get_where($this->tbl_branch_master,array('BranchAPXName'=>$name))->result_array();
        return $this->db->get_where($this->tbl_branch_master," delete_flag = 0 ")->result_array();        
    }
    
    function getEmployeeIdByName($name = NULL){
        return $this->db->get_where($this->tbl_employee_masater," LOWER(EmpFullName) = '".$name."' AND delete_flag = 0 ")->result_array();
    }
    function getAllEmpbyNaame(){
        return $this->db->get_where($this->tbl_employee_masater," delete_flag = 0 ")->result_array();
    }
    
    function getMonthModule($date, $mod){
        $where = "ModuleCode = '".$mod."' AND MONTH(Date) = MONTH('".$date."') AND YEAR(Date) = YEAR('".$date."') AND delete_flag = 0  ";
        return $this->db->get_where($this->tbl_file_list,$where)->result_array();
    }
    
    function removeOldData($fileID = NULL, $newID = NULL){
        $this->db->set(array('delete_flag'=>1))->where('id = '.$fileID.' AND id NOT IN ('.$newID.')')->update($this->tbl_file_list);
        $this->db->set(array('delete_flag'=>1))->where('FileID = '.$fileID.' AND FileID NOT IN ('.$newID.')')->update($this->tbl_incentive);
    }
    
    function getBranchById($id = NULL){
        return $this->db->get_where($this->tbl_branch_master,array('id'=>$id))->result_array();
    }
    
    function addMonthlyIncentiveData($data = array()){
        return $this->db->insert($this->tbl_incentive,$data);
    }
    
	function getFileDataByFileID($id = NULL){
		return $this->db->get_where($this->tbl_file_list,array('id'=>$id))->result_array();
	}
	
    function addFileList($data){
        return $this->db->insert($this->tbl_file_list,$data);
    }
	
	function batch_insert_incentive($data = array()){
		return $this->db->insert_batch($this->tbl, $data);
	}
} 