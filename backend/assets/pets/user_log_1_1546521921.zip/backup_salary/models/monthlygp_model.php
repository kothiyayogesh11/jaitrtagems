<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class monthlygp_model extends Data {
	var $tbl_employee_masater = "employee_masater";
	var $tbl_branchwisemonthlygp = "branchwisemonthlygp";
	var $tbl_branchwisemonthlysales = "branchwisemonthlysales";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_combo_master = "combo_master";
	
    function __construct(){
        parent::__construct();		
        $this->tbl = 'branchwisemonthlygp';
    }

	function getgp(){
		$searchCriteria = array();
		$searchCriteria = $this->searchCriteria;
		
		$selectField = "ms.id as salesid, ms.BranchID as BranchID,ms.Date as SalesDate, ms.GpAmount as GpAmount , ms.NetProfit as NetProfit, ms.FileID as FileID, cm.combo_value as EntryType, c.BranchName as comName";		
		if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "") $selectField = $searchCriteria['selectField'];
		
		$whereClaue = " 1=1 AND ms.delete_flag = 0 and cm.combo_case  = 'ENTRYTYPE'";
		if(isset($searchCriteria['Month']) && $searchCriteria['Month'] != "")$whereClaue .= " AND (MONTH(ms.Date)) = '".$searchCriteria['Month']."' ";
		if(isset($searchCriteria['BranchID']) && $searchCriteria['BranchID'] != "")	$whereClaue .= 	" AND ms.BranchID = '".$searchCriteria['BranchID']."' ";
		if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")	$whereClaue .= 	" AND ms.id !=".$searchCriteria['not_id']." ";
		
		$orderField = " ms.id";
		$orderDir = " DESC";
		if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "") $orderField = $searchCriteria['orderField'];
		if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "") $orderDir = $searchCriteria['orderDir'];
				
		$this->db->select($selectField);
		$this->db->from($this->tbl_branchwisemonthlygp.' ms');
		$this->db->join($this->tbl_branch_master.' c','c.id = ms.BranchID','left');
		$this->db->join($this->tbl_combo_master.' cm','cm.combo_key = ms.EntryType','left');
		$this->db->where($whereClaue);
		$this->db->order_by($orderField,$orderDir);
		return $this->db->get()->result_array();
	}
	
    function update_employee($emp_id){
		$appointment = array('isLast' => 0);    
		$this->db->where('empID', $emp_id);
		$this->db->update('emp_salary_detail', $appointment);    
  	}
  
	function get_employee_by_code($code = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpCode'=>$code))->result_array();
	}
  
  	function update_is_last($where = array(),$status = 0){
		return $this->db->set(array('isLast'=>$status))->where($where)->update($this->tbl_emp_salary_detail);
	}
	
	function addImportSalary($data = array()){
		return $this->db->insert($this->tbl_emp_salary_detail,$data);
	}
   
	function addFileList($data){
		return $this->db->insert($this->tbl_file_list,$data);
	}
	
	function addMonthlyGpData($data){
		return $this->db->insert($this->tbl_branchwisemonthlygp,$data);
	}
	
	function getBranchById($id = NULL){
		return $this->db->get_where($this->tbl_branch_master,array('id'=>$id))->result_array();
	}
	
	function checkRecExists($BranchID, $Date){
		$where = "BranchID = ".$BranchID." AND MONTH(Date) = MONTH('".$Date."') AND YEAR(Date) = YEAR('".$Date."')";
		return $this->db->get_where($this->tbl_branchwisemonthlygp,$where)->result_array();
	}
	
	function getBranchIdByName($name = NULL){
		return $this->db->get_where($this->tbl_branch_master,array('BranchName'=>$name))->result_array();		
	}
	
	function getMonthModule($date, $mod){
		$where = "ModuleCode = '".$mod."' AND MONTH(Date) = MONTH('".$date."') AND YEAR(Date) = YEAR('".$date."') AND delete_flag = 0 ";
		return $this->db->get_where($this->tbl_file_list,$where)->result_array();
	}
	
	function removeOldData($fileID = NULL, $newID = NULL){
		$this->db->set(array('delete_flag'=>1))->where('id = '.$fileID.' AND id NOT IN ('.$newID.')')->update($this->tbl_file_list);
		$this->db->set(array('delete_flag'=>1))->where('FileID = '.$fileID.' AND FileID NOT IN ('.$newID.')')->update($this->tbl_branchwisemonthlygp);
	}
}