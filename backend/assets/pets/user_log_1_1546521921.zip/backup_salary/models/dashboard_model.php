<?php 
class dashboard_model extends Data{
	function __construct(){
        parent::__construct();
    }
	
	function getBookingData($id = NULL){
		$select = "bm.id as bid, bm.BookingDate as b_date, bm.Charges as mb_charge, pd.PaymentType as pd_payment_type, pd.PaymentBy as pd_payment_by, pd.order_status as pd_order_status, CONCAT(cm.first_name,' ',cm.middle_name,' ',cm.last_name) as cname, brd.departureDate as d_date, brd.fare as b_fare";
		$where = " bm.status = 'ACTIVE' AND brd.RoutStopID = ".$id;
		$this->db->select($select);
		$this->db->from('booking_route_detail brd');
		$this->db->join('booking_master bm','brd.BookingID = bm.id','left');
		$this->db->join('paymentdetail pd','pd.booking_id = bm.id','left');
		$this->db->join('customer_master cm','cm.id = bm.CustomerID','left');
		$this->db->where($where);
		return $this->db->get()->result_array();
	}
	
	function getRoutStopData(){
		
		$select = "rs.*, sum(rss.Is_Booked) as booked_seat, count(rss.id) as total_seat";
		$where = " rs.status = 'ACTIVE'";
		$this->db->select($select);
		$this->db->from('route_stop rs');
		$this->db->join('rout_stop_seats rss','rss.RoutStopid = rs.id','left');
		$this->db->where($where);
		$this->db->group_by('rss.RoutStopid');
		return $this->db->get()->result_array();
		//return $this->db->get_where('route_stop',array('status'=>'ACTIVE'))->result_array();
	}
	
	function getSeatData($id = NULL){
		
		$select = "rss.SeatNM as seat_name, rss.Is_Booked as seat_booked, rss.status as seat_status, pd.PaymentType as pay_mode, pd.PaymentBy as bayment_by, pd.order_status as pay_status, pd.mer_amount as mer_pay, CONCAT(bpd.title,' ',bpd.first_name,' ',bpd.last_name) as cname, bpd.email_address as cemail, bpd.contact_phone as ccontact, bpd.ptype as ctype, rssf.fare as seat_fare";
		$where = " rss.RoutStopid = ".$id;
		$this->db->select($select);
		$this->db->from('rout_stop_seats rss');
		$this->db->join('booking_person_rout_seat bprs','bprs.SeatID = rss.id','left');
		$this->db->join('booking_passenger_detail bpd','bpd.id = bprs.PersonID','left');
		$this->db->join('paymentdetail pd','pd.booking_id = bprs.BookingID','left');
		$this->db->join('route_stop_seat_fare rssf','rssf.id = bprs.SeatfareID','left');
		$this->db->where($where);
		return $this->db->get()->result_array();
		
		//return $this->db->get_where('rout_stop_seats', array('RoutStopid'=>$id))->result_array();
	}
}
?>