<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Salaryhead_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'salary_head_master';
    }

    function getSalaryhead()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "c.code as code, c.name as name, c.id as id,cm.combo_value as type , c.max_allowed_amount as amount, c.min_allowed_amount as min_amount,c.is_pre_defined,c.is_calc";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

       $whereClaue = "WHERE 1=1 AND c.delete_flag = 0 and cm.combo_case  = 'SALARYHEAD'";

        // By city name
       /* if(isset($searchCriteria['city_name']) && $searchCriteria['city_name'] != "")
        {
            $whereClaue .= 	" AND ctm.city_name='".$searchCriteria['city_name']."' ";
        }*/

        // Not In
        if(isset($searchCriteria['id']) && $searchCriteria['id'] != "")
        {
            $whereClaue .= 	" AND id =".$searchCriteria['id']." ";
        }
	    if(isset($searchCriteria['code']) && $searchCriteria['code'] != "")
        {
            $whereClaue .= 	" AND (c.code  = '".trim($searchCriteria['code'])."') ";
        }
	   
        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND c.id !=".$searchCriteria['not_id']." ";
        }
	   
        $orderField = " c.id";
        $orderDir = " DESC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM salary_head_master as c left join combo_master as cm on cm.combo_key = c.type  ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";
        
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
   /* function insertlocationID($intCenterID){
	     $appointment = array('LocationID' => $intCenterID);    
		$this->db->where('id', $intCenterID);
		$this->db->update('worklocationmaster', $appointment); 
    }*/
    /*function deleteAbout($id){
		$where = 'id = '.$id.'';
		$set = array('delete_flag'=>1);
		return $query = $this->db->set($set)->where($where)->update('worklocationmaster');
	}*/
}