<?php
/**
 * Created by PhpStorm.
 * User: rakesh
 * Date: 9/21/2017
 * Time: 10:26 PM
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Emp_relation_model extends Data {

    function __construct()
    {
        parent::__construct();
        $this->tbl = 'relationmaster';
    }

    function getRelation()
    {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "")
        {
            $selectField = 	$searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 AND delete_flag = 0";

        // By city name
       /* if(isset($searchCriteria['city_name']) && $searchCriteria['city_name'] != "")
        {
            $whereClaue .= 	" AND ctm.city_name='".$searchCriteria['city_name']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND city_id !=".$searchCriteria['not_id']." ";
        }*/
	    if(isset($searchCriteria['code']) && $searchCriteria['code'] != "")
        {
            $whereClaue .= 	" AND (code = '".$searchCriteria['code']."') ";
        }
	   

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != "")
        {
            $whereClaue .= 	" AND id !=".$searchCriteria['not_id']." ";
        }
        $orderField = " id";
        $orderDir = " DESC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "")
        {
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "")
        {
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM relationmaster ".$whereClaue." ORDER BY ".$orderField." ".$orderDir."";

        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
    }
   /* function insertlocationID($intCenterID){
	     $appointment = array('LocationID' => $intCenterID);    
		$this->db->where('id', $intCenterID);
		$this->db->update('worklocationmaster', $appointment); 
    }*/
}