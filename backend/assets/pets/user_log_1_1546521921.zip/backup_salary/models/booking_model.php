<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class booking_model extends Data {
	public $searchCriteria; 
	function __construct(){
        parent::__construct();
        $this->tbl = 'route_stop';
    }
	function getAirCategory(){
		return $this->db->select('*')->from('aircategory')->where(array('delete_flag'=>0))->order_by('id','ASC')->get()->result_array();
	}
	
	function getTripList(){
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;
		/*echo date('Y-m-d',strtotime($searchCriteria['date_start']));
		pre( $searchCriteria);//exit;*/
        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField = 	$searchCriteria['selectField'];
        }
        $whereClaue = "WHERE 1=1 ";	
        if(isset($searchCriteria['date_start']) && $searchCriteria['date_start'] != ""){
		    $ststdt = date("Y-m-d 00:00:00", strtotime(date('Y-m-d',strtotime($searchCriteria['date_start']))));
		    $edstdt = date("Y-m-d 23:59:59", strtotime(date('Y-m-d',strtotime($searchCriteria['date_start']))));
            $whereClaue .= 	" AND rs.from_city_id='".$searchCriteria['from_city']."' AND rs.to_city_id='".$searchCriteria['to_city']."' AND rs.air_id='".$searchCriteria['air_id']."' AND rs.departure BETWEEN '".$ststdt."' AND '".$edstdt."' ";
        }
        
        if(isset($searchCriteria['ids']) && $searchCriteria['ids'] != ""){
            $whereClaue .=     " AND rs.id IN (".$searchCriteria['ids'].") ";
        }
        if(isset($searchCriteria['id']) && $searchCriteria['id'] != ""){
            if(isset($searchCriteria['id2']) && $searchCriteria['id2'] != ""){
                $whereClaue .=     " AND (rs.id=".$searchCriteria['id']." OR rs.id=".$searchCriteria['id2'].")";
            }else{
                $whereClaue .=     " AND rs.id=".$searchCriteria['id']." ";
            }
            //$whereClaue = "WHERE 1=1 ";
            /*$ststdt = date("Y-m-d 00:00:00", strtotime($searchCriteria['date_start']));
            $edstdt = date("Y-m-d 23:59:59", strtotime($searchCriteria['date_start']));*/
        }
		$whereClaue .=  " AND rs.status = 'ACTIVE' ";
        $orderField = " rs.id";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }

        $sqlQuery = "SELECT ".$selectField." FROM route_stop AS rs 
                            LEFT JOIN route AS rut
							ON rs.main_route_id = rut.id 
							LEFT JOIN city_master AS cm1
							ON rs.from_city_id = cm1.city_id 
							LEFT JOIN city_master AS cm2
							ON rs.to_city_id = cm2.city_id 
							LEFT JOIN air_master AS am
							ON rs.air_id = am.id
							LEFT JOIN airport_master AS apm
							ON rs.airport_id = apm.id
							LEFT JOIN rout_stop_seats AS rss ON rs.id = rss.RoutStopid
							".$whereClaue." GROUP BY rs.id ORDER BY ".$orderField." ".$orderDir."";
       //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        if (empty($rsData)){
            $whereClaue1 = "WHERE 1=1 ";
			$ststdt = date("Y-m-d 00:00:00", strtotime(date('Y-m-d',strtotime($searchCriteria['date_start']))));
			$edstdt = date("Y-m-d 23:59:59", strtotime(date('Y-m-d',strtotime($searchCriteria['date_start']))));
			
            $whereClaue1 .= " AND rut.from_city_id='".$searchCriteria['from_city']."' AND rut.to_city_id='".$searchCriteria['to_city']."' AND rs.air_id='".$searchCriteria['air_id']."' AND rs.departure BETWEEN '".$ststdt."' AND '".$edstdt."'  AND rs.status = 'ACTIVE' ";
            $sqlQuery = "SELECT ".$selectField." FROM route_stop AS rs 
                            LEFT JOIN route AS rut
							ON rs.main_route_id = rut.id 
							LEFT JOIN city_master AS cm1
							ON rs.from_city_id = cm1.city_id 
							LEFT JOIN city_master AS cm2
							ON rs.to_city_id = cm2.city_id 
							LEFT JOIN air_master AS am
							ON rs.air_id = am.id
							LEFT JOIN airport_master AS apm
							ON rs.airport_id = apm.id
							LEFT JOIN rout_stop_seats AS rss ON rs.id = rss.RoutStopid
							".$whereClaue1."  GROUP BY rs.id ORDER BY ".$orderField." ".$orderDir."";
            $result     = $this->db->query($sqlQuery);
            $rsData     = $result->result_array();
            $rsData     = array_unique($rsData);
        }
        return $rsData;
    }
	
	function getReturnTripList(){
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField = 	$searchCriteria['selectField'];
        }
        $whereClaue = "WHERE 1=1 ";
		$ststdt = date("Y-m-d 00:00:00", strtotime($searchCriteria['date_start']));
		$edstdt = date("Y-m-d 23:59:59", strtotime($searchCriteria['date_start']));
        $whereClaue .= 	" AND rs.from_city_id='".$searchCriteria['to_city']."' AND rs.to_city_id='".$searchCriteria['from_city']."' AND rs.air_id='".$searchCriteria['air_id']."' AND rs.departure BETWEEN '".$ststdt."' AND '".$edstdt."' ";
        $orderField = " rs.id";
        $orderDir = " ASC";
        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }
        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }
        $sqlQuery = "SELECT ".$selectField." FROM route_stop AS rs 
                            LEFT JOIN route AS rut
							ON rs.main_route_id = rut.id 
							LEFT JOIN city_master AS cm1
							ON rs.from_city_id = cm1.city_id 
							LEFT JOIN city_master AS cm2
							ON rs.to_city_id = cm2.city_id 
							LEFT JOIN air_master AS am
							ON rs.air_id = am.id
							LEFT JOIN airport_master AS apm
							ON rs.airport_id = apm.id
							LEFT JOIN rout_stop_seats AS rss ON rs.id = rss.RoutStopid
							".$whereClaue."  GROUP BY rs.id ORDER BY ".$orderField." ".$orderDir."";
        //echo $sqlQuery; exit;
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        if (empty($rsData)){
            $whereClaue1 = "WHERE 1=1 ";
			$ststdt = date("Y-m-d 00:00:00", strtotime($searchCriteria['date_start']));
			$edstdt = date("Y-m-d 23:59:59", strtotime($searchCriteria['date_start']));
            $whereClaue1 .= " AND rut.from_city_id='".$searchCriteria['to_city']."' AND rut.to_city_id='".$searchCriteria['from_city']."' AND rs.air_id='".$searchCriteria['air_id']."' AND rs.departure BETWEEN '".$ststdt."' AND '".$edstdt."' ";
            $sqlQuery = "SELECT ".$selectField." FROM route_stop AS rs 
                            LEFT JOIN route AS rut
							ON rs.main_route_id = rut.id 
							LEFT JOIN city_master AS cm1
							ON rs.from_city_id = cm1.city_id 
							LEFT JOIN city_master AS cm2
							ON rs.to_city_id = cm2.city_id 
							LEFT JOIN air_master AS am
							ON rs.air_id = am.id
							LEFT JOIN airport_master AS apm
							ON rs.airport_id = apm.id
							LEFT JOIN rout_stop_seats AS rss ON rs.id = rss.RoutStopid
							".$whereClaue1."  GROUP BY rs.id ORDER BY ".$orderField." ".$orderDir."";
            $result     = $this->db->query($sqlQuery);
            $rsData     = $result->result_array();
            $rsData     = array_unique($rsData);
        }
        return $rsData;
    }
	
	function getShadualTabs(){
		$cat_where = " id IN(select category_id from home_image where status = 'ACTIVE') AND delete_flag = 0 ";
		$data['tabCat'] = $this->db->select('*')->from('home_image_category')->where($cat_where)->order_by('sort_order','ASC')->get()->result_array();
		$data['tabImage'] = array();
		foreach($data['tabCat'] as $cat){
			$imgData = $this->db->get_where('home_image',array('status'=>'ACTIVE','category_id'=>$cat['id']))->result_array();
			if(!empty($imgData)) $data['tabImage'][$cat['id']] = $imgData;
		}
		return $data;
	}
	function getMainImage(){
		return $this->db->get_where('home_image',array('type'=>2))->result_array();
	}
	
	function getBookingDetails(){
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;
        $selectField = "*";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != ""){
            $selectField =     $searchCriteria['selectField'];
        }

        $whereClaue = "WHERE 1=1 ";

        // By airport name
        if(isset($searchCriteria['stop_route_code']) && $searchCriteria['stop_route_code'] != ""){
            $whereClaue .=     " AND bm.stop_route_code='".$searchCriteria['stop_route_code']."' ";
        }

        // Not In
        if(isset($searchCriteria['not_id']) && $searchCriteria['not_id'] != ""){
            $whereClaue .=     " AND bm.id !=".$searchCriteria['not_id']." ";
        }
		
		if($this->input->post('departure_date') != ''){
			$whereClaue .= 	" AND DATE(rs.BookingDate) = DATE('".$this->input->post('departure_date')."') ";
		}
		
		if($this->input->post('book_status') != ''){
			$whereClaue .= 	" AND rs.bookingstatus = '".$this->input->post('book_status')."'  ";
		}
		//$whereClaue .=     " AND brd.RoutID = rs.RoutID ";

        $orderField = " bm.id";
        $orderDir = " ASC";

        // Set Order Field
        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != ""){
            $orderField = $searchCriteria['orderField'];
        }

        // Set Order Field
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != ""){
            $orderDir = $searchCriteria['orderDir'];
        }
		
		/*LEFT JOIN route_stop AS ruts
                            ON rs.routstopID = ruts.id 
                            LEFT JOIN route AS rut
                            ON rs.RoutID = rut.id 
                            LEFT JOIN city_master AS cm1
                            ON ruts.from_city_id = cm1.city_id 
                            LEFT JOIN city_master AS cm2
                            ON ruts.to_city_id = cm2.city_id 
                            LEFT JOIN air_master AS am
                            ON ruts.air_id = am.id
                            LEFT JOIN airport_master AS apm
                            ON ruts.airport_id = apm.id*/

        /*$sqlQuery = "SELECT ".$selectField." FROM booking_person_rout_seat  AS rs 
                            LEFT JOIN booking_route_detail AS brd ON brd.BookingID = rs.BookingID
							LEFT JOIN booking_passenger_detail as bpd ON bpd.bookingid = rs.BookingID
							LEFT JOIN booking_master as bm ON bm.id = rs.BookingID
							LEFT JOIN ccavenue_response cr ON cr.order_id = rs.BookingID
                            ".$whereClaue." GROUP BY bm.id ORDER BY ".$orderField." ".$orderDir."";*/
		
		$sqlQuery = "SELECT ".$selectField." FROM booking_master  AS rs 
							LEFT JOIN paymentdetail pd ON pd.booking_id = rs.id
                            ".$whereClaue."  ORDER BY ".$orderField." ".$orderDir."";
        $result     = $this->db->query($sqlQuery);
        $rsData     = $result->result_array();
        return $rsData;
        
	}
	
	function cancel_booking($id = NULL){
		return $this->db->set(array('bookingstatus'=>3,'updateby'=>$this->session->userdata('sess_intUserId'),'updatedate'=>date('Y-m-d H:i:s')))->where(array('id'=>$id))->update('booking_master');
	}
	
	function active_booking($id){
		return $this->db->set(array('bookingstatus'=>2,'updateby'=>$this->session->userdata('sess_intUserId'),'updatedate'=>date('Y-m-d H:i:s')))->where(array('id'=>$id))->update('booking_master');
	}
	function booking_details($id){
		
		$select = "bm.id as bid, bm.CustomerID as cid, bm.BookingDate bookingDate, bm.departureDate as departure_date, bm.NoOfPassenger as t_pass, bm.totalcharges as total_amount, CONCAT(bpd.title,' ',bpd.first_name,' ',bpd.last_name) as uname, bpd.email_address as email, bpd.contact_phone as contact_number, bpd.ptype as ptype, bpd.pbirthdate as bdate, bpd.pdocumentname as docname, bpd.pdocfile as pdoc ";
		$where = "bm.id = ".$id;
		$this->db->select($select);
		$this->db->from('booking_master bm');
		$this->db->join('booking_passenger_detail bpd','bpd.bookingid = bm.id','left');
		
		$this->db->where($where);
		$rs['booking_data'] = $this->db->get()->result_array();
		
		if(!empty($rs['booking_data'])){
			$select = "bprs.FareAmount as seat_fare_amount, bprs.PersonID as person_id, CONCAT(bpd.title,' ',bpd.first_name,' ',bpd.last_name) as uname, bpd.email_address as email, bpd.contact_phone as contact_number, bpd.ptype as ptype, bpd.pbirthdate as bdate, bpd.pdocumentname as docname, bpd.pdocfile as pdoc, rss.SeatNM as seat_name, rt.route_code as route_code, cm.city_name as from_city_name, cmt.city_name as to_city_name,rst.departure as departuretime, rst.arrival as arrivaltime ";
			$where = "bprs.BookingID = ".$id;
			$this->db->select($select);
			$this->db->from('booking_person_rout_seat bprs');
			$this->db->join('rout_stop_seats rss','rss.id = bprs.SeatID','left');
			$this->db->join('route_stop rst','rst.id = rss.RoutStopid','left');
			$this->db->join('route rt','rt.id = bprs.RoutID','left');
			$this->db->join('city_master cm','cm.city_id = rst.from_city_id','left');
			$this->db->join('city_master cmt','cmt.city_id = rst.to_city_id','left');
			$this->db->join('booking_passenger_detail bpd','bpd.id = bprs.PersonID','left');
			$this->db->where($where);
			$this->db->order_by('rss.id','ASC');
			$rs['SeatDetails'] = $this->db->get()->result_array();
			
			$select = "bm.id as bid, bm.CustomerID as cid, CONCAT(cm.first_name,' ',cm.middle_name,' ',cm.last_name) as cname, cm.mobile_no as cmobile, cm.email as cemail, cm.gender as cgender, cm.dob as cbdate, cm.nationality as cnationality, cm.address1 as cadd1, cm.address2 as cadd2, cm.InsertType as cinstype, cm.passport_id as cpass_id";
			$where = "bm.id = ".$id;
			$this->db->select($select);
			$this->db->from('booking_master bm');
			$this->db->join('customer_master cm','cm.id = bm.CustomerID','left');
			$this->db->where($where);
			$rs['CustomerData'] = $this->db->get()->result_array();
		}
		return $rs;
	}
	
	function getBookingStatus(){
		$data = $this->db->get_where('combo_master',array('combo_case'=>'BOOKSTATUS'))->result_array();
		$dd = array();
		foreach($data as $val) $dd[$val['combo_key']] = ucwords($val['combo_value']);
		return $dd;
	}
	
	function change_booking_status($id, $status){
		$query = $this->db->set(array('bookingstatus'=>$status))->where(array('id'=>$id))->update('booking_master');
		$data = $this->db->get_where('booking_person_rout_seat',array('BookingID'=>$id))->result_array();
		if($status != 2) foreach($data as $v) $this->db->set(array('Is_Booked'=>0))->where(array('id'=>$v['SeatID']))->update('rout_stop_seats');
	}
	
	function checkBookFlag($id = NULL){
		$this->db->select('rss.Is_Booked as booked, bprs.BookingID as bid, bprs.SeatID as seatId, bprs.RoutID as rout_id, bprs.SeatfareID as fare_id, bprs.PersonID as person_id, CONCAT(bpd.title," ",bpd.first_name," ",bpd.last_name) as pname, bpd.email_address as email, bpd.contact_phone as mobile');
		$this->db->from('booking_person_rout_seat bprs');
		$this->db->join('rout_stop_seats rss','rss.id = bprs.SeatID','left');
		$this->db->join('booking_passenger_detail bpd','bpd.bookingid = bprs.BookingID','left');
		$this->db->where('bprs.BookingID = '.$id.' AND rss.Is_Booked = 1');
		//echo $this->db->last_query();exit;
		return $this->db->get()->result_array();
	}
	
	function addCustomer($cusData){
		$count = $this->db->get_where('customer_master','email = "'.$cusData['email'].'" OR  mobile_no = "'.$cusData['mobile_no'].'"')->result_array();
		if(count($count) == 0){
			return $this->db->insert('customer_master',$cusData);
		}else{
			return FALSE;
		}
	}
	
	function getCustomerId($cusData){
		$data = $this->db->get_where('customer_master','email = "'.$cusData['email'].'" OR  mobile_no = "'.$cusData['mobile_no'].'"')->result_array();
		return !empty($data) ? $data[0]['id'] : '';
	}
	
	function checkAlreadyBook($bid = NULL){
		$this->db->select();
		$this->db->from('booking_person_rout_seat bprs');
		$this->db->join('rout_stop_seats rss','rss.id = bprs.SeatID','left');
		$this->db->where(array('bprs.BookingID'=>$bid,'rss.Is_Booked'=>1));
		return $this->db->get()->result_array();
	}
	
	function update_booking($bid = NULL, $cid = NULL){
		$query = $this->db->set(array('CustomerID'=>$cid,'bookingstatus'=>2))->where(array('id'=>$bid))->update('booking_master');
		if($query){
			$upd_paydetail = $this->db->set(array('PaymentType'=>'cash','PaymentBy'=>'ADMIN','order_status'=>'Success'))->where(array('booking_id'=>5))->update('paymentdetail');
			$data = $this->db->get_where('booking_person_rout_seat',array('BookingID'=>$bid))->result_array();
			foreach($data as $v) $this->db->set(array('Is_Booked'=>1))->where(array('id'=>$v['SeatID']))->update('rout_stop_seats');
		}
		return $query;
	}
}