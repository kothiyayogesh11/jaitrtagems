<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Salary_model extends Data {
	var $tbl_employee_masater = "employee_masater";
	var $tbl_emp_salary_detail = "emp_salary_detail";
	var $tbl_file_list = "file_list";
	var $tbl_companymaster = "companymaster";
	var $tbl_branch_master = "branch_master";
	var $tbl_scheme_master = "scheme_master";
	var $tbl_combo_master = "combo_master";
	var $tbl_designation = "designation";
	var $tbl_loanMaster = "LoanMaster";
	var $tbl_EMIMaster = "EMIMaster";
	var $tbl_employee_tds = "employee_tds";
	var $tbl_emp_leave = "emp_leave";
	
    function __construct(){
        parent::__construct();		
        $this->tbl = $this->tbl_emp_salary_detail;
    }

    function getSalary() {
        $searchCriteria = array();
        $searchCriteria = $this->searchCriteria;

        $selectField = "s.id as salaryid , e.EmpFullName as empName , s.startDate as Startdate , s.endDate as Enddate ,  s.salary as salary , s.commitmentSalary as commitmentSalary, cm.combo_value as islast , com.combo_value as isFix, bm.BranchName as bname, comp.name as cname";
        if(isset($searchCriteria['selectField']) && $searchCriteria['selectField'] != "") $selectField = $searchCriteria['selectField'];

        $whereClaue = " 1=1 AND s.delete_flag = 0 and cm.combo_case  = 'STATUSYESNO' and com.combo_case  = 'STATUSYESNO'";

        $orderField = " s.id";
        $orderDir = " DESC";

        if(isset($searchCriteria['orderField']) && $searchCriteria['orderField'] != "") $orderField = $searchCriteria['orderField'];
        if(isset($searchCriteria['orderDir']) && $searchCriteria['orderDir'] != "") $orderDir = $searchCriteria['orderDir'];
/*
        $sqlQuery = "SELECT ".$selectField." FROM emp_salary_detail as s left join employee_masater as e on  left join  combo_master as cm on    left join  combo_master as com on com.combo_key = s.isFix ".$whereClaue." ORDER BY ".$orderField." ".$orderDir." ";*/
		
		$this->db->select($selectField);
		$this->db->from($this->tbl.' s');
		$this->db->join($this->tbl_employee_masater.' e','e.id = s.empID','left');
		$this->db->join($this->tbl_combo_master.' cm','cm.combo_key  = s.isLast','left');
		$this->db->join($this->tbl_combo_master.' com','com.combo_key  = s.isFix','left');
		$this->db->join($this->tbl_companymaster.' comp','comp.id = s.compID','left');
		$this->db->join($this->tbl_branch_master.' bm','bm.id = s.branchID','left');
		$this->db->where($whereClaue);
		$this->db->order_by($orderField,$orderDir);
		
        $result     = $this->db->get();
        $rsData     = $result->result_array();
        return $rsData;
    }
    function update_employee($emp_id){
		$appointment = array('isLast' => 0);    
		$this->db->where('empID', $emp_id);
		$this->db->update('emp_salary_detail', $appointment);    
  	}
  
	function get_employee_by_code($code = NULL){
		return $this->db->get_where($this->tbl_employee_masater,array('EmpCode'=>$code))->result_array();
	}
  
  	function update_is_last($where = array(),$status = 0){
		return $this->db->set(array('isLast'=>$status))->where($where)->update($this->tbl_emp_salary_detail);
	}
	
	function get_branch_by_code($code = NULL){
		return $this->db->get_where($this->tbl_branch_master,array('BranchCode'=>$code))->result_array();
	}
	
	function get_company_by_code($code = NULL){
		return $this->db->get_where($this->tbl_companymaster,array('Code'=>$code))->result_array();
	}
	
	function checkRecExists($empID = NULL, $Date){
		$where = "empID = ".$empID." AND MONTH(startDate) = MONTH('".$Date."') AND YEAR(startDate) = YEAR('".$Date."')";
		return $this->db->get_where($this->tbl_emp_salary_detail,$where)->result_array();
	}
	
	function addImportSalary($data = array()){
		return $this->db->insert($this->tbl_emp_salary_detail,$data);
	}
	
	function updateLastRec($set = array(), $where = array()){
		return $this->db->set($set)->where($where)->update($this->tbl_emp_salary_detail);
	}
	
	function addFileList($data){
		return $this->db->insert($this->tbl_file_list,$data);
	}
	
}