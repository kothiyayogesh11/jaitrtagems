<?php if($blnAjax != 1): ?>
<?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=aheg&m=event_add', $attributes); 
?>

<div class="page-header position-relative">
    <h1>Employee List</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span12 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return openAddPage();"> <i class="icon-plus-sign bigger-125"></i> Add </button>
        <button type="button" class="btn btn-small btn-danger" onclick="return DeleteRow();" name="btnDelete" id="btnDelete"> <i class="icon-trash bigger-125"></i> Delete </button>
    </div>
	
</div>
<br />
<div class="row-fluid">

    <div class="span12">
        <input type="text" id="Code" name="Code" placeholder="Code" value="<?php echo $this->input->get('Code'); ?>" style="height: 22px; width:50px; margin:0;" />
        <select id="selEmp" name="selEmp" style="height: 32px; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->employee_model->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$this->input->get('selEmp'),"Select Employee"); 
		?>
        </select>
        <select id="selComp" name="selComp" style="height: 32px; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->employee_model->tbl_companymaster,"id","Name","","where delete_flag = 0",$this->input->get('selComp'),"Select Company"); 
		?>
        </select>
        <select id="designation" name="designation" style="height: 32px; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->employee_model->tbl_designation,"id","name","","where delete_flag = 0",$this->input->get('designation'),"Select Designation"); 
		?>
        </select>
        
        <select id="status" name="status" style="height: 32px; margin:0;">
			<?php $fSt = $this->input->get('status'); ?>
            <option <?php echo strlen($fSt) == 0 ? 'selected="selected"' : ''; ?> value="">Select Status</option>
            <option <?php echo $fSt == '0' ? 'selected="selected"' : ''; ?> value="0">Active</option>
            <option <?php echo $fSt == '1' ? 'selected="selected"' : ''; ?> value="1">De-Active</option>
        </select>
        
        <button type="button" class="btn btn-small btn-success" id="filter"> <i class="icon-filter bigger-125"></i> Filter </button>
        <button type="button" class="btn btn-small btn-danger" id="clrfilter"> <i class="icon-filter bigger-125"></i> Clear </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
    	<div id="tableColToggle"></div>
        <table width="100%" cellpadding="5" cellspacing="5" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
                <tr class="hdr">
                    <th width="20">
                    	<input type="checkbox" name="chkAll_list1" id="chkAll_list1" onchange="checkAll('list1');" />
                        <span class="lbl"></span>
                    </th>
                    <th></th>
                    <th>Code</th>
                    <th>Full Name</th>
                    <th>Work Location</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Company</th>
                    <th>Email</th>
                    <th>Mobile No.</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
				if(count($rsUsers)==0){
                    echo "<tr>";
                    echo '<td colspan="12" style="text-align:center;">No data found.</td>';
                    echo "</tr>";
                }else{
                    foreach($rsUsers as $arrRecord) {
                        $strEditLink	=	"index.php?c=employee&m=AddEmployee&action=E&id=".$arrRecord['employeeid'];
                        echo '<tr>';
						echo '<td><input type="checkbox" name="chk_lst_list1[]" id="chk_lst_'.$arrRecord['employeeid'].'" value="'.$arrRecord['employeeid'].'" /><span class="lbl"></span></td>';
                        echo '<td width="20" class="action-buttons" nowrap="nowrap">';
						echo '<a href="'.$strEditLink.'" class="green" title="Edit"><i class="icon-pencil bigger-130"></i></a></td>';
						echo '<td>'. $arrRecord['EmpCode'] .'</td>';
						echo '<td>'. $arrRecord['EmpFullName'] .'</td>';
						echo '<td>'. $arrRecord['LocationName'] .'</td>';
						echo '<td>'. $arrRecord['dmname'] .'</td>';
						echo '<td>'. $arrRecord['dename'] .'</td>';
						echo '<td>'. $arrRecord['cmname'] .'</td>';
						echo '<td>'. $arrRecord['empemail'] .'</td>';
						echo '<td>'. $arrRecord['empmobile'] .'</td>';
						
						$status = isset($arrRecord['empstatus']) && $arrRecord['empstatus']== '1' ? 'Active' : 'Deactive';
						echo '<td>'. $status .'</td>';
                        echo '</tr>';
                    }
				}
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php if($blnAjax != 1): ?>
<?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">
var oTable1;
$(document).ready(function() {

<?php if(count($rsUsers)> 0): ?>
oTable1 = $('#pagelist_center').dataTable( {
			"aoColumns": [{"bSortable": false}, {"bSortable": false},null, null, null, null, null, null, null,null,null],
			"iDisplayLength": 25,
		});

if(oTable1){
	var len = oTable1.fnSettings().aoColumns;
	var colStr = '<b>Select TO show / hide columns : &nbsp;</b>';
	for(i = 0; i < len.length; i++){
		var colTitle = $.trim(oTable1.fnSettings().aoColumns[i].sTitle.replace(/(<([^>]+)>)/ig,""));
		if(colTitle != '')
		colStr += '<span><a href="javascript:void(0);" onclick="fnShowHide('+i+');">'+colTitle+',</a> &nbsp;</span>';
	}
	$('#tableColToggle').html(colStr);
}

<?php endif; ?>

});	

function openAddPage()
{
    window.location.href = 'index.php?c=employee&m=AddEmployee&action=A';
}

function DeleteRow()
{
	var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
	if(intChecked == 0)
	{
		alert("No User selected.");
		return false;
	}
	else
	{
		var responce = confirm("Do you want to delete selected record(s)?");
		if(responce==true)
		{
			$('#frm_list_record').attr('action','index.php?c=employee&m=delete');
			$('#frm_list_record').submit()	
		}
	}
}

$(document).on('click','#filter',function(){
	window.location.href = "?c=employee&m=index&Code="+$('#Code').val()+"&selEmp="+$('#selEmp').val()+"&selComp="+$('#selComp').val()+"&designation="+$('#designation').val()+"&status="+$('#status').val();
});

$(document).on('click','#clrfilter',function(){
	window.location.href = "?c=employee";
});
</script>
