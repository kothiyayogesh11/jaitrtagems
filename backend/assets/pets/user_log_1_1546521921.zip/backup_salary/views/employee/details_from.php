<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_customer', 'name' => 'frm_add_customer');
echo form_open_multipart('c=empoyee_details&m=SaveDetails', $attributes);
?>
<style type="text/css">
input[type=checkbox], input[type=radio] { opacity: 1; position: inherit;}
</style>
<div class="page-header position-relative">
    <h1>Add Employee Details</h1>
    <?php
		echo $strMessage;
	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        		
            <div class="control-group">
                <label for="form-field-1" class="control-label">Employee<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="empid" id="empid" >
                        <?php echo $this->Page->generateComboByTable("employee_masater","id","EmpFullName","","where delete_flag=0 AND Status = 0 order by id",$rsEdit->empid,"Select Employee"); ?>
                    </select>
                </div>
            </div>
        	
          <div class="control-group">
                <label for="form-field-1" class="control-label">Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="name" name="name" class="span6 required" value="<?php echo $rsEdit->name ?>"/>
                </div>
            </div>

          
        	 <div class="control-group">
                <label for="form-field-1" class="control-label">Profile Pic.<span class="red">*</span></label>
                <div class="controls">
                <?php if(isset($rsEdit->profilepic)){ ?>
                <input type="file" id="profilepic" name="profilepic" value="<?php echo $rsEdit->profilepic;?>" />
                <img src="<?php echo base_url($rsEdit->profilepic)?>" height="150" width="150" >
			  <?php } else { ?>
			 <input type="file" id="profilepic" name="profilepic" class="required span6" />
                 <?php } ?>
			    <?php echo form_error('profilepic');?>
                </div>
            </div>
        
        	<div class="control-group">
                <label for="form-field-1" class="control-label">Email<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="email" name="email" class="span6 required isemail" value="<?php echo $rsEdit->email ?>" onblur="checkEmail(this)"/>
                    &nbsp; <span id="email_error"></span>
                </div>
            </div>

        
        	<div class="control-group">
                <label for="form-field-1" class="control-label">Password<span class="red">*</span></label>
                <div class="controls">
                 <?php $password = isset($rsEdit->password) && $rsEdit->password != '' ? '' :'required'  ;?>
                   <input type="password" id="password" name="password" class="<?php echo $password;?> span6" value="" />
                </div>
            </div>    
        
        	<div class="control-group">
                <label for="form-field-1" class="control-label">Confirm Password<span class="red">*</span></label>
                <div class="controls">
                 <?php $password = isset($rsEdit->password) && $rsEdit->password != '' ? '' :'required'  ;?>
                   <input type="password" id="cpassword" name="cpassword" class="<?php echo $password;?> span6" value="" />
                </div>
            </div>
        

            <div class="control-group">
                <label for="form-field-1" class="control-label">Status<span class="red">*</span></label>
                <div class="controls">
                	<select class="required span6" name="status" id="status" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUS' order by seq",$rsEdit->status,""); ?>
                    </select>
                </div>
            </div>

            <div class="control-group non-printable">
                <div class="controls">
                        <input type="submit" class="btn btn-primary btn-small newsubmit" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>

<script type="text/javascript">
	$('.newsubmit').click(function(){
		return true;
		 var password = $('#password').val();
		 var cpass = $('#cpassword').val();
		    
		    if(password != cpass){
				  $('#password').addClass('required');
				  $('#cpassword').addClass('required'); 
				  return false;
		    }
		    return true;
		    
	});
   

    function checkEmail(obj) {
	    var field = obj.id;
        var fieldVal = $('#'+obj.id).val();
	   
        $.ajax({
            type:"POST",
            url:"index.php?c=empoyee_details&m=checkEmail",
            data:"field="+field+"&fieldVal="+fieldVal+"&id="+<?php echo $id ? $id : 'null'; ?>,
            beforeSend:function(){
            },
            success:function(res){
                if (res == 'emailExists'){
                    $('#'+obj.id+'_error')
                        .css('color', 'red')
                        .html("Email already exists.");
                    $('#'+obj.id).addClass('border-red');
                    $('#'+obj.id).focus();
                }
                else{
                    $('#'+obj.id+'_error').empty();
                    $('#'+obj.id).removeClass('border-red');
                }
            }
        });
    }

    function getStates(obj) {
        var fieldVal = $('#'+obj.id).val();
        $.ajax({
            type:"POST",
            url:"index.php?c=city&m=getStates",
            data:"fieldVal="+fieldVal+"&state_id="+<?php echo isset($rsEdit->state) ? $rsEdit->state : 'null';?>,
            success:function(res){
                if (res){
                    $('#slt_state').empty();
                    $('#slt_state').append(res);
                }
                <?php if($strAction == 'E'):?>
                    getCities(slt_state);
                <?php endif; ?>
            }
        });
    }

    function getCities(obj) {
        var fieldVal = $('#'+obj.id).val();
        $.ajax({
            type:"POST",
            url:"index.php?c=city&m=getCities",
            data:"fieldVal="+fieldVal+"&city_id="+<?php echo isset($rsEdit->city) ? $rsEdit->city : 'null';?>,
            success:function(res){
                if (res){
                    $('#slt_city').empty();
                    $('#slt_city').append(res);
                }

            }
        });
    }

    $( document ).ready(function() {
        <?php if($strAction == 'E'):?>
            getStates(slt_country);
            //getCities(slt_state);
        <?php endif;?>
        //$("#txt_dob").datepicker({ showOn: 'both'})
    });
    $(function() {
        $("#txt_dob").datepicker({
            format: 'dd/mm/yyyy'
        });
    });

    $('.delete_file_link').click( function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to delete image?'))
        {
            var file = "<?php echo isset($rsEdit->image) ? $rsEdit->image : ''; ?>";
            $.ajax({
                url:"index.php?c=customer&m=deleteImage",
                data:"filename="+file+"&id="+<?php echo isset($rsEdit->id) ? $rsEdit->id : 'null';?>,
                success		: function (data)
                {
                    location.reload();
                }
            });
        }
    });
</script>