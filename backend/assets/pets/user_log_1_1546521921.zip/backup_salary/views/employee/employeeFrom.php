<?php 
include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_user', 'name' => 'frm_add_user');
echo form_open('c=employee&m=saveEmp', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Employee</h1>
    <?php echo $strMessage;	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        	<h5><b>Personal information : </b></h5>
           <?php if($rsEdit->id != ''){?>
          	<div class="control-group">
                <label for="form-field-1" class="control-label">Full Name</label>
                <div class="controls">
                    <input type="text" id="EmpFName" name="EmpFName" class="required span6" value="<?php echo $rsEdit->EmpFName.' '.$rsEdit->EmpMName.' '.$rsEdit->EmpLname; ?>" disabled="disabled"/>
                </div>
            </div>
          
          <?php } ?>
        	<div class="control-group">
                <label for="form-field-1" class="control-label">First Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="EmpFName" name="EmpFName" class="required span6" value="<?php echo $rsEdit->EmpFName; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Middle Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="EmpMName" name="EmpMName" class="required span6" value="<?php echo $rsEdit->EmpMName; ?>" />
                </div>
            </div>
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">Last Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="EmpLname" name="EmpLname" class="required span6" value="<?php echo $rsEdit->EmpLname; ?>" />
                </div>
            </div>
        
        	<div class="control-group">
                <label for="form-field-1" class="control-label">Nick Name</label>
                <div class="controls">
                    <input type="text" id="NickName" name="NickName" class="span6" value="<?php echo $rsEdit->NickName; ?>" />
                </div>
            </div>
          
        	 <div class="control-group">
                <label for="form-field-1" class="control-label">Code<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="EmpCode" name="EmpCode" class="required span6" value="<?php echo $rsEdit->EmpCode; ?>" onblur="checkEmployeeCode(this)" />&nbsp; <span id="EmpCode_error"></span>
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Ext Code<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="EmpExtCode" name="EmpExtCode" class="required span6" value="<?php echo $rsEdit->EmpExtCode; ?>" onblur="checkEmployeeCode(this)"/>&nbsp; <span id="EmpExtCode_error"></span>
                </div>
            </div>
			
            <div class="control-group">
                <label class="control-label">Gender <span class="red">*</span></label>
                <div class="controls">
                	<?php $selGender = $rsEdit->gender; ?>
                    <select class="span6" name="gender">
                    	<option <?php echo $selGender == 'Male' ? 'selected="selected"' : ''; ?> value="Male">Male</option>
                        <option <?php echo $selGender == 'Female' ? 'selected="selected"' : ''; ?> value="Female">Female</option>
                    </select>
                </div>
            </div>
            			
            <div class="control-group">
                <label for="form-field-1" class="control-label">Date of Birth<span class="red">*</span></label>
                <div class="controls">
                   	<select class="required span2" name="date" id="date" >
                    	<option value="">Select Date</option>
					<?php for($i=1;$i<=31 ;$i++){
						$time=strtotime($rsEdit->DOB);
						$date = date("d",$time);
						$selectdate = isset($rsEdit->DOB) && @$rsEdit->DOB != '' && ($i==$date)? 'selected = selected' : '';
						    echo '<option '.$selectdate.' value="'.str_pad($i, 2, '0', STR_PAD_LEFT).'">'.str_pad($i, 2, '0', STR_PAD_LEFT).'</option>';	
                         }?>
                    </select>
                    <select class="required span2" name="month" id="month" >
                    	<option value="">Select Month</option>
					<?php for($m=1;$m<=12 ;++$m){
						$time=strtotime($rsEdit->DOB);
						$month = date("m",$time);
						$selectmonth = isset($rsEdit->DOB)  && @$rsEdit->DOB != '' && ($m==intval($month))? 'selected = selected' : '';
							echo '<option '.$selectmonth.' value="'.str_pad($m, 2, '0', STR_PAD_LEFT).'">'.date('F', mktime(0, 0, 0, $m, 1)).'</option>';
                         }?>
                    </select>
                    <select class="required span2" name="year" id="year" >
                   		<option value="">Select Year</option>
					<?php for($y= date('Y');$y >= 1960 ;$y--){
						$time = isset($rsEdit->DOB) ? strtotime($rsEdit->DOB) : time();
						$year = date('Y',$time);
						$selectyear = ($y == $year)? 'selected = "selected"' : '';
							echo '<option '.$selectyear.' value="'.$y.'">'.$y.'</option>';
                         }?>
                    </select>
                </div>
            </div>
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">Email<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="Email" name="Email" class="required span6 isemail" value="<?php echo $rsEdit->Email; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Work Email<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="WorkEmai" name="WorkEmai" class="required span6 isemail" value="<?php echo $rsEdit->WorkEmai; ?>" />
                </div>
            </div>
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">Mobile No.<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="Moblie" name="Moblie" class="required span6 isnumber" value="<?php echo $rsEdit->Moblie; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Phone No.</label>
                <div class="controls">
                    <input type="text" id="Moblie1" name="Moblie1" class="span6" value="<?php echo $rsEdit->Mobile1; ?>" />
                </div>
            </div>
           	
            <div class="control-group">
                <label for="form-field-1" data-Dep="<?php echo @$rsEdit->EmpDeptID; ?>" class="control-label">Company<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="CompanyID" id="CompanyID" >
                    	<?php echo $this->Page->generateComboByTable("companymaster","id","Name","","where delete_flag = 0",$rsEdit->CompanyID,"Select Company"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Branch<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="BranchID" id="BranchID" >
                    	<?php echo $this->Page->generateComboByTable("branch_master","id","BranchName","","where delete_flag = 0",$rsEdit->BranchID,"Select Branch"); ?>
                    </select>
                </div>
            </div>
           
           	<div class="control-group">
                <label for="form-field-1" class="control-label">Designation<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="DesignationID" id="DesignationID" >
                    	<?php echo $this->Page->generateComboByTable("designation","id","name","","where delete_flag = 0",$rsEdit->DesignationID,"Select Designation"); ?>
                    </select>
                </div>
            </div>
            
            
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Department<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="EmpDeptID" id="EmpDeptID" >
						<?php 
						$dipWher = "";
						//$dipWher = $rsEdit->CompanyID != '' ? " AND ToComp =  ".@$rsEdit->CompanyID : '';
						echo $this->Page->generateComboByTable("departmentmaster","id","Name","","where delete_flag = 0".@$dipWher,$rsEdit->EmpDeptID,"Select Department"); 						
						?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Work Location<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="EmpWorkLocationId" id="EmpWorkLocationId" >
                    	<?php echo $this->Page->generateComboByTable("worklocationmaster","id","LocationName","","",$rsEdit->EmpWorkLocationId,"Select Work Location"); ?>
                    </select>
                </div>
            </div>

            
            <div class="control-group">
                <label for="form-field-1" class="control-label">DOJ Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="dojdate" name="dojdate" class="required span6" value="<?php echo $rsEdit->DOJ; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">DOL</label>
                <div class="controls">
                    <input type="text" id="doldate" name="doldate" class="span6" value="<?php echo $rsEdit->DOL; ?>" />
                </div>
            </div>
            
            
            <h5><b>Address : </b></h5>
            <div class="control-group">
                <label class="control-label">Permanent <span class="red">*</span></label>
                <div class="controls">
                	<div class="col-sm-12 dd-wrap" style="margin-bottom:5px;">
                    <select class="required" name="prCountry" data-type="country" id="prCountry">
                    	<?php 
						$prCountryID = isset($rsEdit->prCountry) ? $rsEdit->prCountry : 6;
						echo $this->Page->generateComboByTable("country_master","country_id","country_name","","where status = 'ACTIVE'",$prCountryID,"Select Country");
						?>
                    </select>
                    <select class="required" name="prState" data-type="state" id="prState">
                    	<?php 
						$prStateID = isset($rsEdit->prState) ? $rsEdit->prState : 3;
						$prStateWhere = "where status = 'ACTIVE' AND country_id = ".$prCountryID." ";
						echo $this->Page->generateComboByTable("state_master","state_id","state_name","",$prStateWhere,$prStateID,"Select State");
						?>
                    </select>
                    <select class="required" name="prCity" data-type="city" id="prCity">
                    	<?php 
						$prCityID = isset($rsEdit->prCity) ? $rsEdit->prCity : '';
						$prCityIDWhere = "where status = 'ACTIVE' AND country_id = ".$prCountryID." AND state_id = ".$prStateID;
						echo $this->Page->generateComboByTable("city_master","city_id","city_name","",$prCityIDWhere,$prCityID,"Select City");
						?>
                    </select>
                    </div>
                    <div class="col-sm-12">
                    	<textarea placeholder="Address" name="prAddress" class="span6"><?php echo isset($rsEdit->prAddress) ? $rsEdit->prAddress : ''; ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Resident</label>
                <div class="controls">
                	<div class="col-sm-12 dd-wrap" style="margin-bottom:5px;">
                    <select class="" name="rsCountry" data-type="country" id="rsCountry">
                    	<?php 
						$rsCountryID = isset($rsEdit->rsCountry) ? $rsEdit->rsCountry : 6;
						echo $this->Page->generateComboByTable("country_master","country_id","country_name","","where status = 'ACTIVE'",$rsCountryID,"Select Country");
						?>
                    </select>
                    <select class="" name="rsState" data-type="state" id="rsState">
                    	<?php 
						$rsStateID = isset($rsEdit->rsState) ? $rsEdit->rsState : 3;
						$rsStateWhere = "where status = 'ACTIVE' AND country_id = ".$rsCountryID." ";
						echo $this->Page->generateComboByTable("state_master","state_id","state_name","",$rsStateWhere,$rsStateID,"Select State");
						?>
                    </select>
                    <select class="" name="rsCity" data-type="city" id="rsCity">
                    	<?php 
						$rsCityID = isset($rsEdit->rsCity) ? $rsEdit->rsCity : '';
						$rsCityIDWhere = "where status = 'ACTIVE' AND country_id = ".$rsCountryID." AND state_id = ".$rsStateID;
						echo $this->Page->generateComboByTable("city_master","city_id","city_name","",$rsCityIDWhere,$rsCityID,"Select City");
						?>
                    </select>
                    </div>
                    <div class="col-sm-12">
                    	<textarea placeholder="Address" name="rsAddress" class="span6"><?php echo isset($rsEdit->rsAddress) ? $rsEdit->rsAddress : ''; ?></textarea>
                    </div>
                </div>
            </div>
            
            <h5><b>Bank Details: </b></h5>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Bank Name</label>
                <div class="controls">
                    <input type="text" id="BankName" name="BankName" class="span6" value="<?php echo $rsEdit->BankName; ?>" />
                </div>
            </div>
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">Bank Account NO</label>
                <div class="controls">
                    <input type="text" id="BankAcNo" name="BankAcNo" class="span6" value="<?php echo $rsEdit->BankAcNo; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">IFSC Code</label>
                <div class="controls">
                    <input type="text" id="IFSCCode" name="IFSCCode" class="span6" value="<?php echo $rsEdit->IFSCCode; ?>" />
                </div>
            </div>
            
		 
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">PAN</label>
                <div class="controls">
                    <input type="text" id="PAN" name="PAN" class="span6" value="<?php echo $rsEdit->PAN; ?>" />
                </div>
            </div>
		           
             <div class="control-group">
                <label for="form-field-1" class="control-label">Aadhar No</label>
                <div class="controls">
                    <input type="text" id="AadharNo" name="AadharNo" class="span6" value="<?php echo $rsEdit->AadharNo; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">ESI Number</label>
                <div class="controls">
                    <input type="text" id="EsiNumber" name="EsiNumber" class="span6" value="<?php echo $rsEdit->EsiNumber; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">PF Number</label>
                <div class="controls">
                    <input type="text" id="PFNumber" name="PFNumber" class="span6" value="<?php echo $rsEdit->PFNumber; ?>" />
                </div>
            </div>
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">PFUAN No</label>
                <div class="controls">
                    <input type="text" id="PFUANNo" name="PFUANNo" class="span6" value="<?php echo $rsEdit->PFUANNo; ?>" />
                </div>
            </div>
            
            <h5><b>Other information : </b></h5>
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">MaritalStatus</label>
                <div class="controls">
                	<select class="span6" name="MaritalStatus" id="MaritalStatus" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUSYESNO' order by seq",$rsEdit->MaritalStatus,""); ?>
                    </select>
                </div>
            </div>
 
            <div class="control-group">
                <label for="form-field-1" class="control-label">Father/Husband Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="FatherHusbandName" name="FatherHusbandName" class="required span6" value="<?php echo $rsEdit->FatherHusbandName; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Father/Husband</label>
                <div class="controls">
                    <select class="span6" data-key="<?php echo @$rsEdit->FathHusb; ?>" name="FathHusb" id="FathHusb" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value","","where combo_case='FATHUB' order by seq",$rsEdit->FathHusb,"Select Relation"); ?>
                    </select>
                </div>
            </div>
            
           
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">IsPPStr</label>
                <div class="controls">
                	<select class="span6" name="IsPPStr" id="IsPPStr" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUSYESNO' order by seq",$rsEdit->IsPPStr,""); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">IsCalByEarn</label>
                <div class="controls">
                	<select class="span6" name="IsCalByEarn" id="IsCalByEarn" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUSYESNO' order by seq",$rsEdit->IsCalByEarn,""); ?>
                    </select>
                </div>
            </div>
            
            
            
            
            
             <div class="control-group">
                <label for="form-field-1" class="control-label">Status<span class="red">*</span></label>
                <div class="controls">
                	<select class="required span6" name="status" id="status" >
                        <?php 
							$status = @$rsEdit->Status == '1' ? 'ACTIVE' : 'DEACTIVE';
							echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUS' order by seq",$status,""); 
						?>
                    </select>
                </div>
            </div>
            
            <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>

<script type="text/javascript">
$("#dojdate").datepicker({format: 'yyyy-mm-dd',	todayBtn: true,	autoclose: true});
$("#doldate").datepicker({format: 'yyyy-mm-dd', todayBtn: true,	autoclose: true});

/*$(document).on('change','#CompanyID',function(){
	var compID = $(this).val();
	var id = $(this).attr('data-Dep');
	if(compID != ''){
		$.ajax({
			type:"POST",
			url:"?c=employee&m=getDepByCompany",
			data:{'compID':compID,'id':id},
			success: function(res){
				$('#EmpDeptID').html(res);
			}
		});
	}
});*/

function checkEmployeeCode(obj) {
	var field = obj.id;
	 var fieldVal = $('#'+obj.id).val();
	 $.ajax({
		type:"POST",
		url:"index.php?c=employee&m=checkEmployeeCode",
		data:"field="+field+"&fieldVal="+fieldVal+"&id="+<?php echo $id ? $id : 'null'; ?>,
		success:function(res){
			if (res == 'EmpCodeExists'){
				$('#'+obj.id+'_error')
					.css('color', 'red')
					.html("Employee Code is already Exists.");
				$('#'+obj.id).addClass('border-red');
				$('#'+obj.id).focus();
			}
			else if (res == 'EmpExtCodeExists'){
				$('#'+obj.id+'_error')
					.css('color', 'red')
					.html("Employee Ext code is already Exists.");
				$('#'+obj.id).addClass('border-red');
				$('#'+obj.id).focus();
			}
			else{
				$('#'+obj.id+'_error').empty();
				$('#'+obj.id).removeClass('border-red');
			}
		}
	});
}

$(document).on('change','select[data-type="country"]',function(e){
	var $obj = $(this);
	var $per = $obj.parents('.dd-wrap');
	var $state_id = $per.find('select[data-type="state"]').val();
	if($obj.val() != ''){
		$.ajax({
			type:"POST",
			url:"index.php?c=employee&m=getstate_by_country",
			data:{'id':$obj.val(),'state_id':$state_id},
			dataType:"json",
			success: function(res){
				if(typeof res.error != 'undefined' && res.error == 0){
					$per.find('select[data-type="state"]').html(res.option);
				}
			}
		});
	}
});

$(document).on('change','select[data-type="state"]',function(e){
	var $obj = $(this);
	var $per = $obj.parents('.dd-wrap');
	var $country = $per.find('select[data-type="country"]').val();
	var $city_id = $per.find('select[data-type="city"]').val();
	if($obj.val() != ''){
		$.ajax({
			type:"POST",
			url:"index.php?c=employee&m=getcity_by_state",
			data:{'id':$country,'city_id':$city_id,'state_id':$obj.val()},
			dataType:"json",
			success: function(res){
				if(typeof res.error != 'undefined' && res.error == 0){
					$per.find('select[data-type="city"]').html(res.option);
				}
			}
		});
	}
});

</script>