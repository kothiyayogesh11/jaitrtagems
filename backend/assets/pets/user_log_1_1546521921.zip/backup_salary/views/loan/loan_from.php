<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_user', 'name' => 'frm_add_user');
//echo form_open('c=scheme_master&m=process', $attributes);
echo form_open('c=loan&m=process', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Lone</h1>
    <?php echo $strMessage; ?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        	<div class="control-group">
                <label class="control-label">Beneficiary Type<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="beneficiary_type" id="beneficiary_type" >
                    	<?php echo $this->Page->generateComboByTable($this->loan->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$rsEdit->EmployeeId,"Select Type"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Amount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" class="span6 required" name="Amount" value="<?php echo $rsEdit->Amount; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">LoneIntrest<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" class="span6 required" name="LoneIntrest" value="<?php echo $rsEdit->LoneIntrest; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">EMIAmount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" class="span6 required" name="EMIAmount" value="<?php echo $rsEdit->EMIAmount; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Lone Start Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="LoneStartDate" id="LoneStartDate" class="required span6" placeholder="LoneStartDate" value="<?php echo $rsEdit->LoneStartDate; ?>" />
                </div>
            </div>
        
        	<div class="control-group">
                <label class="control-label">EMIStartDate<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="EMIStartDate" id="EMIStartDate" class="required span6" placeholder="EMIStartDate" value="<?php echo $rsEdit->EmiStartDate; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">NoOfEmi<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" class="span6 required" name="NoOfEmi" value="<?php echo $rsEdit->NoOfEmi; ?>" />
                </div>
            </div>
          
        	 <div class="control-group">
                <label class="control-label">Lone End Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="LoneEndDate" class="span6 required" name="LoneEndDate" placeholder="LoneEndDate" value="<?php echo $rsEdit->LoneEndDate; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Note<span class="red">*</span></label>
                <div class="controls">
                    <textarea type="text" id="Note" class="span6 required" name="Note"><?php echo $rsEdit->Note; ?></textarea>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Lone Approve By<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="LoneApproveBy" class="span6 required" name="LoneApproveBy" value="<?php echo $rsEdit->LoneApproveBy; ?>" />
                </div>
            </div>

		  
            
          <!--  <div class="control-group">
                <label class="control-label">Beneficiary Type<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="beneficiary_type" id="beneficiary_type" >
                    	<?php //echo $this->Page->generateComboByTable($this->loan->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$rsEdit->EmployeeId,"Select Type"); ?>
                    </select>
                </div>
            </div>-->
            
            <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save"> 
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>
<?php include(APPPATH.'views/bottom.php'); ?>

<script type="text/javascript">
$(document).ready(function(e) {
	//$("#Employee").chosen({no_results_text: "Oops, nothing found!"});
    $('#LoneDate').datepicker({autoclose: true,format: 'yyyy-mm-dd'});
});

$(document).on('change','#beneficiary_type',function(){
	var $obj = $(this);
	var $id = $('#Beneficiary').val();
	if($obj.val() != ''){
		$.ajax({
			type:"POST",
			url:base_url+"?c=scheme_master&m=get_beneficiary_type_list",
			data:{'type':$obj.val(),'id':$id},
			success: function(res){
				$('#Beneficiary').html(res);
			}
		});
	}else{
		$('#Beneficiary').find('option').not('option[value=""]').remove();
	}
});

$(document).on('change','#Beneficiary',function(){
	var $bftype = $('#beneficiary_type').val();
	var $bf = $('#Beneficiary').val();
	if($bftype != '' || $bf != ''){
		$.ajax({
			type:"POST",
			url:base_url+"?c=scheme_master&m=get_beneficiary_employee",
			data:{'type':$bftype,'id':$bf},
			success: function(res){
				$('#Employee').html(res);
				//$("#Employee").chosen(res);
			}
		});
	}else{
		$('#Beneficiary').find('option').not('option[value=""]').remove();
	}
});

$(document).on('click','input[type="submit"]',function(e){
	var err_flag = true;
	$(this).parents('form').find('.required').each(function(index, element) {
        if($(element).val() == ''){
			err_flag = false;
			$(element).addClass('border-red');
		}else{
			if(element.name == 'BranchCode' && !codeFlag){
				err_flag = false;
				$(element).addClass('border-red');
			}else{
				$(element).removeClass('border-red');
			}
			
		}
    });
	return err_flag && codeFlag;
});

</script>
