<?php if($blnAjax != 1){ ?>
<?php include(APPPATH.'views/top.php'); ?>
<?php } ?>
<style>
.tr-hide{display:none;}
#OrderDetails{left: 23%;  z-index: 1050;  width: auto;    margin-left: 0;}
#exampleModalLong{z-index:1060;}
</style>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=loan&m=addLoan', $attributes); 
?>

<div class="page-header position-relative">
    <h1>Loan List</h1>
    <?php echo $this->Page->getMessage(); ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return openAddPage();"> <i class="icon-plus-sign bigger-125"></i> Add </button>
        <button type="button" class="btn btn-small btn-danger" onclick="return DeleteRow();" name="btnDelete" id="btnDelete"> <i class="icon-trash bigger-125"></i> Delete </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
    	<div id="tableColToggle"></div>
        <table width="100%" cellpadding="8" cellspacing="8" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
                <tr class="hdr">
                    <th width="20">
                    	<input type="checkbox" name="chkAll_list1" id="chkAll_list1" onchange="checkAll('list1');" />
                        <span class="lbl"></span>
                    </th>
                    <th></th>
                    <th>+/-</th>
                    <th>Employee Name</th>
                    <th>Amount</th>
                    <th>No Of Emi</th>
                    <th>EMI Amount</th>
                    <th>Lone Start Date</th>
                    <th>Lone End Date</th>
                    <th>Lone Approve By</th>
                    <!--<th>View</th>-->
                </tr>
            </thead>
            <tbody>
                <?php
				if(count($rsList)==0){
                    echo "<tr>";
                    echo '<td colspan="12" style="text-align:center;">No data found.</td>';
                    echo "</tr>";
                } else {
                    foreach($rsList as $arrRecord) {
                        $strEditLink	=	"index.php?c=loan&m=addLoan&action=E&id=".$arrRecord['loanid'];
                        echo '<tr data-val="'.$arrRecord['loanid'].'" data-id = '.$sval['loanid'].'>';
						echo '<td><input type="checkbox" name="chk_lst_list1[]" id="chk_lst_'.$arrRecord['loanid'].'" value="'.$arrRecord['loanid'].'" /><span class="lbl"></span></td>';
                        echo '<td width="20" class="action-buttons" nowrap="nowrap">';
						echo '<a href="'.$strEditLink.'" class="green" title="Edit"><i class="icon-pencil bigger-130"></i></a></td>';
						echo '<td class="plus span1 center booking-details" data-toggle="modal" data-target="#OrderDetails" data-val="'.$arrRecord['loanid'].'" id="'.$record['orderid'].'" style="color:#0b6cbc;">View</td>';
						echo '<td>'. $arrRecord['empname'] .'</td>';
						echo '<td>'. $arrRecord['amount'] .'</td>';
						echo '<td>'. $arrRecord['noofemi'] .'</td>';
						echo '<td>'. $arrRecord['EMIamount'] .'</td>';
						echo '<td>'. $arrRecord['loanstartdate'] .'</td>';
						echo '<td>'. $arrRecord['loanenddate'] .'</td>';
						echo '<td>'. $arrRecord['LoneApproveBy'] .'</td>';
						//echo '<td class="view_notification"><input type="button" class="btn btn-primary btn-small" value="View"></td>';					
						echo '</tr>';
                    }
				}
                ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="OrderDetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
     
        <h5 class="modal-title" style=" display: initial;" id="exampleModalLongTitle">Loan Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
       <span id="msg"></span>
      <div class="modal-body">
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php if($blnAjax != 1){ ?>
<?php echo form_close(); ?>
<?php include(APPPATH.'views/bottom.php'); ?>
<?php } ?>

<script type="text/javascript">
var oTable1;

$(document).on('click','.incomplete',function(){
	var emiid = $(this).data('val');
	var obj = $(this);
	if(confirm("Are you sure for Complete EMI?") && (emiid != '')){
		$.ajax({
			type:"POST",
			url:'index.php?c=loan&m=emicomplete',
			data:{'id':emiid},
			dataType:"json",
			success:function(res){
				$('#msg').html(res.msg);
				if(res.error == 0){
					$(obj).removeClass('btn-warning incomplete');
					$(obj).addClass('btn-success');
					$(obj).attr('disabled','disabled');
					$(obj).val('Completed');
					$(obj).css('cursor','no-drop');	
				}
			}
		});
	}
});


$(document).ready(function() {

<?php if(count($rsList) > 0){ ?>
oTable1 = $('#pagelist_center').dataTable( {
	"aoColumns": [{"bSortable": false}, {"bSortable": false},null, null, null, null, null,null,null,null],
	"iDisplayLength": 25,
});

if(oTable1){
	var len = oTable1.fnSettings().aoColumns;
	var colStr = '<b>Select TO show / hide columns : &nbsp;</b>';
	for(i = 0; i < len.length; i++){
		var colTitle = $.trim(oTable1.fnSettings().aoColumns[i].sTitle.replace(/(<([^>]+)>)/ig,""));
		if(colTitle != '')
		colStr += '<span><a href="javascript:void(0);" onclick="fnShowHide('+i+');">'+colTitle+',</a> &nbsp;</span>';
	}
	$('#tableColToggle').html(colStr);
}
<?php } ?>

});	





$(document).on('click','.booking-details',function(){
	var orderid = $(this).data('val');
	var obj = $(this);
	if(orderid != ''){
		$.ajax({
			type:"POST",
			url:'index.php?c=loan&m=loanDetails',
			data:{'id':orderid},
			dataType:"json",
			success:function(res){
				if(typeof res.table != 'undefined' && res.table != ''){
					$('#OrderDetails .modal-body').html(res.table);
					$(obj).removeClass('booking-details');
					$(obj).addClass('hide-booking-details');
				}
			}
		});
	}
});
$(document).on('click','.hide-booking-details',function(){
	var book_id = $(this).data('val');
	var obj = $(this);
	$('#OrderDetails').hide(100);
	$(obj).addClass('booking-details');
	$(obj).removeClass('hide-booking-details');
});



function openAddPage(){
    window.location.href = 'index.php?c=loan&m=addLoan&action=A';
}

function DeleteRow(){
	var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
	if(intChecked == 0){
		alert("No User selected.");
		return false;
	}else{
		var responce = confirm("Do you want to delete selected record(s)?");
		if(responce==true){
			$('#frm_list_record').attr('action','index.php?c=loan&m=delete');
			$('#frm_list_record').submit()	
		}
	}
}


$(document).on('click','.view_notification',function(){
	var notificationid = $(this).parents('tr').attr('data-id');
	var $obj = $(this);
	var len = $('.notification_'+notificationid).length;
	if(len > 0){
		$('.notification_'+notificationid).hide(300,function(){
			$('.notification_'+notificationid).remove();
		});
		$obj.find('input[type="button"]').val('Open');
	}else{
		$tr = $(this).parents('tr');
		$obj.find('input[type="button"]').val('Close');
		if(notificationid != ''){
			$.ajax({
				type:"POST",
				url:'?c=loan&m=getEMIData',
				data:{'id':notificationid},
				dataType:"json",
				success: function(res){
					if(typeof res.error != 'undefined' && res.error == 0){
						$tr.after('<tr class="notification_'+notificationid+'"><td></td><td colspan="6">'+res.view+'</td><tr>');
					}else if(typeof res.error != 'undefined' && res.error == 1){
						$obj.find('input[type="button"]').val('Open');
						alert(res.msg);
					}
				}
			});
		}
	}
})
</script>
