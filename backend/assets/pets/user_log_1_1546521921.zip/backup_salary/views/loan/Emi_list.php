<table style="width:100%">

<thead>

	<tr>

    	<th>No.</th>
     <th>EMI Amount</th>
     <th>EMI Date</th>
     <th>Status</th>
    </tr>

</thead>

<tbody>

	<?php $i = 0;
		foreach($Loan as $nval){ 
		$i++;
	?>
	<tr data-id="<?php echo $nval['id'];?>" data-title = "<?php echo $nval['id']?>" data-desc = "<?php echo $nval['desc']?>" data-notification_id="<?php echo $nval['id'];?>">
     
          <td><?php echo $i;?></td>
          <td><?php echo $nval['EMIAmount']?></td>
          <td><?php echo $nval['EMIDate']?></td>
          <td><?php /*$img = file_check($nval['user_profile']);
                   echo '<img class="rounded-circle tb-img" style="object-fit:cover;height: 40px; width:40px;" src="'.$img.'" alt=""><a class="tdname">'.ucwords($nval['uname']).'<span>'.ucwords($nval['role_name']).'</span></a>';?></td>
          <?php if($nval['send'] == 1){
                    echo '<td><input type="submit" class="btn btn-success btn-xs" id="success_'.$nval['pushid'].'" value="Success" style="cursor:no-drop;"></td>';	
               }else{
                    echo '<td class="sendnotification"><input type="submit" id="success_'.$nval['pushid'].'" onclick=\'return confirm("Are you sure for send the notification?")\' class="btn btn-primary btn-xs" value="Retry to send"></td>';					
               }*/?>
         </td>
    </tr>
	<?php } ?>
</tbody>

</table>
