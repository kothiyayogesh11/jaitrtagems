<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_city', 'name' => 'frm_add_city');
echo form_open('c=predefine_salary&m=process', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Predefine Salary</h1>
    <?php echo $strMessage;	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
            
            <div class="control-group">
                <label class="control-label">Employee<span class="red">*</span></label>
                <div class="controls">
                    <select <?php echo isset($rsEdit->empID) ? 'disabled="disabled"' : ''; ?> class="required span6" name="empID" id="empID" >
                    	<?php echo $this->Page->generateComboByTable($this->salary->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$rsEdit->empID,"Select Employee"); ?>
                    </select>
                    
                </div>
            </div>

			<div class="control-group">
                <label class="control-label">Amount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="amount" name="amount" class="required span6" value="<?php echo $rsEdit->amount; ?>" />
                    <input type="hidden" id="amountOld" class="span6" value="<?php echo $rsEdit->amount; ?>" />
                    <span id="date_error"></span>
                </div>
            </div>

            <div class="control-group">
                <label class="control-label">headID<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" <?php echo isset($rsEdit->empID) ? 'disabled="disabled"' : ''; ?> name="headID" id="headID" >
                    	<?php echo $this->Page->generateComboByTable($this->salary->tbl_salary_head_master,"id","code","","where delete_flag = 0",$rsEdit->headID,"Select Head"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Start Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="start_date"  name="start_date" class="required span6" <?php echo isset($rsEdit->empID) ? 'disabled="disabled"' : ''; ?> value="<?php echo $rsEdit->start_date; ?>"/>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Note<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="note" name="note" class="required span6" value="<?php echo $rsEdit->note; ?>" />
                    <span id="date_error"></span>
                </div>
            </div>
            
		    <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>
<script type="text/javascript">
$( document ).ready(function() {
	$("#start_date").datepicker({format: 'yyyy-mm-dd',todayBtn: true,autoclose: true});
	$("#end_date").datepicker({format: 'yyyy-mm-dd',todayBtn: true,autoclose: true});
});

$(document).on('click','input[type="submit"]',function(e){
	$id = $('#hid_id').val();
	var $flag = false;
	if($id != '' && $('#amountOld').val() != '' && $('#amountOld').val() != $('#amount').val()){
		var $form = $(this).parents('form');
		$form.find('select[disabled="disabled"], input[disabled="disabled"]').each(function(index, el){
			$(el).removeAttr('disabled');
		});
		var $flag = true;
	}else if($('#amountOld').val() != '' && $('#amountOld').val() == $('#amount').val()){
		window.history.back();
	}else{
		var $flag = true;
	}
	return $flag;
});
</script>