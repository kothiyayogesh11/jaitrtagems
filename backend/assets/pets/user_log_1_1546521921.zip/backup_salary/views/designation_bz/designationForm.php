<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_city', 'name' => 'frm_add_city');
echo form_open('c=designation&m=saveDesignation', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Designation</h1>
    <?php
		echo $strMessage;
	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>

            <div class="control-group">
                <label for="form-field-1" class="control-label">Designation<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="name" name="name" class="required span6" value="<?php echo $rsEdit->name; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Code<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="Code" name="Code" class="required span6" value="<?php echo $rsEdit->Code; ?>" />
                </div>
            </div>

            
            <div class="control-group non-printable">
                <div class="controls">
                        <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>
<script type="text/javascript">
    function getStates(obj) {
        var fieldVal = $('#'+obj.id).val();
        $.ajax({
			cache: false,
            type:"POST",
            url:"index.php?c=city&m=getStates",
            data:"fieldVal="+fieldVal+"&state_id="+<?php echo isset($rsEdit->state_id) ? $rsEdit->state_id : 'null';?>,
            success:function(res){
                if (res){
                    $('#slt_state').empty();
                    $('#slt_state').append(res);
                }

            }
        });
    }
    $( document ).ready(function() {
        <?php if($strAction == 'E'):?>
            getStates(slt_country);
        <?php endif;?>
    });
	
	$(document).on('blur','#Code',function(){
		var $obj = $(this);
		var code = $obj.val();
		var id = $('#hid_id').val();
		if(code == ''){
			$.ajax({
				cache: false,
				type:"POST",
				url:"index.php?c=city&m=getStates",
				data:{'Code':code},
				success:function(res){
					if (res){
						$('#slt_state').empty();
						$('#slt_state').append(res);
					}
				}
			});
		}
	});
	
</script>
