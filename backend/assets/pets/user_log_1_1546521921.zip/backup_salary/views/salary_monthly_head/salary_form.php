<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_city', 'name' => 'frm_add_city');
echo form_open('c=salary_monthly_head&m=process', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Employee Monthly Salary Head</h1>
    <?php echo $strMessage;	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
            
            <div class="control-group">
                <label class="control-label">Employee<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="empID" id="empID" >
                    	<?php echo $this->Page->generateComboByTable($this->salary->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$rsEdit->empID,"Select Employee"); ?>
                    </select>
                </div>
            </div>

			<div class="control-group">
                <label class="control-label">Amount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="amount" name="amount" class="required span6" value="<?php echo $rsEdit->amount; ?>" />
                    <span id="date_error"></span>
                </div>
            </div>
               
            <!--<div class="control-group">
                <label class="control-label">PreDefineField<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="preDefineField" name="preDefineField" class="span6" value="<?php echo $rsEdit->preDefineField; ?>"/>
                </div>
            </div>-->
            
            <div class="control-group">
                <label class="control-label">headID<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="headID" id="headID" >
                    	<?php echo $this->Page->generateComboByTable($this->salary->tbl_salary_head_master,"id","code","","where delete_flag = 0",$rsEdit->headID,"Select Head"); ?>
                    </select>
                </div>
            </div>
            
            <!--<div class="control-group">
                <label class="control-label">Employee Code<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="empCode" name="empCode" class="required span6" value="<?php echo $rsEdit->empCode; ?>"/>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">empBranch<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="empBranch" id="empBranch" >
                    	<?php //echo $this->Page->generateComboByTable($this->salary->tbl_branch_master,"id","BranchName","","where delete_flag = 0",$rsEdit->empBranch,"Select Company"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Companay<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="empCompany" id="empCompany" >
                    	<?php //echo $this->Page->generateComboByTable($this->salary->tbl_companymaster,"id","Name","","where delete_flag = 0",$rsEdit->empCompany,"Select Branch"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Employee ESINumber<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="empESINumber" name="empESINumber" class="required span6" value="<?php echo $rsEdit->empESINumber; ?>"/>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">PFNo<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="PFNo" name="PFNo" class="required span6" value="<?php echo $rsEdit->PFNo; ?>"/>
                </div>
            </div>-->
            
            <div class="control-group">
                <label class="control-label">Month<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="month" id="month" >
                    	<option value="">Select Month</option>
                        <?php
						for($i = 1; $i <= 12; $i++){
							$ival = str_pad($i,2,'0',STR_PAD_LEFT);
							$sel = isset($rsEdit->month) && intval($rsEdit->month) == $i ? 'selected="selected"' : '';
							echo '<option value="'.$ival.'" '.$sel.'>'.$ival.'</option>';
						}
						?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Year<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="year" id="year" >
                    	<option value="">Select Year</option>
                        <?php
						for($i = intval(date('Y')); $i >= 1980; $i--){
							$ival = str_pad($i,2,'0',STR_PAD_LEFT);
							$sel = isset($rsEdit->year) && intval($rsEdit->year) == $i ? 'selected="selected"' : '';
							echo '<option value="'.$ival.'" '.$sel.'>'.$ival.'</option>';
						}
						?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="date" name="date" class="required span6" value="<?php echo $rsEdit->date; ?>"/>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Days<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="days" name="days" class="required span6" value="<?php echo $rsEdit->days; ?>"/>
                </div>
            </div>
            
            
		    <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>
<script type="text/javascript">
$( document ).ready(function() {
	$("#date").datepicker({format: 'yyyy-mm-dd',todayBtn: true,autoclose: true});
	<?php if($strAction == 'E'):?>
		getStates(slt_country);
	<?php endif;?>
});

</script>