<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=salary_monthly_head&m=import_add_process', $attributes);
?>
<style>
td.error{ background-color: #ff00001f !important;}
tr.error{ background: #ff000038 !important;}
</style>
<div class="page-header position-relative">
    <h1>Salary Monthly Head</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return submitImport();"> <i class="icon-plus-sign bigger-125"></i> Submit </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
        <table width="100%" cellpadding="3" cellspacing="3" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
            <tr class="hdr">
                <th>No.</th>
                <th>Code / Employee</th>
                <th>Amount</th>
                <th>preDefineField</th>
                <th>headCode</th>
                <th>empESINumber</th>
                <th>PFNo</th>
                <th>Month</th>
                <th>Year</th>
                <th>Date</th>
                <th>Days</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(count($data)==0){
			 	echo "<tr>";
                echo '<td colspan="3" style="text-align:center;">No data found.</td>';
	            echo "</tr>";
            }else{
				$i = 0;
                foreach($data as $arrRecord){
					$trError = isset($arrRecord['error']['recExit']) ? 'error' : '';
                    echo '<tr class="'.$trError.'">';
					
					 echo '<td class="" >'. ($i + 1) .'</td>';
					
					$empCodeClass = $arrRecord['empCode'] == '' || isset($arrRecord['error']['empCode']) ? 'error' : '';
                    echo '<td class="'.$EmployeeIDClass.'" data-val="" >'. $arrRecord['empCode'] .' - '. $arrRecord['EmployeeName'] .'
					<input type="hidden" value="'.$arrRecord['empID'].'" name="empID['.$i.']" />
					<input type="hidden" value="'.$arrRecord['empCode'].'" name="empCode['.$i.']" />
					<input type="hidden" value="'.$arrRecord['empBranch'].'" name="empBranch['.$i.']" />
					<input type="hidden" value="'.$arrRecord['empCompany'].'" name="empCompany['.$i.']" />
					</td>';
					
					$amountError = $arrRecord['amount'] == '' ? 'error' : '';
					echo '<td class="'.$amountError.'">'. $arrRecord['amount'] .'<input type="hidden" value="'.$arrRecord['amount'].'" name="amount['.$i.']" /></td>';
					
					$preDefineFieldError = $arrRecord['is_pre_defined'] == '' ? 'error' : '';
					echo '<td class="'.$preDefineFieldError.'">'. $arrRecord['is_pre_defined'] .'<input type="hidden" value="'.$arrRecord['is_pre_defined'].'" name="is_pre_defined['.$i.']" /></td>';
					
					$headCodeError = $arrRecord['headCode'] == '' ? 'error' : '';
					echo '<td class="'.$headCodeError.'">'. $arrRecord['headCode'] .'<input type="hidden" value="'.$arrRecord['headID'].'" name="headID['.$i.']" /></td>';
					
					$empESINumberError = $arrRecord['empESINumber'] == '' ? 'error' : '';
					echo '<td class="'.$empESINumberError.'">'. $arrRecord['empESINumber'] .'<input type="hidden" value="'.$arrRecord['empESINumber'].'" name="empESINumber['.$i.']" /></td>';
					
					$PFNoError = $arrRecord['PFNo'] == '' ? 'error' : '';
					echo '<td class="'.$PFNoError.'">'. $arrRecord['PFNo'] .'<input type="hidden" value="'.$arrRecord['PFNo'].'" name="PFNo['.$i.']" /></td>';
					
					$monthE = $arrRecord['month'] == '' ? 'error' : '';
					echo '<td class="'.$monthE.'">'. $arrRecord['month'] .'<input type="hidden" value="'.$arrRecord['month'].'" name="month['.$i.']" /></td>';
					
					$yearE = $arrRecord['year'] == '' ? 'error' : '';
					echo '<td class="'.$yearE.'">'. $arrRecord['year'] .'<input type="hidden" value="'.$arrRecord['year'].'" name="year['.$i.']" /></td>';
					
					$dateE = $arrRecord['date'] == '' ? 'error' : '';
					echo '<td class="'.$dateE.'">'. date('M-Y',strtotime($arrRecord['date'])).'<input type="hidden" value="'.$arrRecord['date'].'" name="dateTbl['.$i.']" /></td>';
					
					$daysEr = $arrRecord['days'] == '' ? 'error' : '';
					echo '<td class="'.$daysEr.'">'. $arrRecord['days'] .'<input type="hidden" value="'.$arrRecord['days'].'" name="days['.$i.']" /></td>';

					
					echo '</tr>';
					$i++;
                }
            }
            ?>
            
            </tbody>
        </table>
        <input type="hidden" name="totalLength" value="<?php echo @$i; ?>" />
        <input type="hidden" name="fileID" value="<?php echo @$fileID; ?>" />
        <input type="hidden" id="date" name="date" value="<?php echo @$date; ?>" />
    </div>
</div>
<?php if(isset($errMsg) && trim($errMsg) != ''){ ?>
        <div class="msg_error"><?php echo @$errMsg; ?></div>
        <?php } ?>
<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">

$(document).ready(function() {

	<?php if(count($data)> 0): ?>
	var oTable1 =	$('#pagelist_center').dataTable( {
		"aoColumns": [null,null,null,null],
		"iDisplayLength": 100,
	});
	<?php endif; ?>
	
	
	var ti = 0;
	var tdataArr = [];
	$('#pagelist_center tbody tr').each(function(index, element) {
        var branch_id = $(element).find('td.branch_id input').val();
		var date_rep = $('#date').val();
		
		if($('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').length > 1){
			$('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').parents('tr').addClass('error');
		}
		console.log($('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]'));
		ti++;
    });
	//console.log(tdataArr);
});


function submitImport(){
	console.log($('td.error').length);
	if($('td.error').length > 0 || $('tr.error').length > 0) return false;
	<?php if(isset($checkDate) && count($checkDate) > 0) { ?>
	var conf = confirm('This month data already added! \n Are you sure to remove and upload new data?');
	<?php }else{ ?>
	var conf = true;
	<?php } ?>
	if(conf && confirm('Are you sure to import excel data?')){
		$('#frm_list_record').attr('action','index.php?c=salary_monthly_head&m=import_add_process');
		$('#frm_list_record').submit()
	}
}

</script>
