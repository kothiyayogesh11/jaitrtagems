<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_city', 'name' => 'frm_add_city');
echo form_open('c=employeetds&m=process', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Employee TDS</h1>
    <?php
		echo $strMessage;
	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
            
            <div class="control-group">
                <label class="control-label">Employee<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="EmpID" id="EmpID" >
                    	<?php echo $this->Page->generateComboByTable($this->tds->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$rsEdit->empID,"Select Employee"); ?>
                    </select>
                </div>
            </div>

		<div class="control-group">
                <label for="form-field-1" class="control-label">Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="tdsDate" name="tdsDate" class="required span6" value="<?php echo $rsEdit->tdsDate; ?>" />
                    <span id="date_error"></span>
                </div>
            </div>
               
            <div class="control-group">
                <label class="control-label">TDS Amount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="tdsAmount" name="tdsAmount" class="required span6" value="<?php echo $rsEdit->tdsAmount; ?>"/>
                </div>
            </div>
		    <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>
<script type="text/javascript">
$( document ).ready(function() {
	$("#tdsDate").datepicker({format: 'yyyy-mm-dd',todayBtn: true,autoclose: true});
	<?php if($strAction == 'E'):?>
		getStates(slt_country);
	<?php endif;?>
});

</script>