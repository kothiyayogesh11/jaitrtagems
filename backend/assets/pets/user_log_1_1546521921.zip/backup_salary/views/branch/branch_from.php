<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_user', 'name' => 'frm_add_user');
echo form_open('c=branch&m=process', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Branch</h1>
    <?php echo $strMessage; ?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        	 <div class="control-group">
                <label class="control-label">BranchName<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="BranchName" class="required span6" value="<?php echo $rsEdit->BranchName; ?>" />
                </div>
            </div>
            
             <div class="control-group">
                <label class="control-label">BranchCode<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="BranchCode" class="required span6" value="<?php echo $rsEdit->BranchCode; ?>" />
                    <span id="BranchCode_error"></span>
                </div>
            </div>
            
             <div class="control-group">
                <label class="control-label">BranchAPXName<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="BranchAPXName" class="required span6" value="<?php echo $rsEdit->BranchAPXName; ?>" />
                </div>
            </div>
        
        	<div class="control-group">
                <label class="control-label">BranchAPXID<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="BranchAPXID" class="required span6" value="<?php echo $rsEdit->BranchAPXID; ?>" />
                </div>
            </div>
          
        	 <div class="control-group">
                <label class="control-label">BranchAPXCode<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="BranchAPXCode" class="required span6" value="<?php echo $rsEdit->BranchAPXCode; ?>" />
                </div>
            </div>
            
            <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save"> 
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>

<script type="text/javascript">
var codeFlag = true;
$(document).on('blur','input[name="BranchCode"]',function(){
	var id = $('#hid_id').val();
	var obj = $(this);
	var code = jQuery.trim($(this).val());
	if(code != ''){
		$.ajax({
			type:"POST",
			url:"?c=branch&m=checkBranchCode",
			data:{'branch_id':id,'code':code},
			dataType:"json",
			success: function(res){
				if(typeof res.error != 'undefined' && res.error > 0 ){
					obj.addClass('border-red');
					codeFlag = false;
				}else{
					obj.removeClass('border-red');
					codeFlag = true;
				}
			}
		});
	}
});

$(document).on('click','input[type="submit"]',function(e){
	var err_flag = true;
	$(this).parents('form').find('.required').each(function(index, element) {
        if($(element).val() == ''){
			err_flag = false;
			$(element).addClass('border-red');
		}else{
			if(element.name == 'BranchCode' && !codeFlag){
				err_flag = false;
				$(element).addClass('border-red');
			}else{
				$(element).removeClass('border-red');
			}
			
		}
    });
	return err_flag && codeFlag;
});
</script>
