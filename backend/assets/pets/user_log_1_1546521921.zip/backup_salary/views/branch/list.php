<?php if($blnAjax != 1): ?>
<?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=branch&m=event_add', $attributes); 
?>

<div class="page-header position-relative">
    <h1>Branch List</h1>
    <?php echo $this->Page->getMessage(); ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return openAddPage();"> <i class="icon-plus-sign bigger-125"></i> Add </button>
        <button type="button" class="btn btn-small btn-danger" onclick="return DeleteRow();" name="btnDelete" id="btnDelete"> <i class="icon-trash bigger-125"></i> Delete </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
    	<div id="tableColToggle"></div>
        <table width="100%" cellpadding="8" cellspacing="8" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
                <tr class="hdr">
                    <th width="20">
                    	<input type="checkbox" name="chkAll_list1" id="chkAll_list1" onchange="checkAll('list1');" />
                        <span class="lbl"></span>
                    </th>
                    <th></th>
                    <th>BranchName</th>
                    <th>BranchCode</th>
                    <th>BranchAPXName</th>
                    <th>BranchAPXID</th>
                    <th>BranchAPXCode</th>
                    <th>isActive</th>
                </tr>
            </thead>
            <tbody>
                <?php
				if(count($rsList)==0){
                    echo "<tr>";
                    echo '<td colspan="12" style="text-align:center;">No data found.</td>';
                    echo "</tr>";
                } else {
                    foreach($rsList as $arrRecord) {
                        $strEditLink	=	"index.php?c=branch&m=addBranch&action=E&id=".$arrRecord['id'];
                        echo '<tr data-val="'.$arrRecord['id'].'">';
						echo '<td><input type="checkbox" name="chk_lst_list1[]" id="chk_lst_'.$arrRecord['id'].'" value="'.$arrRecord['id'].'" /><span class="lbl"></span></td>';
                        echo '<td width="20" class="action-buttons" nowrap="nowrap">';
						echo '<a href="'.$strEditLink.'" class="green" title="Edit"><i class="icon-pencil bigger-130"></i></a></td>';
						echo '<td>'. $arrRecord['BranchName'] .'</td>';
						echo '<td>'. $arrRecord['BranchCode'] .'</td>';
						echo '<td>'. $arrRecord['BranchAPXName'] .'</td>';
						echo '<td>'. $arrRecord['BranchAPXID'] .'</td>';
						echo '<td>'. $arrRecord['BranchAPXCode'] .'</td>';
						
						if($arrRecord['delete_flag'] == 0){
							$isActiveClass = "btn-success";
							$isActiveVal = "Active";
							$isActiveTitle = "Click to In-Active";
						}else{
							$isActiveClass = "btn-danger";
							$isActiveVal = "In-Active";
							$isActiveTitle = "Click to Active";
						} 
						echo '<td><button type="button" title="'.$isActiveTitle.'" class="btn btn-small '.$isActiveClass.' isActive">'.$isActiveVal.'</button></td>';
						echo '</tr>';
                    }
				}
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php if($blnAjax != 1): ?>
<?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">
var oTable1;
$(document).ready(function() {

<?php if(count($rsList)> 0): ?>
oTable1 = $('#pagelist_center').dataTable( {
	"aoColumns": [{"bSortable": false}, {"bSortable": false},null, null, null, null, null, null],
	"iDisplayLength": 25,
});

if(oTable1){
	var len = oTable1.fnSettings().aoColumns;
	var colStr = '<b>Select TO show / hide columns : &nbsp;</b>';
	for(i = 0; i < len.length; i++){
		var colTitle = $.trim(oTable1.fnSettings().aoColumns[i].sTitle.replace(/(<([^>]+)>)/ig,""));
		if(colTitle != '')
		colStr += '<span><a href="javascript:void(0);" onclick="fnShowHide('+i+');">'+colTitle+',</a> &nbsp;</span>';
	}
	$('#tableColToggle').html(colStr);
}
<?php endif; ?>

});	

$(document).on('click','.isActive',function(){
	var $obj = $(this);
	var branch_id = $obj.parents('tr').attr('data-val');
	if(branch_id == ''){
		alert('Something went wrong!');
		return false;
	}
	$.ajax({
		type:"POST",
		url:"?c=branch&m=branch_status",
		data:{'branch_id':branch_id},
		dataType:"json",
		success: function(res){
			if(typeof res.error != 'undefined' && res.error == 1){
				alert(res.msg);
			}else if(typeof res.error != 'undefined' && res.error == 0){
				if(typeof res.data != 'undefined'){
					if(res.data.delete_flag == 0){
						$obj.addClass('btn-success');
						$obj.removeClass('btn-danger');
						$obj.attr('title','Click to In-Active');
						$obj.text('Active');
					}else{
						$obj.text('In-Active');
						$obj.attr('title','Click to Active');
						$obj.removeClass('btn-success');
						$obj.addClass('btn-danger');
					}
				}
			}
		}
	});
});

function openAddPage(){
    window.location.href = 'index.php?c=branch&m=addBranch&action=A';
}

function DeleteRow(){
	var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
	if(intChecked == 0){
		alert("No User selected.");
		return false;
	}else{
		var responce = confirm("Do you want to delete selected record(s)?");
		if(responce==true){
			$('#frm_list_record').attr('action','index.php?c=employee&m=delete');
			$('#frm_list_record').submit()	
		}
	}
}
</script>
