<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=monthlysalse&m=import_add_process', $attributes);
?>
<style>
td.error{ background-color: #ff00001f !important;}
tr.error{ background: #ff000038 !important;}
</style>
<div class="page-header position-relative">
    <h1>Branch wise Monthly GP</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return submitImport();"> <i class="icon-plus-sign bigger-125"></i> Submit </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
        <table width="100%" cellpadding="3" cellspacing="3" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
            <tr class="hdr">
                <th>No.</th>
                <th>Branch</th>
                <th>Date</th>
                <th>GpAmount</th>
                <th>NetProfit</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(count($data)==0){
			 	echo "<tr>";
                echo '<td colspan="3" style="text-align:center;">No data found.</td>';
	            echo "</tr>";
            }else{
				$i = 0;
                foreach($data as $arrRecord){
					$trError = isset($arrRecord['error']['recExit']) ? 'error' : '';
                    echo '<tr class="'.$trError.'">';
					
					 echo '<td class="" >'. ($i + 1) .'</td>';
					
					$BrancErrorClass = $arrRecord['BranchID'] == '' || isset($arrRecord['error']['BranchID']) ? 'error' : '';
                    echo '<td class="'.$BrancErrorClass.' branch_id" data-val="'.$arrRecord['BranchID'].'|'.$arrRecord['Date'].'" >'. $arrRecord['BranchName'] .'<input type="hidden" value="'.$arrRecord['BranchID'].'" name="BranchID['.$i.']" /></td>';
					
					$DateError = $arrRecord['Date'] == '' || isset($arrRecord['error']['Date']) ? 'error' : '';
					echo '<td class="'.$DateError.' date_rep"  data-val="'.$arrRecord['BranchID'].'">'. date('M-Y',strtotime($arrRecord['Date'])).'<input type="hidden" value="'.$arrRecord['Date'].'" name="Date['.$i.']" /></td>';
					
					$SalesAmountError = $arrRecord['GpAmount'] == '' ? 'error' : '';
					echo '<td class="'.$SalesAmountError.'">'. $arrRecord['GpAmount'] .'<input type="hidden" value="'.$arrRecord['GpAmount'].'" name="GpAmount['.$i.']" /></td>';
					
					$NetProfitError = $arrRecord['NetProfit'] == '' ? 'error' : '';
					echo '<td class="'.$NetProfitError.'">'. $arrRecord['NetProfit'] .'<input type="hidden" value="'.$arrRecord['NetProfit'].'" name="NetProfit['.$i.']" /></td>';
					
					echo '</tr>';
					$i++;
                }
            }
            ?>
            
            </tbody>
        </table>
        <input type="hidden" name="totalLength" value="<?php echo @$i; ?>" />
        <input type="hidden" name="fileID" value="<?php echo @$fileID; ?>" />
        <input type="hidden" name="date" value="<?php echo @$date; ?>" />
    </div>
</div>
<?php if(isset($errMsg) && trim($errMsg) != ''){ ?>
        <div class="msg_error"><?php echo @$errMsg; ?></div>
        <?php } ?>
<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">

$(document).ready(function() {

	<?php if(count($data)> 0): ?>
	var oTable1 =	$('#pagelist_center').dataTable( {
		"aoColumns": [null,null,null,null,null],
		"iDisplayLength": 100,
	});
	<?php endif; ?>
	
	
	var ti = 0;
	var tdataArr = [];
	$('#pagelist_center tbody tr').each(function(index, element) {
        var branch_id = $(element).find('td.branch_id').text();
		var date_rep = $(element).find('td.date_rep').text();
		
		if($('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').length > 1){
			$('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').parents('tr').addClass('error');
		}
		console.log($('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]'));
		ti++;
    });
	//console.log(tdataArr);
});

function openAddPage(){
	window.location.href = 'index.php?c=monthlysales&m=Addsales&action=A';
}

function DeleteRow(){
	var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
	if(intChecked == 0){
		alert("No Designation selected.");
		return false;
	}else{
		var responce = confirm("Do you want to delete selected record(s)?");
		if(responce==true){
			$('#frm_list_record').attr('action','index.php?c=monthlysales&m=delete');
			$('#frm_list_record').submit()
		}
	}
}

function submitImport(){
	console.log($('td.error').length);
	if($('td.error').length > 0) return false;
	<?php if(isset($checkDate) && count($checkDate)) { ?>
	var conf = confirm('This month data already added! \n Are you sure to remove and upload new data?');
	<?php }else{ ?>
	var conf = true;
	<?php } ?>
	if(conf && confirm('Are you sure to import excel data?')){
		$('#frm_list_record').attr('action','index.php?c=monthlygp&m=import_add_process');
		$('#frm_list_record').submit()
	}
}

</script>
