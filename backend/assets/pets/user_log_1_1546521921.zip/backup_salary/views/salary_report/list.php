<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>

<div class="page-header position-relative">
    <h1>Salary List</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>

<?php
$attributes = array('id' => 'frm_search_salary', 'class'=>'frm_search_salary form-horizontal', 'name'=>'frm_search_salary');
echo form_open_multipart('c=SalaryReport', $attributes);
?>

<!--<div class="row-fluid">
    <div class="span10">
        <fieldset>
            <div class="control-group">
                <label for="form-field-1" class="control-label">Date<span class="red">*</span></label>
                <div class="controls">
                <?php //$Sdate = isset($search_date) && $search_date != '' ? $search_date : $this->input->get('search_date'); ?>
                    <input type="text" id="search_date" name="search_date" class="required span6" value="<?php //echo $Sdate; ?>" />
                    <input type="submit" class="btn btn-primary btn-small" value="Search" onclick="return submit_form(this.form);">
                </div>
            </div>
        </fieldset>
    </div>
</div>-->


<div class="row-fluid">

    <div class="span12">
    <input type="text" id="search_date" name="search_date" placeholder="Date" value="<?php echo $this->input->get('search_date');?>" style="width:8%; height:22px;">
       <select id="selEmp" name="selEmp" style="height: 32px; width:15%; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->salary_report_model->tbl_employee_masater,"id","EmpFullName","","where delete_flag = 0",$this->input->get('selEmp'),"Select Employee"); 
		?>
        </select>
         <select id="selDeg" name="selDeg" style="height: 32px; width:15%; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->salary_report_model->tbl_designation,"id","name","","where delete_flag = 0",$this->input->get('selDeg'),"Select Designation"); 
		?>
        </select>
        <select id="selBrch" name="selBrch" style="height: 32px; width:15%; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->salary_report_model->tbl_branch_master,"id","BranchName","","where delete_flag = 0",$this->input->get('selBrch'),"Select Branch"); 
		?>
        </select>
        <select id="selComp" name="selComp" style="height: 32px; width:15%; margin:0;">
        <?php 
		echo $this->Page->generateComboByTable($this->salary_report_model->tbl_companymaster,"id","Name","","where delete_flag = 0",$this->input->get('selComp'),"Select Company"); 
		?>
        </select>
        <button type="button" class="btn btn-small btn-success filter_btn" id="filter"> <i class="icon-filter bigger-125"></i> Filter </button>
        <button type="button" class="btn btn-small btn-danger" id="clrfilter"> <i class="icon-filter bigger-125"></i> Clear </button>
        <button type="button" class="btn btn-small btn-success filter_btn" data-val="excel"> <i class="icon-filter bigger-125"></i> Get Excel</button>
    </div>
</div>

<br />
<?php echo form_close(); $HeadTotalArr = Array();?>

<br />
<div class="row-fluid">
    <div class="span12">
        <div id="tableColToggle"></div>
        <table width="100%" cellpadding="5" cellspacing="5" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
                <tr class="hdr">
                    <th>Emp Code</th>
                    <th>Employee Name</th>
                    <th>Designation</th>
                    <th>Branch</th>
                    <th>Companay</th>
                    <th>Days</th>
                    <th>LWP</th>

                    <?php if(count($salaryHeadArr) > 0): ?>
                        <?php foreach ($salaryHeadArr AS $code=>$name): ?>
                            <th><?php echo $name; $HeadTotalArr[$code]=0;?></th>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if(count($empArr)==0): ?>
                 <tr>
                    <td colspan="26" style="text-align:center;">No data found.</td>
                 </tr>
                 <?php else: ?>

                     <?php foreach($empArr as $data): ?>
                        <tr>
                            <td><?php echo $data['EmpCode']; ?></td>
                            <td><?php echo $data['EmpFullName']; ?></td>
                            <td><?php echo $designationArr[$data['DesignationId']]; ?></td>
                            <td><?php echo $data['Branch']; ?></td>
                            <td><?php echo $data['Company']; ?></td>
                            <td><?php echo $data['days']; ?></td>
                            <td><?php echo $data['LWP']>0?$data['LWP']:0; ?></td>

                            <?php if(count($salaryHeadArr) > 0): ?>
                                <?php foreach ($salaryHeadArr AS $code=>$name): ?>
                                    <td><?php $HeadVal = round($empSalaryArr[$data['EmpId']][$code]);$HeadTotalArr[$code] += $HeadVal; echo $HeadVal;?></td>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>

                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <!--<th colspan="7" style="text-align:right;"> TOTAL </th>-->
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th style="text-align:right;"> TOTAL </th>
                    <?php if(count($salaryHeadArr) > 0): ?>
                            <?php foreach ($salaryHeadArr AS $code=>$name): ?>
                                <th><?php echo $HeadTotalArr[$code];?></th>
                            <?php endforeach; ?>
                        <?php endif; ?>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php echo form_close(); ?>
<?php if($blnAjax != 1): ?>
<div class="modal fade" id="exportModel" tabindex="-1" style="display:none;" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <?php 
    $attributes = array('id' => 'file_import', 'name'=>'file_import');
    echo form_open_multipart('c=salary&m=import', $attributes);
    ?>
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="exampleModalLongTitle">Import Salary Data</h5></div>
            <div class="modal-body">
                <div class="col-sm-12">
                    
                    <div class="row-fluid" id="printFrmDiv">
                        <div class="span10">
                            <fieldset>
                                <div class="control-group">
                                    <label for="form-field-1 span6" class="control-label">File <span class="red">*</span></label>
                                    <div class="controls">
                                        <input type="file" id="import" name="import" class="required span6">
                                    </div>
                                </div>
                    
                                <div class="control-group">
                                    <label for="form-field-1 span6" class="control-label">Start Date <span class="red">*</span></label>
                                    <div class="controls">
                                           <input type="text" id="startDate" name="startDate" class="required span6" value="">
                                    </div>
                                </div>                                
                                
                            </fieldset>
                        </div>
                    </div>

                                   
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="form-import-submit" class="btn btn-primary">Upload</button>
            </div>
        </div>
    </div>
    <?php
    echo form_close();
    ?> 
</div>
    <?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">
//var oTable1;
$(document).on('click','.filter_btn',function(){
	window.location.href = "?c=salaryReport&m=index&selEmp="+$('#selEmp').val()+"&selDeg="+$('#selDeg').val()+"&selBrch="+$('#selBrch').val()+"&selComp="+$('#selComp').val()+"&search_date="+$('#search_date').val()+"&export="+$(this).attr('data-val');
});

$(document).on('click','#clrfilter',function(){
	window.location.href = "?c=salaryReport";
});


$(document).ready(function(e) {
    <?php if(count($empArr)> 0): ?>
    oTable1 =$('#pagelist_center').dataTable({
        "iDisplayLength": 25
    });
    if(oTable1){
        var len = oTable1.fnSettings().aoColumns;
        var colStr = '<b>Select TO show / hide columns : &nbsp;</b>';
        for(i = 0; i < len.length; i++){
            var colTitle = $.trim(oTable1.fnSettings().aoColumns[i].sTitle.replace(/(<([^>]+)>)/ig,""));
            if(colTitle != '')
            colStr += '<span><a href="javascript:void(0);" onclick="fnShowHide('+i+');">'+colTitle+',</a> &nbsp;</span>';
        }
        $('#tableColToggle').html(colStr);
    }
    
    <?php endif; ?>
    $('#search_date').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
    });
});
</script>
