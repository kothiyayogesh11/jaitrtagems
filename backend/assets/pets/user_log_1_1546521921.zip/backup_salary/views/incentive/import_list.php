<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/top.php'); ?>
<?php endif; 
?>
<style>
td.error{border: 1px solid red; background-color: #ff00001f !important;}
tr.error{border: 1px solid red !important; background: #ff000038 !important;}
</style>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=incentive&m=import_add_process', $attributes);

?>

<input type="hidden" name="fileID" value="<?php echo @$fileID; ?>" />
<input type="hidden" name="date" value="<?php echo @$date; ?>" />
<div class="page-header position-relative">
    <h1>Import Data</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return submitImport();"> <i class="icon-plus-sign bigger-125"></i> Submit </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
        <table width="100%" cellpadding="5" cellspacing="5" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
            <tr class="hdr">
                <th>Branch</th>
                <th>Employee Name</th>
                <th>Date</th>
                <th>Scheme</th>
                <th>Qty</th>
                <th>Benefit Amt.</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(count($data)==0){
			 	echo "<tr>";
                echo '<td colspan="5" style="text-align:center;">No data found.</td>';
	            echo "</tr>";
            }else{
				$i = 0;
				$er = 0;
                foreach($data as $arrRecord){
					$trError = isset($arrRecord['error']['recExit']) ? 'error' : '';
                    echo '<tr class="'.$trError.'">';
					
					$BrancErrorClass = $arrRecord['BranchID'] == '' || isset($arrRecord['error']['BranchID']) ? 'error '.$er++ : '';
                    echo '<td class="'.$BrancErrorClass.'">'. $arrRecord['BranchName'] .'</td>';
					
					
					
					//$empErrorClass = $arrRecord['empID'] == '' || isset($arrRecord['error']['empID']) ? 'error' : '';
					
					$empErrorClass = $arrRecord['empID'] == '' || isset($arrRecord['error']['empID']) ? ' error '.$er++ : '';
                    $title = $arrRecord['empID'] == '' || isset($arrRecord['error']['empID']) ? $arrRecord['errMsg'] : '';
                    echo '<td class="'.$empErrorClass.'" title = "'.$title.'">'. $arrRecord['EmpName'] .'</td>';
					
					$DateError = $date == '' ? 'error '.$er++ : '';
					echo '<td class="'.$DateError.'">'. date('M-Y',strtotime($date)).'</td>';
					
					$schemeError = $arrRecord['scheme'] == '' ? 'error '.$er++ : '';
					echo '<td class="'.$schemeError.'">'.$arrRecord['scheme'].'</td>';
					
					$qtyError = $arrRecord['qty'] == '' ? ' error '.$er++ : '';
					echo '<td class="'.$qtyError.'">'. $arrRecord['qty'] .'</td>';
					
					$benefit_amtError = $arrRecord['benefit_amt'] == '' ? 'error '.$er++ : '';
					echo '<td class="'.$benefit_amtError.'">'.$arrRecord['benefit_amt'].'</td>';
					
					echo '</tr>';
					$i++;
                }
            }
            ?>
            </tbody>
        </table>
        
    </div>
</div>
<input type="hidden" name="totalLength" value="<?php echo @$i; ?>" />
<input type="hidden" name="errorLength" value="<?php echo @$er; ?>" />
<?php if(isset($errMsg) && trim($errMsg) != ''){ ?>
        <div class="msg_error"><?php echo @$errMsg; ?></div>
<?php } ?>
<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">

$(document).ready(function() {
	<?php if(count($data)> 0): ?>
	var oTable1 =	$('#pagelist_center').dataTable( {
		"aoColumns": [null,null,null,null,null,null],
		"iDisplayLength": 100,
	});
	<?php endif; ?>
	
	$('#startDate').datepicker({autoclose: true,format: 'yyyy-mm-dd'});
	
	var ti = 0;
	var tdataArr = [];
	$('#pagelist_center tbody tr').each(function(index, element) {
        var branch_id = $(element).find('td.branch_id').text();
		var date_rep = $(element).find('td.date_rep').text();
		if($('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').length > 1){
			$('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').parents('tr').addClass('error');
		}
		ti++;
    });
});

function submitImport(){
	//if($('td.error').length > 0 || parseInt($('input[name="errorLength"]').val()) > 0) return false;
	
	<?php if(isset($checkDate) && count($checkDate)) { ?>
	var conf = confirm('This month data already added! \n Are you sure to remove and upload new data?');
	<?php }else{ ?>
	var conf = true;
	<?php } ?>
	if(conf && confirm('Are you sure to import file data?')){
		$('#frm_list_record').attr('action','index.php?c=incentive&m=import_add_process');
		$('#frm_list_record').submit()
	}
}
</script>