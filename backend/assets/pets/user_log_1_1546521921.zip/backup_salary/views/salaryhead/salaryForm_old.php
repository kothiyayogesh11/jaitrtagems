<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_city', 'name' => 'frm_add_city');
echo form_open('c=salaryhead&m=savesalaryhead', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Salary Head Master</h1>
    <?php
		echo $strMessage;
	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        
        <div class="control-group">
                <label for="form-field-1" class="control-label">Code<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" <?php echo isset($rsEdit->is_lock) && $rsEdit->is_lock == 1 ? 'disabled="disabled"' : ''; ?> id="code" name="code" class="required span6" value="<?php echo $rsEdit->code; ?>" onblur="checkLocationCode(this)" />&nbsp; <span id="code_error"></span>
                </div>
            </div>
        
        	<div class="control-group">
                <label for="form-field-1" class="control-label">Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="name" name="name" class="required span6" value="<?php echo $rsEdit->name; ?>" />
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Type<span class="red">*</span></label>
                <div class="controls">
                	<select class="required span6" name="type" id="type" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='SALARYHEAD' order by seq",$rsEdit->type,""); ?>
                    </select>
                </div>
            </div>

			
            <div class="control-group">
                <label class="control-label">Min Allowed Amount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="min_allowed_amount" name="min_allowed_amount" class="required span6 isnumber" value="<?php echo $rsEdit->min_allowed_amount; ?>" />
                </div>
            </div>
            
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Max Allowed Amount<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="max_allowed_amount" name="max_allowed_amount" class="required span6 isnumber" value="<?php echo $rsEdit->max_allowed_amount; ?>" />
                </div>
            </div>

            <div class="control-group">
                <label for="form-field-1" class="control-label">Is Pre Defined ?<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="is_pre_defined" id="is_pre_defined" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='IS_PRE_DEFINED' order by seq",$rsEdit->is_pre_defined,""); ?>
                    </select>
                </div>
            </div>

            <div class="control-group">
                <label for="form-field-1" class="control-label">Is Calculated Field ?<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="is_calc" id="is_calc" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='IS_CALC' order by seq",$rsEdit->is_calc,""); ?>
                    </select>
                </div>
            </div>
			
            <div class="control-group">
                <label class="control-label">Head Index<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="headIndex" name="headIndex" class="required span6" value="<?php echo $rsEdit->headIndex; ?>" />
                </div>
            </div>
            
            
            <div class="control-group non-printable">
                <div class="controls">
                        <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>
<script type="text/javascript">
    function getStates(obj) {
        var fieldVal = $('#'+obj.id).val();
        $.ajax({
			cache: false,
            type:"POST",
            url:"index.php?c=city&m=getStates",
            data:"fieldVal="+fieldVal+"&state_id="+<?php echo isset($rsEdit->state_id) ? $rsEdit->state_id : 'null';?>,
            success:function(res){
                if (res){
                    $('#slt_state').empty();
                    $('#slt_state').append(res);
                }

            }
        });
    }
    $( document ).ready(function() {
        <?php if($strAction == 'E'):?>
            getStates(slt_country);
        <?php endif;?>
    });
    
    function checkLocationCode(obj) {
	    var field = obj.id;
         var fieldVal = $('#'+obj.id).val();
         $.ajax({
            type:"POST",
            url:"index.php?c=salaryhead&m=checkLocationCode",
            data:"field="+field+"&fieldVal="+fieldVal+"&id="+<?php echo $id ? $id : 'null'; ?>,
            beforeSend:function(){
            },
            success:function(res){
                if (res == 'codeExists'){
                    $('#'+obj.id+'_error')
                        .css('color', 'red')
                        .html("Code is already Exists.");
                    $('#'+obj.id).addClass('border-red');
                    $('#'+obj.id).focus();
                }
                else{
                    $('#'+obj.id+'_error').empty();
                    $('#'+obj.id).removeClass('border-red');
                }
            }
        });
    }
    
</script>
