<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>
<?php
$attributes = array('id' => 'frm_list_record', 'name'=>'frm_list_record');
echo form_open_multipart('c=monthlysalse&m=import_add_process', $attributes);
?>
<style>
td.error{ background-color: #ff00001f !important;}
tr.error{ background: #ff000038 !important;}
</style>
<div class="page-header position-relative">
    <h1>Salary Import</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return submitImport();"> <i class="icon-plus-sign bigger-125"></i> Submit </button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
        <table width="100%" cellpadding="3" cellspacing="3" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
            <tr class="hdr">
                <th>EmpCode</th>
                <th>BasicSalary</th>
                <th>TotalSalary</th>
                <th>HRA</th>
                <th>ConveyenceAllowence</th>
                <th>StandardAllowence</th>
                <th>SpecialAllowence</th>
                <th>CommitmentSalary</th>
                <th>StartDate</th>
                <th>isFix</th>
                <th>TDS</th>
                <th>PF</th>
                <th>ESI</th>
                <th>SPLALL</th>
                <th>INC</th>
                <th>Trans</th>
                <th>PTAX</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(count($list)==0){
			 	echo "<tr>";
                echo '<td colspan="3" style="text-align:center;">No data found.</td>';
	            echo "</tr>";
            }else{
				$i = 0;
                foreach($list as $arrRecord){
					$trError = isset($arrRecord['error']['recExit']) ? 'error' : '';
                    echo '<tr class="'.$trError.'">';
					
					$EmpCodeErrorClass = $arrRecord['EmpCode'] == '' || isset($arrRecord['error']['EmpCode']) ? 'error' : '';
                    echo '<td class="'.$EmpCodeErrorClass.' EmpCode" data-val="'.$arrRecord['EmpCode'].'|'.$arrRecord['StartDate'].'" >'. $arrRecord['EmpCode'] .'<input type="hidden" value="'.$arrRecord['empID'].'" name="empID['.$i.']" /></td>';

					echo '<input type="hidden" value="'.$arrRecord['branchID'].'" name="branchID['.$i.']" />';
					echo '<input type="hidden" value="'.$arrRecord['compID'].'" name="compID['.$i.']" />';
					
					$BasicSalaryError = $arrRecord['BasicSalary'] == '' || isset($arrRecord['error']['BasicSalary']) ? 'error' : '';
					echo '<td class="'.$BasicSalaryError.'"  data-val="'.$arrRecord['BasicSalary'].'">'. $arrRecord['BasicSalary'].'<input type="hidden" value="'.$arrRecord['BasicSalary'].'" name="BasicSalary['.$i.']" /></td>';
					
					$TotalSalaryError = $arrRecord['TotalSalary'] == '' || isset($arrRecord['error']['TotalSalary']) ? 'error' : '';
					echo '<td class="'.$TotalSalaryError.' "  data-val="'.$arrRecord['TotalSalary'].'">'. $arrRecord['TotalSalary'].'<input type="hidden" value="'.$arrRecord['TotalSalary'].'" name="TotalSalary['.$i.']" /></td>';
					
					$HRAError = $arrRecord['HRA'] == '' || isset($arrRecord['error']['HRA']) ? 'error' : '';
					echo '<td class="'.$HRAError.' "  data-val="'.$arrRecord['HRA'].'">'. $arrRecord['HRA'].'<input type="hidden" value="'.$arrRecord['HRA'].'" name="HRA['.$i.']" /></td>';
					
					$ConveyenceAllowenceError = $arrRecord['ConveyenceAllowence'] == '' || isset($arrRecord['error']['ConveyenceAllowence']) ? 'error' : '';
					echo '<td class="'.$BasicSalaryError.'"  data-val="'.$arrRecord['ConveyenceAllowence'].'">'. $arrRecord['ConveyenceAllowence'].'<input type="hidden" value="'.$arrRecord['ConveyenceAllowence'].'" name="ConveyenceAllowence['.$i.']" /></td>';
					
					$StandardAllowenceError = $arrRecord['StandardAllowence'] == '' || isset($arrRecord['error']['StandardAllowence']) ? 'error' : '';
					echo '<td class="'.$StandardAllowenceError.' "  data-val="'.$arrRecord['BasicSalary'].'">'. $arrRecord['StandardAllowence'].'<input type="hidden" value="'.$arrRecord['StandardAllowence'].'" name="StandardAllowence['.$i.']" /></td>';
					
					$SpecialAllowenceError = $arrRecord['SpecialAllowence'] == '' || isset($arrRecord['error']['SpecialAllowence']) ? 'error' : '';
					echo '<td class="'.$SpecialAllowenceError.' "  data-val="'.$arrRecord['SpecialAllowence'].'">'. $arrRecord['SpecialAllowence'].'<input type="hidden" value="'.$arrRecord['SpecialAllowence'].'" name="SpecialAllowence['.$i.']" /></td>';
					
					$CommitmentSalaryError = $arrRecord['CommitmentSalary'] == '' || isset($arrRecord['error']['CommitmentSalary']) ? 'error' : '';
					echo '<td class="'.$CommitmentSalaryError.' "  data-val="'.$arrRecord['CommitmentSalary'].'">'. $arrRecord['CommitmentSalary'].'<input type="hidden" value="'.$arrRecord['CommitmentSalary'].'" name="CommitmentSalary['.$i.']" /></td>';
					
					$StartDateError = strtotime($arrRecord['StartDate']) == 0 || isset($arrRecord['error']['StartDate']) ? 'error' : '';
					echo '<td class="'.$StartDateError.'"  data-val="'.$arrRecord['StartDate'].'">'. $arrRecord['StartDate'].'<input type="hidden" value="'.$arrRecord['StartDate'].'" name="StartDate['.$i.']" /></td>';
					
					$isFixError = $arrRecord['isFix'] == '' || isset($arrRecord['error']['isFix']) ? 'error' : '';
					echo '<td class="'.$isFixError.'"  data-val="'.$arrRecord['isFix'].'">'. $arrRecord['isFix'].'<input type="hidden" value="'.$arrRecord['isFix'].'" name="isFix['.$i.']" /></td>';
					
					$TDSError = $arrRecord['TDS'] == '' || isset($arrRecord['error']['TDS']) ? 'error' : '';
					echo '<td class="'.$TDSError.'"  data-val="'.$arrRecord['TDS'].'">'. $arrRecord['TDS'].'<input type="hidden" value="'.$arrRecord['TDS'].'" name="TDS['.$i.']" /></td>';
					
					$PFError = $arrRecord['PF'] == '' || isset($arrRecord['error']['PF']) ? 'error' : '';
					echo '<td class="'.$PFError.'"  data-val="'.$arrRecord['PF'].'">'. $arrRecord['PF'].'<input type="hidden" value="'.$arrRecord['PF'].'" name="PF['.$i.']" /></td>';
					
					$ESIError = $arrRecord['ESI'] == '' || isset($arrRecord['error']['ESI']) ? 'error' : '';
					echo '<td class="'.$ESIError.'"  data-val="'.$arrRecord['ESI'].'">'. $arrRecord['ESI'].'<input type="hidden" value="'.$arrRecord['ESI'].'" name="ESI['.$i.']" /></td>';
					
					$SPLALLError = $arrRecord['SPLALL'] == '' ? 'error' : '';
					echo '<td class="'.$SPLALLError.'">'. $arrRecord['SPLALL'] .'<input type="hidden" value="'.$arrRecord['SPLALL'].'" name="SPLALL['.$i.']" /></td>';
					$INCError = $arrRecord['INC'] == '' || isset($arrRecord['error']['INC']) ? 'error' : '';
					echo '<td class="'.$INCError.'">'. $arrRecord['INC'].'<input type="hidden" value="'.$arrRecord['INC'].'" name="INC['.$i.']" /></td>';
					
					$TransError = $arrRecord['Trans'] == '' || isset($arrRecord['error']['Trans']) ? 'error' : '';
					echo '<td class="'.$TransError.'">'. $arrRecord['Trans'].'<input type="hidden" value="'.$arrRecord['Trans'].'" name="Trans['.$i.']" /></td>';
					
					$PTAXError = $arrRecord['PTAX'] == '' || isset($arrRecord['error']['PTAX']) ? 'error' : '';
					echo '<td class="'.$PTAXError.'">'. $arrRecord['PTAX'].'<input type="hidden" value="'.$arrRecord['PTAX'].'" name="PTAX['.$i.']" /></td>';
					
					echo '</tr>';
					$i++;
                }
            }
            ?>
            
            </tbody>
        </table>
        
        
    </div>
</div>
<input type="hidden" name="totalLength" value="<?php echo @$i; ?>" />
<input type="hidden" name="fileID" value="<?php echo @$fileID; ?>" />
<?php if(isset($errMsg) && trim($errMsg) != ''){ ?>
        <div class="msg_error"><?php echo @$errMsg; ?></div>
        <?php } ?>
<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">

$(document).ready(function() {

	<?php if(count($list)> 0): ?>
	var oTable1 =	$('#pagelist_center').dataTable( {
		"aoColumns": [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],
		"iDisplayLength": 100,
	});
	<?php endif; ?>
	var ti = 0;
	var tdataArr = [];
	$('#pagelist_center tbody tr').each(function(index, element) {
        var branch_id = $(element).find('td.empCode').text();
		var date_rep = $(element).find('td.startDate').text();
		
		if($('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').length > 1){
			$('tbody').find('td[data-val="'+branch_id+'|'+date_rep+'"]').parents('tr').addClass('error');
		}
		ti++;
    });
	//console.log(tdataArr);
});

function openAddPage(){
	window.location.href = 'index.php?c=monthlysales&m=Addsales&action=A';
}

function DeleteRow(){
	var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
	if(intChecked == 0){
		alert("No Designation selected.");
		return false;
	}else{
		var responce = confirm("Do you want to delete selected record(s)?");
		if(responce==true){
			$('#frm_list_record').attr('action','index.php?c=monthlysales&m=delete');
			$('#frm_list_record').submit()
		}
	}
}

function submitImport(){
	if($('td.error').length > 0 || $('tr.error').length > 0) return false;
	if(confirm('Are you sure to import excel data?')){
		$('#frm_list_record').attr('action','index.php?c=salary&m=import_add_process');
		$('#frm_list_record').submit()
	}
}

</script>
