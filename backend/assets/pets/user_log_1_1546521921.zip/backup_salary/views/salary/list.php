<?php if($blnAjax != 1): ?>
    <?php include(APPPATH.'views/top.php'); ?>
<?php endif; ?>

<?php
$attributes = array('id' => 'frm_list_record', 'class'=>'frm_add_record form-horizontal', 'name'=>'frm_list_record');
echo form_open_multipart('c=worklocation&m=addworklocation', $attributes);
?>

<div class="page-header position-relative">
    <h1>Salary List</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span6 text-left">
        <button type="button" class="btn btn-small btn-success" onclick="return openAddPage();"> <i class="icon-plus-sign bigger-125"></i> Add </button>
        <button type="button" class="btn btn-small btn-danger" onclick="return DeleteRow();" name="btnDelete" id="btnDelete"> <i class="icon-trash bigger-125"></i> Delete </button>
        <button type="button" class="btn btn-small btn-primary" id="importBtn"> <i class="icon-upload bigger-125"></i> Import</button>
        <button type="button" class="btn btn-small btn-primary" id="downloadFormat"> <i class="icon-download bigger-125"></i> Download Format</button>
    </div>
</div>

<br />
<div class="row-fluid">
    <div class="span12">
    	<div id="tableColToggle"></div>
        <table width="100%" cellpadding="5" cellspacing="5" border="0" class="table table-striped table-bordered table-hover dataTable" id="pagelist_center">
            <thead>
            <tr class="hdr">
                <th width="20">
                    <input type="checkbox" name="chkAll_list1" id="chkAll_list1" onchange="checkAll('list1');" />
                    <span class="lbl"></span>
                </th>
                <th></th>
                <th>Name</th>
                <th>Branch</th>
                <th>Companay</th>
                <th>Salary</th>
                <th>commitmentSalary</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>is Last?</th>
                <th>is Fix?</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(count($rsSalary)==0)
            {
			 echo "<tr>";
                echo '<td colspan="10" style="text-align:center;">No data found.</td>';
                echo "</tr>";
            }
            else
            {
                foreach($rsSalary as $arrRecord)
                {
                    $strEditLink	=	"index.php?c=salary&m=Addsalary&action=E&id=".$arrRecord['salaryid'];
                    echo '<tr>';
                    echo '<td><input type="checkbox" name="chk_lst_list1[]" id="chk_lst_'.$arrRecord['salaryid'].'" value="'.$arrRecord['salaryid'].'" /><span class="lbl"></span></td>';
                    echo '<td width="20" class="action-buttons" nowrap="nowrap">';
                    echo '<a href="'.$strEditLink.'" class="green" title="Edit"><i class="icon-pencil bigger-130"></i></a>';
                    echo '<td>'. $arrRecord['empName'] .'</td>';
					echo '<td>'. $arrRecord['bname'] .'</td>';
					echo '<td>'. $arrRecord['cname'] .'</td>';
					echo '<td>'. $arrRecord['salary'] .'</td>';
					echo '<td>'. $arrRecord['commitmentSalary'] .'</td>';
					
					$start = isset($arrRecord['Startdate']) && $arrRecord['Startdate'] != '0000-00-00' && $arrRecord['Startdate'] != '' ?  date('D d-M, Y',strtotime($arrRecord['Startdate'])) :  ' - ';
					$end = isset($arrRecord['Enddate']) && $arrRecord['Enddate'] != '0000-00-00' && $arrRecord['Enddate'] != '' ?  date('D d-M, Y',strtotime($arrRecord['Enddate'])) :  ' - ';
					
					echo '<td>'. $start.'</td>';
					echo '<td>'. $end .'</th>';
					echo '<td>'. $arrRecord['islast'] .'</th>';
					echo '<td>'. $arrRecord['isFix'] .'</th>';
					echo '</tr>';
                }
            }
            ?>
            </tbody>
        </table>
    </div>
</div>
<?php echo form_close(); ?>
<?php if($blnAjax != 1): ?>
<div class="modal fade" id="exportModel" tabindex="-1" style="display:none;" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<?php 
	$attributes = array('id' => 'file_import', 'name'=>'file_import');
	echo form_open_multipart('c=salary&m=import', $attributes);
	?>
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="exampleModalLongTitle">Import Salary Data</h5></div>
            <div class="modal-body">
            	<div class="col-sm-12">
					
                    <div class="row-fluid" id="printFrmDiv">
                        <div class="span10">
                            <fieldset>
                                <div class="control-group">
                                    <label for="form-field-1 span6" class="control-label">File <span class="red">*</span></label>
                                    <div class="controls">
                                    	<input type="file" id="import" name="import" class="required span6">
                                    </div>
                                </div>
                    
                                <div class="control-group">
                                    <label for="form-field-1 span6" class="control-label">Start Date <span class="red">*</span></label>
                                    <div class="controls">
                                   		<input type="text" id="startDate" name="startDate" class="required span6" value="">
                                    </div>
                                </div>                                
                                
                            </fieldset>
                        </div>
                    </div>

                                   
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="form-import-submit" class="btn btn-primary">Upload</button>
            </div>
        </div>
    </div>
    <?php
	echo form_close();
	?> 
</div>
    <?php include(APPPATH.'views/bottom.php'); ?>
<?php endif; ?>

<script type="text/javascript">
var oTable1;
$(document).ready(function(e) {
	<?php if(count($rsSalary)> 0): ?>
	oTable1 =	$('#pagelist_center').dataTable( {
		"aoColumns": [{"bSortable": false}, {"bSortable": false},null,null,null,null,null,null,null,null,null],
		"iDisplayLength": 25,
	});
	if(oTable1){
		var len = oTable1.fnSettings().aoColumns;
		var colStr = '<b>Select TO show / hide columns : &nbsp;</b>';
		for(i = 0; i < len.length; i++){
			var colTitle = $.trim(oTable1.fnSettings().aoColumns[i].sTitle.replace(/(<([^>]+)>)/ig,""));
			if(colTitle != '')
			colStr += '<span><a href="javascript:void(0);" onclick="fnShowHide('+i+');">'+colTitle+',</a> &nbsp;</span>';
		}
		$('#tableColToggle').html(colStr);
	}
	
	<?php endif; ?>
	$('#startDate').datepicker({
		autoclose: true,
		format: 'yyyy-mm-dd'
	});
});

function openAddPage(){
	window.location.href = 'index.php?c=salary&m=Addsalary&action=A';
}

function DeleteRow(){
	var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
	if(intChecked == 0){
		alert("No Designation selected.");
		return false;
	}else{
		var responce = confirm("Do you want to delete selected record(s)?");
		if(responce==true){
			$('#frm_list_record').attr('action','index.php?c=salary&m=delete');
			$('#frm_list_record').submit()
		}
	}
}

$(document).on('click','#importBtn',function(){
	$('#exportModel').modal('show');
});

$(document).on('click','#form-import-submit',function(){
	if($('#import')[0].files.length > 0 && confirm('Are you sure to import excel data?')){
		if($('#startDate').val() == ''){
			$('#startDate').addClass('border-red');
			return false;
		}
		$(this).parents('form').submit();
	}else{
		alert('Please select excel file');
	}
});

$(document).on('click','#downloadFormat',function(e){
	window.location.href = "?c=salary&m=download_format";
});
</script>
