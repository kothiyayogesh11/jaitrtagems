<?php
include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('id' => 'frm_calc_salary', 'class'=>'frm_calc_salary form-horizontal', 'name'=>'frm_calc_salary');
echo form_open_multipart('c=CalculateSalary&m=calculate', $attributes);
?>

<div class="page-header position-relative">
    <h1>Calculate Salary</h1>
    <?php
    echo $this->Page->getMessage();
    ?>
</div>
<input type="hidden" id="action" name="action" value="<?php echo $strAction; ?>" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />

<div class="row-fluid">
    <div class="span10">
        <fieldset>
            <div class="control-group">
                <label for="form-field-1" class="control-label">Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="calc_date" name="calc_date" class="required span6" value="" /
                </div>
            </div>
            <br/>
            <div class="control-group">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Calculate" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>
<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>


<script type="text/javascript">
    $(document).ready(function(e) {
        $('#calc_date').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd'
        });
    });

    function openAddPage(){
        window.location.href = 'index.php?c=salary&m=Addsalary&action=A';
    }

    function DeleteRow(){
        var intChecked = $("input[name='chk_lst_list1[]']:checked").length;
        if(intChecked == 0){
            alert("No Designation selected.");
            return false;
        }else{
            var responce = confirm("Do you want to delete selected record(s)?");
            if(responce==true){
                $('#frm_list_record').attr('action','index.php?c=salary&m=delete');
                $('#frm_list_record').submit()
            }
        }
    }
</script>
