<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_city', 'name' => 'frm_add_city');
echo form_open('c=salary&m=saveSalary', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Salary</h1>
    <?php
		echo $strMessage;
	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        
        	<div class="control-group">
                <label for="form-field-1" class="control-label">Employee<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="empID" id="empID" >
                    	<?php echo $this->Page->generateComboByTable("employee_masater","id","EmpFullName","","where delete_flag = 0",$rsEdit->empID,"Select Employee"); ?>
                    </select>
                </div>
            </div>
            
            <!--<div class="control-group">
                <label for="form-field-1" class="control-label">Branch<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="branchID" id="branchID" >
                    	<?php echo $this->Page->generateComboByTable($this->salary_model->tbl_branch_master,"id","BranchName","","where delete_flag = 0",$rsEdit->branchID,"Select Brnach"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Company<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="compID" id="compID" >
                    	<?php echo $this->Page->generateComboByTable($this->salary_model->tbl_companymaster,"id","name","","where delete_flag = 0",$rsEdit->branchID,"Select Company"); ?>
                    </select>
                </div>
            </div>-->

            <div class="control-group">
                <label for="form-field-1" class="control-label">Total Salary<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="totalsalary" name="totalsalary" class="required span6 isnumber" value="<?php echo $rsEdit->totalsalary; ?>"/>
                </div>
            </div>

			<div class="control-group">
                <label for="form-field-1" class="control-label">Basic Salary<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="salary" name="salary" class="required span6 isnumber" value="<?php echo $rsEdit->salary; ?>"/>
                </div>
            </div>
            
             <div class="control-group">
                <label class="control-label">HRA <span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="HRA" name="HRA" class="required span6" value="<?php echo $rsEdit->HRA; ?>" />
                </div>
            </div>
               
            <div class="control-group">
                <label for="form-field-1" class="control-label">Conveyence Allowence</label>
                <div class="controls">
                    <input type="text" id="conveyence_allowence" name="conveyence_allowence" class="span6" value="<?php echo $rsEdit->conveyence_allowence; ?>"/>
                </div>
            </div>
		
           <div class="control-group">
                <label for="form-field-1" class="control-label">Standard Allowence</label>
                <div class="controls">
                    <input type="text" id="standard_allowence" name="standard_allowence" class="span6" value="<?php echo $rsEdit->standard_allowence; ?>"/>
                </div>
            </div>
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Special Allowence</label>
                <div class="controls">
                    <input type="text" id="special_allowence" name="special_allowence" class="span6" value="<?php echo $rsEdit->special_allowence; ?>"/>
                </div>
            </div>
          
          
          <div class="control-group">
                <label for="form-field-1" class="control-label">Commitment Salary</label>
                <div class="controls">
                    <input type="text" id="commitmentSalary" name="commitmentSalary" class="span6 isnumber" value="<?php echo $rsEdit->commitmentSalary; ?>"/>
                </div>
            </div>
          
          
          
           <div class="control-group">
                <label for="form-field-1" class="control-label">Start Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="startDate" name="startDate" class="required span6" value="<?php echo $rsEdit->startDate; ?>" />
                </div>
            </div>
            
            
            <!--<div class="control-group">
                <label for="form-field-1" class="control-label">End Date<span class="red">*</span></label>
                <div class="controls">
                   <input type="text" id="endDate" name="endDate" class="required span6" value="<?php echo $rsEdit->endDate; ?>" />
                </div>
            </div>-->
            
            
            
            
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Is Fix?<span class="red">*</span></label>
                <div class="controls">
                	<select class="required span6" name="isFix" id="isFix" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUSYESNO' order by seq",$rsEdit->isFix,""); ?>
                    </select>
                </div>
            </div>
            
            
            
            <!-- New Field 14-08-18 -->
            
            <div class="control-group">
                <label class="control-label">TDS <span class="red">*</span></label>
                <div class="controls">
                	<select name="TDS" class="required span6">
                   			 <!--<option value=""> -- Select TDS -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->TDS) && $rsEdit->TDS == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->TDS) && $rsEdit->TDS == '0' ? 'selected=selected' : ''; ?>>No</option>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">PF <span class="red">*</span></label>
                <div class="controls">
                <select name="PF" class="required span6">
                   			 <!--<option value=""> -- Select PF -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->PF) && $rsEdit->PF == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->PF) && $rsEdit->PF == '0' ? 'selected=selected' : ''; ?>>No</option>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">ESI <span class="red">*</span></label>
                <div class="controls">
                <select name="ESI" class="required span6">
                   			 <!--<option value=""> -- Select ESI -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->ESI) && $rsEdit->ESI == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->ESI) && $rsEdit->ESI == '0' ? 'selected=selected' : ''; ?>>No</option>
                    </select>
                </div>
            </div>
            
           
            
            <div class="control-group">
                <label class="control-label">SPLALL <span class="red">*</span></label>
                <div class="controls">
                <select name="SPLALL" class="required span6">
                   			 <!--<option value=""> -- Select ESI -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->SPLALL) && $rsEdit->SPLALL == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->SPLALL) && $rsEdit->SPLALL == '0' ? 'selected=selected' : ''; ?>>No</option>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">INC <span class="red">*</span></label>
                <div class="controls">
                	<select name="INC" class="required span6">
                   			 <!--<option value=""> -- Select INC -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->INC) && $rsEdit->INC == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->INC) && $rsEdit->INC == '0' ? 'selected=selected' : ''; ?>>No</option>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Trans <span class="red">*</span></label>
                <div class="controls">
                	<select name="Trans" class="required span6">
                   			 <!--<option value=""> -- Select Trans -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->Trans) && $rsEdit->Trans == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->Trans) && $rsEdit->Trans == '0' ? 'selected=selected' : ''; ?>>No</option>	
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">PTAX <span class="red">*</span></label>
                <div class="controls">
                    <select name="PTAX" class="required span6">
                   			 <!--<option value=""> -- Select PTAX -- </option>-->
                               <option value="1" <?php echo $select = isset($rsEdit->PTAX) && $rsEdit->PTAX == '1' ? 'selected=selected' : ''; ?>>Yes</option>
                               <option value="0" <?php echo $select = isset($rsEdit->PTAX) && $rsEdit->PTAX == '0' ? 'selected=selected' : ''; ?>>No</option>
                    </select>
                </div>
            </div>
            
            
            <!-- End -->
            
            
            
            
            <div class="control-group non-printable">
                <div class="controls">
                        <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>
<script type="text/javascript">

$(document).ready(function () {
    var daysToAdd = 1;
	var start = new Date();
	var end = new Date(new Date().setYear(start.getFullYear()+1));
	$('#startDate').datepicker({
		autoclose: true,
		format: 'yyyy-mm-dd',
		endDate   : end
	}).on('changeDate', function(){$('#endDate').datepicker('setStartDate', new Date($(this).val()));}); 

	$('#endDate').datepicker({
		autoclose: true,
		format: 'yyyy-mm-dd',
		endDate   : end
	}).on('changeDate', function(){$('#startDate').datepicker('setEndDate', new Date($(this).val()));});
});


$( document ).ready(function() {
	<?php if($strAction == 'E'):?>
		getStates(slt_country);
	<?php endif;?>
});
    
function checkCompanyCode(obj) {
	var field = obj.id;
	 var fieldVal = $('#'+obj.id).val();
	 $.ajax({
		type:"POST",
		url:"index.php?c=company&m=checkCompanyCode",
		data:"field="+field+"&fieldVal="+fieldVal+"&id="+<?php echo $id ? $id : 'null'; ?>,
		beforeSend:function(){
		},
		success:function(res){
			if (res == 'CodeExists'){
				$('#'+obj.id+'_error')
					.css('color', 'red')
					.html("Code is already Exists.");
				$('#'+obj.id).addClass('border-red');
				$('#'+obj.id).focus();
			}else if (res == 'NameExists'){
				$('#'+obj.id+'_error')
					.css('color', 'red')
					.html("Name is already Exists.");
				$('#'+obj.id).addClass('border-red');
				$('#'+obj.id).focus();
			} else{
				$('#'+obj.id+'_error').empty();
				$('#'+obj.id).removeClass('border-red');
			}
		}
	});
}
</script>
