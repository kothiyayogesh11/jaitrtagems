<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="../images/ptpl_favicon.png" type="image/x-icon" />
	<title>POOJARA TELECOM PVT. LTD</title>

	<!--basic styles-->
	<link href="css/bootstrap.min.css" rel="stylesheet" />
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="css/font-awesome.min.css" />

	<!--[if IE 7]>
	  <link rel="stylesheet" href="css/font-awesome-ie7.min.css" />
	<![endif]-->

	<!--page specific plugin styles-->
	<!--fonts-->
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" />

	<!--ace styles-->
	<link rel="stylesheet" href="css/ace.min.css" />
	<link rel="stylesheet" href="css/ace-responsive.min.css" />
	<link rel="stylesheet" href="css/ace-skins.min.css" />
	
	<link rel="stylesheet" href="css/style.main.css" />
	<link rel="stylesheet" href="./css/customize.css" />
</head>

<body class="login-layout">
<div class="main-container container-fluid">
