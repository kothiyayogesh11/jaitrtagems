<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_air', 'name' => 'frm_add_air');
echo form_open('c=flight_schedule&m=save', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Flight Schedule</h1>
    <?php
		echo $strMessage;
	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
			<!--
			<div class="control-group">
                <label for="flight_date" class="control-label">Flight Date<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="flight_date" name="flight_date" class="required span6" value="<?php echo $rsEdit->flight_date; ?>">
					
                </div>
            </div>
			-->
			<div class="control-group">
                <label for="departure" class="control-label">Departure<span class="red">*</span></label>
                <div class="controls">
				<input type="text" id="flight_date" name="flight_date" class="required span3" value="<?php echo $rsEdit->flight_date; ?>">
				<?php
					$flight_date = $rsEdit->flight_date;
					$departure_time = date( 'H:i', strtotime( $rsEdit->departure ) );
					
					$departure_time_arr = explode( ":", $departure_time);
					
					$departure_hr = $departure_time_arr[0];
					$departure_min = $departure_time_arr[1];
				?>
					<select id="departure_hour" name="departure_hour" class="required" style="width:75px;">
						<option value="">Hours</option>
						<?php
							for($i=0; $i<=23; $i++)
							{
								$j = $i;
								if( $i < 10 )
								{
									$j = '0'.$i;
								}
						?>
								<option value="<?php echo $j?>"
									<?php echo ($i==$departure_hr) ? 'selected' : '';?>
								><?php echo $j;?></option>
						<?php
							}
						?>
					</select>
					
					<select id="departure_minutes" name="departure_minutes" class="required" style="width:90px;">
						<option value="">Minutes</option>
						<?php
							for($i=0; $i<=59; $i++)
							{
								$j = $i;
								if( $i < 10 )
								{
									$j = '0'.$i;
								}
						?>
								<option value="<?php echo $j?>"
									<?php echo ($i==$departure_min) ? 'selected' : '';?>
								><?php echo $j?></option>
						<?php
							}
						?>
					</select>
					<label id="departure_date" style="display:inline-block;margin-top: 3px;margin-left: 8px;"></label>
					<!--
                    <input type="text" id="departure" name="departure" class="required span6 input-small" value="<?php echo $rsEdit->departure; ?>">
					-->
                </div>
            </div>
			
			<div class="control-group">
                <label for="arrival" class="control-label">Arrival<span class="red">*</span></label>
                <div class="controls">
					<?php
						$arrival_datetime = $rsEdit->arrival;
						$arrival_date = date( 'Y-m-d', strtotime( $arrival_datetime ) );
						$arrival_time = date( 'H:i', strtotime( $arrival_datetime ) );
						
						$arrival_time_arr = explode( ":", $arrival_time);
						
						$arrival_hr = $arrival_time_arr[0];
						$arrival_min = $arrival_time_arr[1];
					?>
					<input type="text" id="arrival_date" name="arrival_date" class="required span3" value="<?php echo $arrival_date; ?>">
					
					<select id="arrival_hour" name="arrival_hour" class="required" style="width:75px;">
						<option value="">Hours</option>
						<?php
							for($i=0; $i<=23; $i++)
							{
								$j = $i;
								if( $i < 10 )
								{
									$j = '0'.$i;
								}
						?>
								<option value="<?php echo $j?>"
									<?php echo ($i==$arrival_hr) ? 'selected' : '';?>
								><?php echo $j;?></option>
						<?php
							}
						?>
					</select>
					
					<select id="arrival_minutes" name="arrival_minutes" class="required" style="width:90px;">
						<option value="">Minutes</option>
						<?php
							for($i=0; $i<=59; $i++)
							{
								$j = $i;
								if( $i < 10 )
								{
									$j = '0'.$i;
								}
						?>
								<option value="<?php echo $j?>"
									<?php echo ($i==$arrival_min) ? 'selected' : '';?>
								><?php echo $j?></option>
						<?php
							}
						?>
					</select>
					<label id="arrival_date" style="display:inline-block;margin-top: 3px;margin-left: 8px;"></label>
				<!--
                    <input type="text" id="arrival" name="arrival" class="required span6" value="<?php echo $rsEdit->arrival; ?>">
				-->
                </div>
            </div>
		
			<div class="control-group">
                <label for="air_id" class="control-label">AirCraft<span class="red">*</span></label>
                <div class="controls">
                  
                    <select class="required span6" name="air_id" id="air_id">
						<option value="">Select AirCraft</option>
						<?php
							if( isset( $aircraft_info ) && !empty( $aircraft_info ) )
							{
								foreach( $aircraft_info AS $aircraft )
								{
						?>
									<option value="<?php echo $aircraft['id'];?>"
										data-no_of_passengers="<?php echo $aircraft['no_of_passengers'];?>"
										data-code="<?php echo $aircraft['code'];?>"
										data-name="<?php echo $aircraft['name'];?>"
							<?php echo ($rsEdit->air_id == $aircraft['id']) ? 'selected' : ''; ?>
									>
<?php echo $aircraft['name'] .' - '.$aircraft['code'].' ('. $aircraft['no_of_passengers'] .')';?>
									</option>
						<?php
								}
							}
						?>
                    </select>
                </div>
            </div>
			
			<div class="control-group">
                <label for="air_fare_id" class="control-label">Air Fare<span class="red">*</span></label>
                <div class="controls">
                  
                    <select class="required span6" name="air_fare_id" id="air_fare_id">
						<option value="">Select Air Fare</option>
						<?php
							if( isset( $air_fare_info ) && !empty( $air_fare_info ) )
							{
								foreach( $air_fare_info AS $air_fare )
								{
						?>
									<option value="<?php echo $air_fare['id'];?>"
										data-fare="<?php echo $air_fare['fare'];?>"
										data-fsc="<?php echo $air_fare['fsc'];?>"
										data-route_id="<?php echo $air_fare['route_id'];?>"
										data-from_city_name="<?php echo $air_fare['from_city_name'];?>"
										data-to_city_name="<?php echo $air_fare['to_city_name'];?>"
										data-route_code="<?php echo $air_fare['route_code'];?>"
							<?php echo ($rsEdit->air_fare_id == $air_fare['id']) ? 'selected' : ''; ?>
									>
<?php echo $air_fare['from_city_name'] .' - '.$air_fare['to_city_name'].' '.' - '.$air_fare['fare'];?>
									</option>
						<?php
								}
							}
						?>
                    </select>
                </div>
            </div>
			
			<div class="control-group">
                <label for="status" class="control-label">Status</label>
                <div class="controls">
                	<select class="required span6" name="status" id="status" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='STATUS' order by seq",$rsEdit->status,""); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group non-printable">
                <div class="controls">
                        <input type="submit" class="btn btn-primary btn-small" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>

<script>

$("#flight_date").datepicker({
	//format: 'dd/mm/yyyy',
	format: 'yyyy-mm-dd',
	todayBtn: true,
	autoclose: true
})
.on("changeDate", function(e) {
	// `e` here contains the extra attributes
	$("#arrival_date").val( $("#flight_date").val() );
});

$("#arrival_date").datepicker({
	//format: 'dd/mm/yyyy',
	format: 'yyyy-mm-dd',
	todayBtn: true,
	autoclose: true
});

</script>