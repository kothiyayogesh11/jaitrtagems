<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_user', 'name' => 'frm_add_user');
echo form_open('c=scheme_master&m=process', $attributes);
?>
<div class="page-header position-relative">
    <h1>Add Scheme</h1>
    <?php echo $strMessage; ?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
        	 <div class="control-group">
                <label class="control-label">Beneficiary Type<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="beneficiary_type" id="beneficiary_type" >
                    	<?php echo $this->Page->generateComboByTable($this->scheme->tbl_combo_master,"combo_key","combo_value","","where combo_case = 'BFTYPE' AND status = 'ACTIVE'",$rsEdit->beneficiary_type,"Select Type"); ?>
                    </select>
                </div>
            </div>
            
             <div class="control-group">
                <label class="control-label">Beneficiary<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="Beneficiary" id="Beneficiary" >
                    	<?php 
						error_reporting(-1);
						if(isset($rsEdit->beneficiary_type) && $rsEdit->beneficiary_type != ''){
                        	echo $bf_dd;
						}else{
                        	echo '<option value="">Select Beneficiary</option>';
						}
						?>
                    </select>
                </div>
            </div>
            
             <div class="control-group">
                <label class="control-label">Month<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" name="Month" id="Month" class="required span6" placeholder="Month" value="<?php echo $rsEdit->month; ?>" />
                </div>
            </div>
        
        	<div class="control-group">
                <label class="control-label">SchemeBase<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="SchemeBase">
                    	<?php echo $this->Page->generateComboByTable($this->scheme->tbl_combo_master,"combo_key","combo_value","","where combo_case = 'SCHEME_BASE' AND status = 'ACTIVE'",$rsEdit->SchemeBase,"Select Type"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Employee<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="Employee" id="Employee" >
                        <?php 
						error_reporting(-1);
						if(isset($rsEdit->beneficiary_type) && $rsEdit->beneficiary_type != ''){
                        	echo $emp_data;
						}else{
                        	echo '<option value="">Select Employee</option>';
						}
						?>
                    </select>
                </div>
            </div>
          
        	 <div class="control-group">
                <label class="control-label">Inactive Type<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="inactive_type" id="inactive_type" >
                    	<?php echo $this->Page->generateComboByTable($this->scheme->tbl_combo_master,"combo_key","combo_value","","where combo_case = 'inactive_type' AND status = 'ACTIVE'",$rsEdit->inactive_type,"Select Type"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Inactive value</label>
                <div class="controls">
                    <input type="text" name="inactive_value" id="inactive_value" class="span6" placeholder="Inactive Value" value="<?php echo $rsEdit->inactive_value; ?>" />
                </div>
            </div>

            
            <div class="control-group non-printable">
                <div class="controls">
                    <input type="submit" class="btn btn-primary btn-small" value="Save"> 
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>
<?php include(APPPATH.'views/bottom.php'); ?>

<script type="text/javascript">
$(document).ready(function(e) {
	//$("#Employee").chosen({no_results_text: "Oops, nothing found!"});
    $('#Month').datepicker({autoclose: true,format: 'yyyy-mm-dd'});
});

$(document).on('change','#beneficiary_type',function(){
	var $obj = $(this);
	var $id = $('#Beneficiary').val();
	if($obj.val() != ''){
		$.ajax({
			type:"POST",
			url:base_url+"?c=scheme_master&m=get_beneficiary_type_list",
			data:{'type':$obj.val(),'id':$id},
			success: function(res){
				$('#Beneficiary').html(res);
			}
		});
	}else{
		$('#Beneficiary').find('option').not('option[value=""]').remove();
	}
});

$(document).on('change','#Beneficiary',function(){
	var $bftype = $('#beneficiary_type').val();
	var $bf = $('#Beneficiary').val();
	if($bftype != '' || $bf != ''){
		$.ajax({
			type:"POST",
			url:base_url+"?c=scheme_master&m=get_beneficiary_employee",
			data:{'type':$bftype,'id':$bf},
			success: function(res){
				$('#Employee').html(res);
				//$("#Employee").chosen(res);
			}
		});
	}else{
		$('#Beneficiary').find('option').not('option[value=""]').remove();
	}
});

$(document).on('click','input[type="submit"]',function(e){
	var err_flag = true;
	$(this).parents('form').find('.required').each(function(index, element) {
        if($(element).val() == ''){
			err_flag = false;
			$(element).addClass('border-red');
		}else{
			if(element.name == 'BranchCode' && !codeFlag){
				err_flag = false;
				$(element).addClass('border-red');
			}else{
				$(element).removeClass('border-red');
			}
			
		}
    });
	return err_flag && codeFlag;
});

</script>
