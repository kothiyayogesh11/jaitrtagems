<?php include(APPPATH.'views/top.php');
$this->load->helper('form');
$attributes = array('class' => 'frm_add_record form-horizontal', 'id' => 'frm_add_customer', 'name' => 'frm_add_customer');
echo form_open_multipart('c=emp_setting&m=SaveDetails', $attributes);
?>
<style type="text/css">
input[type=checkbox], input[type=radio] { opacity: 1; position: inherit;}
</style>
<div class="page-header position-relative">
    <h1>Add Employee Setting</h1>
    <?php echo $strMessage;	?>
</div>
<input type="hidden" name="action" value="<?php echo $strAction; ?>" id="action"/>
<input type="hidden" name="hid_id" value="<?php echo $id; ?>" id="hid_id" />
<input type="hidden" id="txt_counter" name="txt_counter" value="0" />
<input type="hidden" id="from_page" name="from_page" value="<?php echo $from_page; ?>" />
<div class="row-fluid" id="printFrmDiv">
    <div class="span10">
        <fieldset>
          <div class="control-group">
                <label for="form-field-1" class="control-label">Name<span class="red">*</span></label>
                <div class="controls">
                    <input type="text" id="name" name="name" class="span6 required" value="<?php echo $rsEdit->name ?>"/>
                </div>
            </div>
         		
             <div class="control-group">
                <label for="form-field-1" class="control-label">Amount Type<span class="red">*</span></label>
                <div class="controls">
                	<select class="required span6" name="type" id="type" >
                        <?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value",0,"where combo_case='SETTINGTYPE' order by seq",$rsEdit->type,""); ?>
                    </select>
                </div>
            </div>
            
            
            <div class="control-group">
               <label for="form-field-1" class="control-label">Value<span class="red">*</span></label>
               <div class="controls">
                   <input type="text" id="value" name="value" class="required span6 isnumber" value="<?php echo $rsEdit->value ?>"/>
               </div>
            </div>
            
            <div class="control-group">
               <label for="form-field-1" class="control-label">Min Limit<span class="red">*</span></label>
               <div class="controls">
                   <input type="text" id="min_limit" name="min_limit" class="required span6 isnumber" value="<?php echo $rsEdit->min_limit ?>"/>
               </div>
            </div>
            
            <div class="control-group">
               <label for="form-field-1" class="control-label">Max Limit<span class="red">*</span></label>
               <div class="controls">
                   <input type="text" id="max_limit" name="max_limit" class="required span6 isnumber" value="<?php echo $rsEdit->max_limit ?>"/>
               </div>
            </div>  
            
            <div class="control-group">
                <label for="form-field-1" class="control-label">Salary Head Code<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="salary_head_code" id="salary_head_code" >
                    	<?php echo $this->Page->generateComboByTable("salary_head_master","id","code","","where delete_flag = 0",$rsEdit->salary_head_code,"-- Select Code --"); ?>
                    </select>
                </div>
            </div>

            <div class="control-group">
                <label for="form-field-1" class="control-label">Salary Head Code Store<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="salary_head_code_store" id="salary_head_code_store" >
                        <?php echo $this->Page->generateComboByTable("salary_head_master","id","code","","where delete_flag = 0",$rsEdit->salary_head_code_store,"-- Select Code --"); ?>
                    </select>
                </div>
            </div>
            
            <div class="control-group">
                <label class="control-label">Type<span class="red">*</span></label>
                <div class="controls">
                    <select class="required span6" name="cal_type" id="cal_type" >
                    	<?php echo $this->Page->generateComboByTable("combo_master","combo_key","combo_value","","where combo_case = 'SALARYHEAD' AND status = 'ACTIVE'",$rsEdit->cal_type,"-- Select Type --"); ?>
                    </select>
                </div>
            </div>

            <div class="control-group">
                <label for="isRange" class="control-label">Calculate on basic salary?</label>
                <?php  $value = isset($rsEdit->is_calc_on_base_salary)&& $rsEdit->is_calc_on_base_salary == 1 ? '1' : '0'; ?>
                <?php  $checked = isset($rsEdit->is_calc_on_base_salary)&& $rsEdit->is_calc_on_base_salary == 1 ? 'checked= "checked" ' : ''; ?>
                <div class="controls">
                    <input type="checkbox" name="is_calc_on_base_salary" id="is_calc_on_base_salary" value="<?php echo $value; ?>" <?php echo $checked; ?> />
                </div>
            </div>
            
            <div class="control-group">
               <label for="isRange" class="control-label">Is Range ?</label>
               <?php  $value = isset($rsEdit->isRange)&& $rsEdit->isRange == 1 ? '1' : '0'; ?>
               <?php  $checked = isset($rsEdit->isRange)&& $rsEdit->isRange == 1 ? 'checked= "checked" ' : ''; ?>
               <div class="controls">
                    <input type="checkbox" name="isRange" id="isRange" value="<?php echo $value; ?>" <?php echo $checked; ?> />
               </div>
          	</div>
            
            <div class="date-placeholder">
                <div class="control-group for-date" style="display:none">
                        <div class="control-group">
                           <label for="form-field-1" class="control-label">From<span class="red">*</span></label>
                           <div class="controls">
                               <input type="text" id="from" name="from" class="span6" value="<?php echo $rsEdit->from ?>"/>
                           </div>
                       	</div>  
                       
                       <div class="control-group">
                           <label for="form-field-1" class="control-label">To<span class="red">*</span></label>
                           <div class="controls">
                        <input type="text" id="to" name="to" class="span6" value="<?php echo $rsEdit->to ?>"/>
                           </div>
                       </div>  
                </div>
			</div>
            
                  
            <div class="control-group non-printable">
                <div class="controls">
                        <input type="submit" class="btn btn-primary btn-small newsubmit" value="Save" onclick="return submit_form(this.form);">
                    <input type="button" class="btn btn-primary btn-small" value="Cancel" onclick="window.history.back()" >
                </div>
            </div>
        </fieldset>
    </div>
</div>

<?php echo form_close(); ?>

<?php include(APPPATH.'views/bottom.php'); ?>

<script type="text/javascript">
$(document).ready(function() {
     $('#isRange').val('0');
	if($('input[name="isRange"]').prop('checked') == false){
		$('.for-date').hide(1000);
		$('#isRange').val('0');
	}else{
		$('.for-date').show(1000);
		$('#from').addClass('required');
		$('#to').addClass('required');
		$('#isRange').val('1');
	}

    if($("#is_calc_on_base_salary").prop('checked') == false){
        $('#is_calc_on_base_salary').val('0');
    }else{
        $('#is_calc_on_base_salary').val('1');
    }
});

$(document).on('change','input[name="isRange"]',function(){
	if($(this).prop('checked') == false){
		$('.for-date').hide(1000);
		$('#isRange').val('0');
	}else{
		$('.for-date').show(1000);
		$('#from').addClass('required');
		$('#to').addClass('required');
		$('#isRange').val('1');
	}
});

$(document).on('click','#is_calc_on_base_salary',function(){
    if($(this).prop('checked') == false){
        $('#is_calc_on_base_salary').val('0');
    }else{
        $('#is_calc_on_base_salary').val('1');
    }
});

	$('.newsubmit').click(function(){
		return true;
		 var password = $('#password').val();
		 var cpass = $('#cpassword').val();
		    
		    if(password != cpass){
				  $('#password').addClass('required');
				  $('#cpassword').addClass('required'); 
				  return false;
		    }
		    return true;
		    
	});
   

    function checkEmail(obj) {
	    var field = obj.id;
        var fieldVal = $('#'+obj.id).val();
	   
        $.ajax({
            type:"POST",
            url:"index.php?c=empoyee_details&m=checkEmail",
            data:"field="+field+"&fieldVal="+fieldVal+"&id="+<?php echo $id ? $id : 'null'; ?>,
            beforeSend:function(){
            },
            success:function(res){
                if (res == 'emailExists'){
                    $('#'+obj.id+'_error')
                        .css('color', 'red')
                        .html("Email already exists.");
                    $('#'+obj.id).addClass('border-red');
                    $('#'+obj.id).focus();
                }
                else{
                    $('#'+obj.id+'_error').empty();
                    $('#'+obj.id).removeClass('border-red');
                }
            }
        });
    }

    $(function() {
        $("#txt_dob").datepicker({
            format: 'dd/mm/yyyy'
        });
    });

    $('.delete_file_link').click( function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to delete image?'))
        {
            var file = "<?php echo isset($rsEdit->image) ? $rsEdit->image : ''; ?>";
            $.ajax({
                url:"index.php?c=customer&m=deleteImage",
                data:"filename="+file+"&id="+<?php echo isset($rsEdit->id) ? $rsEdit->id : 'null';?>,
                success		: function (data)
                {
                    location.reload();
                }
            });
        }
    });
</script>